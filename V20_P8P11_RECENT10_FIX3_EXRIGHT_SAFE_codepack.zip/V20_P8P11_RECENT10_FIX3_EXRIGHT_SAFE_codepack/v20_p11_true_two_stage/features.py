import os, gc, math
from pathlib import Path
import numpy as np
import pandas as pd
try:
    import duckdb
except Exception:
    duckdb=None
from tqdm import tqdm
from .utils import normalize_symbol_from_parts, safe_z, pct_rank

KLINE_FEATURES = [
 'ret_1','ret_2','ret_3','ret_5','ret_10','ret_20','ret_60','ret_120','ret_180',
 'limitup_like_1','limitup_like_2','limitup_count_3','limitup_count_5','limitup_count_10','near_limitup_count_5','near_limitup_count_10',
 'is_high20_break','is_high60_break','is_high120_break','close_to_high20','close_to_high60','close_to_high120',
 'amount_ratio_1_5','amount_ratio_1_20','amount_ratio_3_20','amount_ratio_5_60','amount_rank_20','amount_rank_60','amount_accel_1_5',
 'close_pos_1','upper_shadow_1','lower_shadow_1','body_ret_1','amp_1',
 'up_days_3','up_days_5','positive_ret_count_5','positive_ret_count_10','consecutive_up_days','consecutive_amount_up_days',
 'pos_20','pos_60','pos_120','pos_180','ma20_ratio','ma60_ratio','ma120_ratio','ma180_ratio','volatility_20','volatility_60','volatility_180','amp_20','amp_60','amp_180',
 'market_positive_ratio','market_ret_median','market_limitup_count','market_near_limitup_count','market_big_up_count','market_big_down_count','market_amount_ratio_median'
]

def read_daily_panel(duckdb_path, daily_table, candidate_symbols, min_date, max_date, logger, source_scope='all'):
    if duckdb is None: raise RuntimeError('duckdb not installed')
    con=duckdb.connect(str(duckdb_path), read_only=True)
    cols=[r[1] for r in con.execute(f"PRAGMA table_info('{daily_table}')").fetchall()]
    for c in ['date','open','high','low','close','volume','amount']:
        if c not in cols: raise ValueError(f'DuckDB table missing required column {c}')
    has_symbol='symbol' in cols; has_code='code' in cols; has_market='market' in cols
    select_cols=[]
    if has_symbol: select_cols.append('symbol as raw_symbol')
    else: select_cols.append("'' as raw_symbol")
    if has_code: select_cols.append('code as raw_code')
    else: select_cols.append("'' as raw_code")
    if has_market: select_cols.append('market as raw_market')
    else: select_cols.append("'' as raw_market")
    select_cols += ['date','open','high','low','close','volume','amount']
    q=f"SELECT {', '.join(select_cols)} FROM {daily_table} WHERE date >= ? AND date <= ?"
    logger.log(f'read DuckDB | table={daily_table} | date={min_date.date()}..{max_date.date()} | scope={source_scope}')
    df=con.execute(q, [str(min_date.date()), str(max_date.date())]).df()
    con.close()
    df['date']=pd.to_datetime(df['date']).dt.normalize()
    df['symbol']=[normalize_symbol_from_parts(r.raw_symbol, r.raw_code, r.raw_market) for r in df.itertuples(index=False)]
    for c in ['open','high','low','close','volume','amount']:
        df[c]=pd.to_numeric(df[c], errors='coerce')
    df=df.dropna(subset=['date','symbol','open','high','low','close']).sort_values(['symbol','date']).reset_index(drop=True)
    candidate_symbols=set([str(s).lower() for s in candidate_symbols])
    matched=len(candidate_symbols & set(df['symbol'].unique()))
    logger.log(f'daily rows read={len(df):,} | symbols total={df.symbol.nunique():,} | candidate symbols matched={matched}/{len(candidate_symbols)}')
    return df

def _consecutive_true(arr):
    out=np.zeros(len(arr), dtype=float)
    cnt=0
    for i,v in enumerate(arr):
        cnt = cnt+1 if bool(v) else 0
        out[i]=cnt
    return out

def build_symbol_features(daily, candidate_symbols, logger):
    # market features first, based on all available rows; shifted one day by market date
    m=daily.copy()
    m['ret_raw']=m.groupby('symbol')['close'].pct_change()
    m['amount_ratio_raw']=m['amount'] / m.groupby('symbol')['amount'].transform(lambda s: s.shift(1).rolling(20, min_periods=5).mean())
    market=m.groupby('date').agg(
        market_positive_ratio=('ret_raw', lambda x: float((x>0).mean())),
        market_ret_median=('ret_raw','median'),
        market_limitup_count=('ret_raw', lambda x: int((x>=0.095).sum())),
        market_near_limitup_count=('ret_raw', lambda x: int((x>=0.07).sum())),
        market_big_up_count=('ret_raw', lambda x: int((x>=0.05).sum())),
        market_big_down_count=('ret_raw', lambda x: int((x<=-0.05).sum())),
        market_amount_ratio_median=('amount_ratio_raw','median'),
    ).reset_index().sort_values('date')
    for c in market.columns:
        if c!='date': market[c]=market[c].shift(1)
    feats=[]
    sub=daily[daily['symbol'].isin(candidate_symbols)].copy()
    logger.log(f'building K-line features | symbols={sub.symbol.nunique():,} | rows={len(sub):,}')
    for sym,g in tqdm(sub.groupby('symbol'), desc='build_kline_features'):
        g=g.sort_values('date').reset_index(drop=True).copy()
        close=g['close'].astype(float); open_=g['open'].astype(float); high=g['high'].astype(float); low=g['low'].astype(float); amount=g['amount'].astype(float); vol=g['volume'].astype(float)
        prev_close=close.shift(1)
        ret=close.pct_change()
        raw=pd.DataFrame({'date':g['date'], 'symbol':sym})
        for n in [1,2,3,5,10,20,60,120,180]:
            raw[f'ret_{n}']=close/close.shift(n)-1
        raw['limitup_like_1']=(ret>=0.095).astype(float)
        raw['limitup_like_2']=(ret.shift(1)>=0.095).astype(float)
        raw['limitup_count_3']=(ret>=0.095).rolling(3, min_periods=1).sum()
        raw['limitup_count_5']=(ret>=0.095).rolling(5, min_periods=1).sum()
        raw['limitup_count_10']=(ret>=0.095).rolling(10, min_periods=1).sum()
        raw['near_limitup_count_5']=(ret>=0.07).rolling(5, min_periods=1).sum()
        raw['near_limitup_count_10']=(ret>=0.07).rolling(10, min_periods=1).sum()
        for n in [20,60,120]:
            prev_high=high.shift(1).rolling(n, min_periods=max(5,n//4)).max()
            roll_high=high.rolling(n, min_periods=max(5,n//4)).max()
            raw[f'is_high{n}_break']=(close>=prev_high).astype(float)
            raw[f'close_to_high{n}']=close/roll_high-1
        raw['amount_ratio_1_5']=amount/amount.shift(1).rolling(5,min_periods=2).mean()
        raw['amount_ratio_1_20']=amount/amount.shift(1).rolling(20,min_periods=5).mean()
        raw['amount_ratio_3_20']=amount.rolling(3,min_periods=1).mean()/amount.shift(1).rolling(20,min_periods=5).mean()
        raw['amount_ratio_5_60']=amount.rolling(5,min_periods=1).mean()/amount.shift(1).rolling(60,min_periods=10).mean()
        raw['amount_rank_20']=amount.rolling(20,min_periods=5).rank(pct=True)
        raw['amount_rank_60']=amount.rolling(60,min_periods=10).rank(pct=True)
        raw['amount_accel_1_5']=raw['amount_ratio_1_5']/raw['amount_ratio_5_60']
        denom=(high-low).replace(0,np.nan)
        raw['close_pos_1']=(close-low)/denom
        raw['upper_shadow_1']=(high-np.maximum(open_,close))/close.replace(0,np.nan)
        raw['lower_shadow_1']=(np.minimum(open_,close)-low)/close.replace(0,np.nan)
        raw['body_ret_1']=close/open_.replace(0,np.nan)-1
        raw['amp_1']=high/low.replace(0,np.nan)-1
        raw['up_days_3']=(ret>0).rolling(3,min_periods=1).sum()
        raw['up_days_5']=(ret>0).rolling(5,min_periods=1).sum()
        raw['positive_ret_count_5']=(ret>0).rolling(5,min_periods=1).sum()
        raw['positive_ret_count_10']=(ret>0).rolling(10,min_periods=1).sum()
        raw['consecutive_up_days']=_consecutive_true((ret>0).fillna(False).to_numpy())
        raw['consecutive_amount_up_days']=_consecutive_true((amount.pct_change()>0).fillna(False).to_numpy())
        for n in [20,60,120,180]:
            rlow=low.rolling(n,min_periods=max(5,n//4)).min(); rhigh=high.rolling(n,min_periods=max(5,n//4)).max()
            raw[f'pos_{n}']=(close-rlow)/(rhigh-rlow).replace(0,np.nan)
            ma=close.rolling(n,min_periods=max(5,n//4)).mean()
            raw[f'ma{n}_ratio']=close/ma-1
        for n in [20,60,180]:
            raw[f'volatility_{n}']=ret.rolling(n,min_periods=max(5,n//4)).std()
            raw[f'amp_{n}']=(high/low.replace(0,np.nan)-1).rolling(n,min_periods=max(5,n//4)).mean()
        # shift all features by 1: candidate date T uses T-1 and earlier
        for c in raw.columns:
            if c not in ('date','symbol'):
                raw[c]=raw[c].shift(1)
        feats.append(raw)
    out=pd.concat(feats, ignore_index=True) if feats else pd.DataFrame()
    out=out.merge(market, on='date', how='left')
    return out

def merge_features(seed_rows, feats, logger, tolerance_days=10):
    left=seed_rows.copy(); right=feats.copy()
    left['date']=pd.to_datetime(left['date']).dt.normalize(); right['date']=pd.to_datetime(right['date']).dt.normalize()
    merged=left.merge(right, on=['date','symbol'], how='left')
    exact=merged['ret_20'].notna().sum() if 'ret_20' in merged.columns else 0
    logger.log(f'exact merge ret_20 nonnull={exact}/{len(merged)}')
    if exact/ max(1,len(merged)) < 0.95:
        # asof fallback per symbol, date backward, but features are already shifted on exact date; fallback handles suspended/missing exact dates
        logger.log('exact coverage low; applying merge_asof fallback')
        parts=[]
        feat_cols=[c for c in right.columns if c not in ('date','symbol')]
        for sym,g in tqdm(left.groupby('symbol'), desc='merge_asof'):
            fg=right[right['symbol']==sym].sort_values('date').copy()
            if fg.empty:
                tmp=g.copy()
                for c in feat_cols: tmp[c]=np.nan
                parts.append(tmp); continue
            cg=g.sort_values('date').copy()
            cg['_date_ns']=pd.to_datetime(cg['date']).astype('int64')
            fg['_date_ns']=pd.to_datetime(fg['date']).astype('int64')
            tmp=pd.merge_asof(cg.sort_values('_date_ns'), fg.drop(columns=['symbol','date']).sort_values('_date_ns'), on='_date_ns', direction='backward', tolerance=pd.Timedelta(days=int(tolerance_days)).value)
            tmp=tmp.drop(columns=['_date_ns'])
            parts.append(tmp)
        merged=pd.concat(parts, ignore_index=True)
    return merged

def add_seed_local_relative_features(df, logger):
    df=df.copy()
    base_cols=[]
    for c in KLINE_FEATURES + ['seed_rank','seed_score','seed_z','seed_pct','top10_votes','top5_votes','top3_votes','top1_votes','rank_min','rank_mean','rank_std','score_mean','score_std','zscore_mean','zscore_std','rankpct_mean','rankpct_std']:
        if c in df.columns and pd.api.types.is_numeric_dtype(df[c]): base_cols.append(c)
    # rank ascending direction: for rank/std/shadow/risk lower is better, but pct itself only diagnostic; generate both normal and reverse for important risk cols
    risk_lower=['seed_rank','rank_min','rank_mean','rank_std','score_std','zscore_std','rankpct_std','upper_shadow_1','volatility_20','volatility_60','volatility_180','amp_1','amp_20','amp_60','amp_180']
    new_cols=[]
    for c in tqdm(base_cols, desc='seedlocal_relative_features'):
        grp=df.groupby(['date','seed'])[c]
        df[f'{c}_seedlocal_pct']=grp.transform(lambda s: pd.to_numeric(s,errors='coerce').rank(pct=True, method='average'))
        df[f'{c}_seedlocal_z']=grp.transform(lambda s: safe_z(s))
        df[f'{c}_seedlocal_gap_mean']=pd.to_numeric(df[c], errors='coerce')-grp.transform('mean')
        new_cols += [f'{c}_seedlocal_pct', f'{c}_seedlocal_z', f'{c}_seedlocal_gap_mean']
        if c in risk_lower:
            df[f'{c}_seedlocal_low_pct']=grp.transform(lambda s: pd.to_numeric(s,errors='coerce').rank(pct=True, ascending=False, method='average'))
            new_cols.append(f'{c}_seedlocal_low_pct')
    logger.log(f'seed-local relative features added | base_cols={len(base_cols)} | new_cols={len(new_cols)} | total_cols={len(df.columns)}')
    return df, base_cols, new_cols
