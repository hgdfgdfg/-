import os, sys, json, time, gc
from pathlib import Path
from datetime import datetime
import pandas as pd
import numpy as np

class Logger:
    def __init__(self, out_dir: str):
        self.out_dir = Path(out_dir)
        (self.out_dir / 'logs').mkdir(parents=True, exist_ok=True)
        self.path = self.out_dir / 'logs' / 'run.log'
    def log(self, msg):
        s = f"[time] {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {msg}"
        print(s, flush=True)
        with open(self.path, 'a', encoding='utf-8') as f:
            f.write(s + '\n')

def ensure_dir(p):
    Path(p).mkdir(parents=True, exist_ok=True)

def save_json(obj, path):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=str)

def normalize_symbol_from_parts(symbol=None, code=None, market=None):
    s = '' if symbol is None or (isinstance(symbol,float) and np.isnan(symbol)) else str(symbol).strip()
    c = '' if code is None or (isinstance(code,float) and np.isnan(code)) else str(code).strip()
    m = '' if market is None or (isinstance(market,float) and np.isnan(market)) else str(market).strip().lower()
    def norm_one(x):
        x=str(x).strip().lower().replace(' ', '')
        if not x or x=='nan': return ''
        if '.' in x:
            a,b=x.split('.',1)
            if b in ('sh','ss','sse'): return 'sh'+a.zfill(6)
            if b in ('sz','szse'): return 'sz'+a.zfill(6)
        if x.startswith(('sh','sz')) and len(x)>=8:
            return x[:2]+x[2:8].zfill(6)
        if x.isdigit():
            # infer if no market: 6/9 -> sh, 0/3 -> sz
            if m in ('sh','sse','ss'): return 'sh'+x.zfill(6)
            if m in ('sz','szse'): return 'sz'+x.zfill(6)
            return ('sh' if x.startswith('6') or x.startswith('9') else 'sz') + x.zfill(6)
        return x
    # prefer code+market if possible, else symbol
    if c:
        nc=norm_one(c)
        if nc and not (nc.startswith(('sh','sz')) and len(nc)>=8 and c.lower().startswith(('sh','sz'))):
            if len(nc)==8 and nc[:2] in ('sh','sz'):
                return nc
        if c.isdigit() or (len(c)==6 and c[:1].isdigit()):
            return norm_one(c)
        if nc: return nc
    return norm_one(s)

def safe_z(x):
    arr = pd.to_numeric(x, errors='coerce')
    mu = arr.mean()
    sd = arr.std(ddof=0)
    if not np.isfinite(sd) or sd < 1e-12:
        return arr*0.0
    return (arr - mu) / sd

def pct_rank(x, ascending=True):
    return pd.to_numeric(x, errors='coerce').rank(pct=True, ascending=ascending, method='average')
