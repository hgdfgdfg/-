import argparse, json, gc
from pathlib import Path
from datetime import timedelta
import pandas as pd
from .logger import Logger
from .data import load_candidate_pool, detect_seeds, prepare_candidate_pool, expand_seed_local_rows
from .features import read_daily_panel, build_symbol_features, merge_features, add_seed_local_relative_features
from .analysis import run_two_stage


def parse_args():
    ap=argparse.ArgumentParser(description='V20_P11_TRUE_TWO_STAGE_SHRINK: seed top10 -> seed-local shrink -> TRUE cross-seed stage2 shrink -> portfolio')
    ap.add_argument('--ensemble_zip', required=True)
    ap.add_argument('--duckdb_path', required=True)
    ap.add_argument('--out_dir', required=True)
    ap.add_argument('--daily_table', default='stock_daily_mainboard')
    ap.add_argument('--structure', default='W160_60_30')
    ap.add_argument('--calendar_buffer_days', type=int, default=520)
    ap.add_argument('--asof_tolerance_days', type=int, default=10)
    ap.add_argument('--force_rebuild_cache', action='store_true')
    ap.add_argument('--allow_low_coverage', action='store_true')
    ap.add_argument('--shrink_rules', default='score_kline_combo,score_kline_trend_volume,score_short_momentum,score_trend180,score_kline_balanced,score_seed_strength')
    ap.add_argument('--shrink_ks', default='3,5')
    ap.add_argument('--stage2_methods', default='stage2_retained_votes,stage2_multi_rule_votes,stage2_retained_votes_zms,stage2_retained_votes_kline,stage2_quality_filter_zms')
    ap.add_argument('--stage2_top_ns', default='8,10,12,15,20')
    ap.add_argument('--portfolio_ns', default='1,2,3,5')
    ap.add_argument('--expected_folds', type=int, default=10, help='strict input audit: require this many unique chronological fold date ranges')
    ap.add_argument('--allow_mixed_folds', action='store_true', help='debug only: allow duplicate/non-chronological fold ranges instead of aborting')
    return ap.parse_args()



def _fold_num(x):
    import re
    m=re.search(r'(\d+)', str(x))
    return int(m.group(1)) if m else 10**9

def audit_candidate_fold_schedule(cand: pd.DataFrame, out_dir: Path, logger, expected_folds: int = 10, allow_mixed: bool = False):
    d=cand.copy()
    d['date']=pd.to_datetime(d['date'], errors='coerce').dt.normalize()
    d['fold_id']=d['fold_id'].astype(str)
    tbl=(d.groupby('fold_id', dropna=False)
           .agg(start_date=('date','min'), end_date=('date','max'), n_dates=('date','nunique'), rows=('symbol','size'), symbols=('symbol','nunique'))
           .reset_index())
    tbl['fold_num']=tbl['fold_id'].map(_fold_num)
    tbl=tbl.sort_values(['start_date','end_date','fold_num','fold_id']).reset_index(drop=True)
    tbl['temporal_order_by_date']=range(1, len(tbl)+1)
    tbl['date_range_key']=tbl['start_date'].dt.strftime('%Y-%m-%d')+'__'+tbl['end_date'].dt.strftime('%Y-%m-%d')
    tbl['duplicate_range_count']=tbl.groupby('date_range_key')['fold_id'].transform('nunique')
    tbl['is_duplicate_range']=tbl['duplicate_range_count']>1
    tbl['fold_num_order_ok']=(tbl['fold_num'].rank(method='first').astype(int)==tbl['temporal_order_by_date'])
    tbl.to_csv(out_dir/'V20_P11_TRUE_candidate_fold_schedule_audit.csv', index=False, encoding='utf-8-sig')
    dup=tbl[tbl['is_duplicate_range']].copy()
    dup.to_csv(out_dir/'V20_P11_TRUE_candidate_fold_duplicate_ranges.csv', index=False, encoding='utf-8-sig')
    n_unique=int(tbl['date_range_key'].nunique())
    n_folds=int(tbl['fold_id'].nunique())
    errors=[]
    if expected_folds and n_unique != int(expected_folds):
        errors.append(f'unique date ranges={n_unique}, expected={expected_folds}')
    if expected_folds and n_folds != int(expected_folds):
        errors.append(f'fold_id count={n_folds}, expected={expected_folds}')
    if int(dup['fold_id'].nunique())>0:
        errors.append('duplicate fold date ranges found')
    # Canonical fold ids should be chronological in a clean recent10fold run.
    by_num=tbl.sort_values(['fold_num','fold_id']).reset_index(drop=True)
    if len(by_num) and not by_num['start_date'].is_monotonic_increasing:
        errors.append('fold_id numeric order is not chronological')
    logger.log(f'P11 candidate fold schedule audit | fold_ids={n_folds} unique_ranges={n_unique} expected={expected_folds} duplicates={int(dup.fold_id.nunique())} allow_mixed={allow_mixed}')
    if errors and not allow_mixed:
        raise RuntimeError('P11 input candidate pool is mixed/stale: '+ '; '.join(errors) + '. Rebuild P8 with RECENT10_FIX1 using a clean output_dir or --force so all recent10 folds are regenerated.')
    return tbl

def main():
    args=parse_args()
    out_dir=Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    logger=Logger(out_dir)
    logger.log('V20_P11_TRUE_TWO_STAGE_SHRINK start')
    logger.log(json.dumps(vars(args), ensure_ascii=False, indent=2))
    cand,src=load_candidate_pool(args.ensemble_zip,args.structure)
    cand=prepare_candidate_pool(cand,args.structure)
    audit_candidate_fold_schedule(cand, out_dir, logger, expected_folds=args.expected_folds, allow_mixed=args.allow_mixed_folds)
    seeds=detect_seeds(cand)
    if not seeds:
        raise RuntimeError('No seed columns detected: expected rank_Sxxxx and score_Sxxxx columns')
    logger.log(f'candidate_pool loaded | source={src} | rows={len(cand):,} | dates={cand.date.nunique():,} | symbols={cand.symbol.nunique():,} | seeds={len(seeds)}')
    seed_rows=expand_seed_local_rows(cand,seeds)
    seed_rows['future_avg_daily_ret']=pd.to_numeric(seed_rows['future_ret_h'],errors='coerce')/2.0
    logger.log(f'seed-local expanded | rows={len(seed_rows):,} | groups={seed_rows.groupby(["date","seed"]).ngroups:,} | local_oracle={int(seed_rows.is_local_oracle.sum()):,}')
    input_diag={
        'candidate_source':src,
        'candidate_rows':int(len(cand)),
        'candidate_dates':int(cand.date.nunique()),
        'candidate_symbols':int(cand.symbol.nunique()),
        'seeds':seeds,
        'seed_local_rows':int(len(seed_rows)),
        'seed_day_groups':int(seed_rows.groupby(['date','seed']).ngroups),
        'local_oracle_rows':int(seed_rows.is_local_oracle.sum()),
    }
    (out_dir/'V20_P11_TRUE_input_diag.json').write_text(json.dumps(input_diag,ensure_ascii=False,indent=2),encoding='utf-8')
    seed_rows[['date','seed','fold_id','symbol','seed_rank','future_ret_h','future_avg_daily_ret','is_local_oracle']].to_csv(out_dir/'V20_P11_TRUE_seed_local_rows_basic.csv',index=False,encoding='utf-8-sig')
    cache_dir=out_dir/'_cache'; cache_dir.mkdir(exist_ok=True)
    cache_file=cache_dir/f'V20_P11_TRUE_kline_features_{args.structure}.parquet'
    min_date=seed_rows['date'].min()-timedelta(days=args.calendar_buffer_days)
    max_date=seed_rows['date'].max()+timedelta(days=args.asof_tolerance_days)
    if cache_file.exists() and not args.force_rebuild_cache:
        logger.log(f'load cached K-line features | {cache_file}')
        feats=pd.read_parquet(cache_file)
    else:
        daily=read_daily_panel(args.duckdb_path,args.daily_table,seed_rows['symbol'].unique(),min_date,max_date,logger)
        feats=build_symbol_features(daily, set(seed_rows['symbol'].unique()), logger)
        try:
            feats.to_parquet(cache_file,index=False)
            logger.log(f'K-line feature cache saved | {cache_file}')
        except Exception as e:
            logger.log(f'WARN parquet cache save failed: {e}')
        del daily; gc.collect()
    merged=merge_features(seed_rows,feats,logger,tolerance_days=args.asof_tolerance_days)
    key_features=['ret_1','ret_3','ret_5','ret_20','limitup_like_1','amount_ratio_1_20','pos_60','pos_180','ma60_ratio','market_positive_ratio']
    rows=[]
    for f in key_features:
        if f in merged.columns:
            rows.append({'feature':f,'nonnull':int(merged[f].notna().sum()),'total':int(len(merged)),'coverage':float(merged[f].notna().mean())})
    cov=pd.DataFrame(rows)
    cov.to_csv(out_dir/'V20_P11_TRUE_key_feature_coverage_diag.csv',index=False,encoding='utf-8-sig')
    low=cov[cov.coverage<0.95] if not cov.empty else pd.DataFrame()
    if len(low)>0 and not args.allow_low_coverage:
        logger.log('WARNING low key feature coverage:\n'+low.to_string(index=False))
        raise RuntimeError('Key K-line feature coverage below 0.95. Use --allow_low_coverage only for diagnostics.')
    if 'close_pos_1' in merged.columns:
        merged['close_pos_1']=merged['close_pos_1'].fillna(0.5)
    merged, base_cols, rel_cols=add_seed_local_relative_features(merged,logger)
    shrink_rules=[x.strip() for x in args.shrink_rules.split(',') if x.strip()]
    shrink_ks=tuple(int(x) for x in args.shrink_ks.split(',') if x.strip())
    stage2_methods=[x.strip() for x in args.stage2_methods.split(',') if x.strip()]
    stage2_top_ns=tuple(int(x) for x in args.stage2_top_ns.split(',') if x.strip())
    portfolio_ns=tuple(int(x) for x in args.portfolio_ns.split(',') if x.strip())
    run_two_stage(merged,out_dir,logger,shrink_rules=shrink_rules,shrink_ks=shrink_ks,stage2_methods=stage2_methods,stage2_top_ns=stage2_top_ns,portfolio_ns=portfolio_ns)
    logger.log('V20_P11_TRUE_TWO_STAGE_SHRINK finished')

if __name__=='__main__':
    main()
