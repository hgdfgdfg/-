from pathlib import Path
from datetime import datetime
class Logger:
    def __init__(self, out_dir):
        self.out_dir=Path(out_dir); self.out_dir.mkdir(parents=True, exist_ok=True)
        (self.out_dir/'logs').mkdir(exist_ok=True)
        self.log_path=self.out_dir/'logs'/'run.log'
    def log(self,msg):
        s=f"[time] {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {msg}"
        print(s, flush=True)
        with open(self.log_path,'a',encoding='utf-8') as f: f.write(s+'\n')
