import zipfile, os, re
from pathlib import Path
import pandas as pd
import numpy as np
from .utils import normalize_symbol_from_parts

def load_candidate_pool(path, structure='W160_60_30'):
    path = str(path)
    if path.lower().endswith('.zip'):
        z = zipfile.ZipFile(path)
        names = z.namelist()
        preferred = [f'{structure}/seed30_candidate_pool.csv', f'30seedensemble/{structure}/seed30_candidate_pool.csv', 'seed30_candidate_pool.csv', '30seedensemble/seed30_candidate_pool.csv']
        target = None
        for p in preferred:
            for n in names:
                if n.replace('\\','/').endswith(p):
                    target = n; break
            if target: break
        if target is None:
            cands = [n for n in names if n.endswith('seed30_candidate_pool.csv')]
            if not cands: raise FileNotFoundError('seed30_candidate_pool.csv not found in zip')
            target = cands[0]
        df = pd.read_csv(z.open(target))
        return df, target
    else:
        p = Path(path)
        if p.is_dir():
            candidates = list(p.rglob('seed30_candidate_pool.csv')) + list(p.rglob('seed*_candidate_pool.csv'))
            if not candidates: raise FileNotFoundError('candidate pool csv not found under directory')
            df = pd.read_csv(candidates[0])
            return df, str(candidates[0])
        df = pd.read_csv(p)
        return df, str(p)

def detect_seeds(df):
    seeds=[]
    for c in df.columns:
        m = re.match(r'^rank_(S\d+)$', c)
        if m:
            s=m.group(1)
            if f'score_{s}' in df.columns:
                seeds.append(s)
    return sorted(seeds)

def prepare_candidate_pool(df, structure=None):
    df=df.copy()
    if 'date' not in df.columns: raise ValueError('candidate_pool missing date')
    if 'symbol' not in df.columns: raise ValueError('candidate_pool missing symbol')
    df['date']=pd.to_datetime(df['date']).dt.normalize()
    df['symbol']=df['symbol'].astype(str).str.lower().str.strip()
    if structure and 'structure' in df.columns:
        sub = df[df['structure'].astype(str)==structure]
        if len(sub)>0: df=sub.copy()
    if 'fold_id' not in df.columns:
        if 'fold' in df.columns:
            df['fold_id']=df['fold'].astype(str)
        else:
            # date chunks as fallback
            ds=sorted(df['date'].dropna().unique())
            import numpy as np
            chunks=np.array_split(ds, 10)
            mp={d:f'fold_{i+1:02d}' for i,ch in enumerate(chunks) for d in ch}
            df['fold_id']=df['date'].map(mp)
    return df.reset_index(drop=True)

def expand_seed_local_rows(cand, seeds):
    rows=[]
    base_cols=['date','symbol','fold_id','future_ret_h','hit16','hit20','big_loss','top10_votes','top5_votes','top3_votes','top1_votes','rank_min','rank_mean','rank_std','score_mean','score_std','zscore_mean','zscore_std','rankpct_mean','rankpct_std']
    for s in seeds:
        rc=f'rank_{s}'; sc=f'score_{s}'; zc=f'z_{s}'; pc=f'pct_{s}'
        cols=[c for c in base_cols if c in cand.columns]+[rc,sc]
        if zc in cand.columns: cols.append(zc)
        if pc in cand.columns: cols.append(pc)
        tmp=cand.loc[cand[rc].notna(), cols].copy()
        tmp['seed']=s
        tmp['seed_rank']=pd.to_numeric(tmp[rc], errors='coerce')
        tmp['seed_score']=pd.to_numeric(tmp[sc], errors='coerce')
        tmp['seed_z']=pd.to_numeric(tmp[zc], errors='coerce') if zc in cand.columns else np.nan
        tmp['seed_pct']=pd.to_numeric(tmp[pc], errors='coerce') if pc in cand.columns else np.nan
        tmp=tmp.drop(columns=[c for c in [rc,sc,zc,pc] if c in tmp.columns])
        rows.append(tmp)
    out=pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()
    out['future_avg_daily_ret']=pd.to_numeric(out['future_ret_h'], errors='coerce')/2.0
    out['is_local_oracle']=0
    idx=out.groupby(['date','seed'])['future_ret_h'].idxmax()
    out.loc[idx, 'is_local_oracle']=1
    # local rank by future return, 1 is best within seed-day
    out['local_future_rank']=out.groupby(['date','seed'])['future_ret_h'].rank(ascending=False, method='first')
    return out.reset_index(drop=True)
