from pathlib import Path
import gc
import numpy as np
import pandas as pd
from tqdm import tqdm


def metric_summary(df, ret_col='portfolio_ret'):
    ret = pd.to_numeric(df[ret_col], errors='coerce')
    n = int(ret.notna().sum())
    return {
        'n_days': n,
        'avg_daily_ret': float(ret.mean()) if n else np.nan,
        'median_daily_ret': float(ret.median()) if n else np.nan,
        'hit16': float((ret >= 0.016).mean()) if n else np.nan,
        'hit20': float((ret >= 0.020).mean()) if n else np.nan,
        'big_loss': float((ret <= -0.05).mean()) if n else np.nan,
        'very_big_loss': float((ret <= -0.08).mean()) if n else np.nan,
        'positive_days': float((ret > 0).mean()) if n else np.nan,
        'min_daily_ret': float(ret.min()) if n else np.nan,
        'max_daily_ret': float(ret.max()) if n else np.nan,
    }


def row_metrics(df, ret_col='future_avg_daily_ret', prefix=''):
    ret = pd.to_numeric(df[ret_col], errors='coerce')
    n = int(ret.notna().sum())
    return {
        prefix+'n': n,
        prefix+'avg_daily_ret': float(ret.mean()) if n else np.nan,
        prefix+'median_daily_ret': float(ret.median()) if n else np.nan,
        prefix+'hit16': float((ret >= 0.016).mean()) if n else np.nan,
        prefix+'hit20': float((ret >= 0.020).mean()) if n else np.nan,
        prefix+'big_loss': float((ret <= -0.05).mean()) if n else np.nan,
        prefix+'very_big_loss': float((ret <= -0.08).mean()) if n else np.nan,
        prefix+'positive': float((ret > 0).mean()) if n else np.nan,
    }


def positive_fold_count(daily):
    if 'fold_id' not in daily.columns or daily.empty:
        return {'positive_fold_count':0,'fold_count':0,'worst_fold_avg_daily_ret':np.nan,'best_fold_avg_daily_ret':np.nan,'fold_avg_daily_ret_std':np.nan}
    bf = daily.groupby('fold_id', sort=False)['portfolio_ret'].mean()
    return {
        'positive_fold_count': int((bf > 0).sum()),
        'fold_count': int(len(bf)),
        'worst_fold_avg_daily_ret': float(bf.min()) if len(bf) else np.nan,
        'best_fold_avg_daily_ret': float(bf.max()) if len(bf) else np.nan,
        'fold_avg_daily_ret_std': float(bf.std(ddof=0)) if len(bf) else np.nan,
    }


def _mean_cols(df, cols):
    use = [c for c in cols if c in df.columns]
    if not use:
        return pd.Series(0.0, index=df.index)
    return df[use].apply(pd.to_numeric, errors='coerce').mean(axis=1).fillna(0.0)


def build_p9_scores(df):
    out = df.copy()
    out['score_short_momentum'] = _mean_cols(out, [
        'ret_1_seedlocal_pct','ret_2_seedlocal_pct','ret_3_seedlocal_pct','ret_5_seedlocal_pct',
        'near_limitup_count_5_seedlocal_pct','limitup_count_5_seedlocal_pct'
    ])
    out['score_breakout'] = _mean_cols(out, [
        'is_high20_break_seedlocal_pct','is_high60_break_seedlocal_pct',
        'close_to_high20_seedlocal_pct','close_to_high60_seedlocal_pct',
        'pos_60_seedlocal_pct','pos_180_seedlocal_pct'
    ])
    out['score_volume'] = _mean_cols(out, [
        'amount_ratio_1_5_seedlocal_pct','amount_ratio_1_20_seedlocal_pct','amount_ratio_3_20_seedlocal_pct',
        'amount_ratio_5_60_seedlocal_pct','amount_rank_20_seedlocal_pct','amount_rank_60_seedlocal_pct'
    ])
    out['score_close_quality'] = _mean_cols(out, [
        'close_pos_1_seedlocal_pct','body_ret_1_seedlocal_pct','upper_shadow_1_seedlocal_low_pct'
    ])
    out['score_trend180'] = _mean_cols(out, [
        'ret_20_seedlocal_pct','ret_60_seedlocal_pct','ret_180_seedlocal_pct',
        'ma60_ratio_seedlocal_pct','ma180_ratio_seedlocal_pct','pos_180_seedlocal_pct'
    ])
    out['score_seed_strength'] = _mean_cols(out, [
        'seed_z_seedlocal_pct','seed_score_seedlocal_pct','seed_rank_seedlocal_low_pct'
    ])
    out['score_kline_combo'] = (0.25*out['score_short_momentum'] + 0.20*out['score_breakout'] +
                                0.20*out['score_volume'] + 0.15*out['score_close_quality'] +
                                0.10*out['score_trend180'] + 0.10*out['score_seed_strength'])
    out['score_kline_trend_volume'] = (0.35*out['score_trend180'] + 0.30*out['score_volume'] +
                                       0.20*out['score_breakout'] + 0.15*out['score_seed_strength'])
    risk_cols = [c for c in ['upper_shadow_1_seedlocal_pct','volatility_20_seedlocal_pct','amp_1_seedlocal_pct','amp_20_seedlocal_pct'] if c in out.columns]
    risk = out[risk_cols].mean(axis=1).fillna(0.0) if risk_cols else 0.0
    out['score_kline_balanced'] = (0.30*out['score_trend180'] + 0.25*out['score_short_momentum'] +
                                   0.20*out['score_volume'] + 0.15*out['score_seed_strength'] +
                                   0.10*out['score_close_quality'] - 0.10*risk)
    return out


def _pct_by_date(pool, col):
    if col not in pool.columns:
        return pd.Series(0.5, index=pool.index)
    return pool.groupby('date', sort=False)[col].rank(pct=True, method='average').fillna(0.5)


def aggregate_stage1_pool(kept, source_label, shrink_rule, shrink_top_k):
    agg = {
        'seed': 'nunique',
        'fold_id': 'first',
        'future_ret_h': 'mean',
        'future_avg_daily_ret': 'mean',
        'is_local_oracle': 'max',
        '_shrink_score': 'mean',
        'seed_rank': 'mean',
    }
    extra = [
        'top10_votes','top5_votes','top3_votes','top1_votes','rank_min','rank_mean','rank_std',
        'score_mean','score_std','zscore_mean','zscore_std','rankpct_mean','rankpct_std',
        'ret_1','ret_3','ret_5','ret_10','ret_20','ret_60','ret_180','pos_60','pos_180',
        'ma20_ratio','ma60_ratio','ma180_ratio','amount_ratio_1_20','amount_ratio_5_60',
        'close_pos_1','upper_shadow_1','score_trend180','score_short_momentum','score_volume',
        'score_kline_combo','score_kline_trend_volume','score_kline_balanced','score_seed_strength'
    ]
    for c in extra:
        if c in kept.columns:
            agg[c] = 'mean'
    pool = kept.groupby(['date','symbol'], as_index=False, sort=False).agg(agg)
    pool = pool.rename(columns={
        'seed': 'retained_votes',
        '_shrink_score': 'mean_shrink_score',
        'is_local_oracle': 'any_seed_local_oracle',
        'seed_rank': 'mean_seed_rank',
    })
    pool['source_label'] = source_label
    pool['shrink_rule'] = shrink_rule
    pool['shrink_top_k'] = shrink_top_k
    pool['zms_score'] = (pool['zscore_mean'].fillna(0) - pool['zscore_std'].fillna(0)) if {'zscore_mean','zscore_std'}.issubset(pool.columns) else 0.0
    trend_cols = [c for c in ['ret_5','ret_10','ret_20','ret_60','ret_180','pos_60','pos_180','ma60_ratio','amount_ratio_5_60'] if c in pool.columns]
    pct_cols=[]
    for c in trend_cols:
        pc=f'{c}_pool_pct'
        pool[pc]=_pct_by_date(pool,c)
        pct_cols.append(pc)
    pool['trend_score'] = pool[pct_cols].mean(axis=1).fillna(0.0) if pct_cols else 0.0
    pool['pool_size'] = pool.groupby('date', sort=False)['symbol'].transform('count')
    return pool


def aggregate_multi_rule_pool(kept_all, shrink_top_k):
    # One row per seed-rule-candidate; count both retained seed votes and seed-rule votes.
    agg = {
        'seed': 'nunique',
        'rule_name': 'nunique',
        'fold_id': 'first',
        'future_ret_h': 'mean',
        'future_avg_daily_ret': 'mean',
        'is_local_oracle': 'max',
        '_shrink_score': 'mean',
        'seed_rank': 'mean',
    }
    extra = [
        'top10_votes','top5_votes','top3_votes','top1_votes','rank_min','rank_mean','rank_std',
        'score_mean','score_std','zscore_mean','zscore_std','rankpct_mean','rankpct_std',
        'ret_1','ret_3','ret_5','ret_10','ret_20','ret_60','ret_180','pos_60','pos_180',
        'ma20_ratio','ma60_ratio','ma180_ratio','amount_ratio_1_20','amount_ratio_5_60',
        'score_trend180','score_short_momentum','score_volume','score_kline_combo','score_kline_trend_volume','score_kline_balanced','score_seed_strength'
    ]
    for c in extra:
        if c in kept_all.columns:
            agg[c] = 'mean'
    # Count seed-rule pair votes separately.
    pair_counts = kept_all.groupby(['date','symbol'], sort=False).size().rename('seed_rule_votes').reset_index()
    pool = kept_all.groupby(['date','symbol'], as_index=False, sort=False).agg(agg)
    pool = pool.merge(pair_counts, on=['date','symbol'], how='left')
    pool = pool.rename(columns={
        'seed': 'retained_votes',
        'rule_name': 'multi_rule_votes',
        '_shrink_score': 'mean_shrink_score',
        'is_local_oracle': 'any_seed_local_oracle',
        'seed_rank': 'mean_seed_rank',
    })
    pool['source_label'] = 'ALL_RULES'
    pool['shrink_rule'] = 'ALL_RULES'
    pool['shrink_top_k'] = shrink_top_k
    pool['zms_score'] = (pool['zscore_mean'].fillna(0) - pool['zscore_std'].fillna(0)) if {'zscore_mean','zscore_std'}.issubset(pool.columns) else 0.0
    trend_cols = [c for c in ['ret_5','ret_10','ret_20','ret_60','ret_180','pos_60','pos_180','ma60_ratio','amount_ratio_5_60'] if c in pool.columns]
    pct_cols=[]
    for c in trend_cols:
        pc=f'{c}_pool_pct'
        pool[pc]=_pct_by_date(pool,c)
        pct_cols.append(pc)
    pool['trend_score'] = pool[pct_cols].mean(axis=1).fillna(0.0) if pct_cols else 0.0
    pool['pool_size'] = pool.groupby('date', sort=False)['symbol'].transform('count')
    return pool


def add_stage2_scores(pool):
    p = pool.copy()
    p['retained_votes_pct'] = _pct_by_date(p, 'retained_votes')
    p['multi_rule_votes_pct'] = _pct_by_date(p, 'multi_rule_votes') if 'multi_rule_votes' in p.columns else 0.5
    p['seed_rule_votes_pct'] = _pct_by_date(p, 'seed_rule_votes') if 'seed_rule_votes' in p.columns else p['retained_votes_pct']
    p['zms_pct'] = _pct_by_date(p, 'zms_score')
    p['trend_pct'] = _pct_by_date(p, 'trend_score')
    p['shrink_pct'] = _pct_by_date(p, 'mean_shrink_score')
    # A
    p['stage2_retained_votes'] = p['retained_votes_pct']
    # B
    p['stage2_multi_rule_votes'] = 0.55*p['seed_rule_votes_pct'] + 0.25*p['multi_rule_votes_pct'] + 0.20*p['retained_votes_pct']
    # C
    p['stage2_retained_votes_zms'] = 0.55*p['retained_votes_pct'] + 0.45*p['zms_pct']
    # D
    p['stage2_retained_votes_kline'] = 0.45*p['retained_votes_pct'] + 0.25*p['trend_pct'] + 0.20*p['zms_pct'] + 0.10*p['shrink_pct']
    # E
    p['stage2_quality_filter_zms'] = 0.35*p['zms_pct'] + 0.30*p['trend_pct'] + 0.20*p['shrink_pct'] + 0.15*p['retained_votes_pct']
    # Cross scores for final portfolio inside stage2 pool.
    p['cross_consensus_score'] = 100.0*p['retained_votes'].fillna(0) + p['mean_shrink_score'].fillna(0) + p['zms_score'].fillna(0)
    p['cross_zms_score'] = p['zms_score'].fillna(0) + 0.05*p['retained_votes'].fillna(0)
    p['cross_stage2_score'] = p[['stage2_retained_votes_zms','stage2_retained_votes_kline','stage2_quality_filter_zms']].mean(axis=1)
    return p


def stage2_select(pool, method, top_n):
    if method not in pool.columns:
        raise ValueError(f'missing stage2 method column: {method}')
    ranked = pool.sort_values(['date', method, 'retained_votes', 'zms_score'], ascending=[True, False, False, False]).copy()
    ranked['_stage2_rank'] = ranked.groupby('date', sort=False)[method].rank(ascending=False, method='first')
    st2 = ranked[ranked['_stage2_rank'] <= top_n].copy()
    st2['stage2_method'] = method
    st2['stage2_top_n'] = top_n
    st2['stage2_pool_size'] = st2.groupby('date', sort=False)['symbol'].transform('count')
    return st2


def oracle_summary(pool, prefix_fields):
    if pool.empty:
        return {**prefix_fields, **metric_summary(pd.DataFrame({'portfolio_ret':[]}), 'portfolio_ret')}
    idx = pool.groupby('date', sort=False)['future_avg_daily_ret'].idxmax()
    oracle = pool.loc[idx].copy().rename(columns={'future_avg_daily_ret':'portfolio_ret'})
    summ = metric_summary(oracle, 'portfolio_ret')
    summ.update(prefix_fields)
    summ.update({
        'avg_pool_size': float(pool.groupby('date').size().mean()) if not pool.empty else np.nan,
        'avg_oracle_retained_votes': float(oracle['retained_votes'].mean()) if 'retained_votes' in oracle.columns else np.nan,
        'median_oracle_retained_votes': float(oracle['retained_votes'].median()) if 'retained_votes' in oracle.columns else np.nan,
    })
    return summ


def daily_portfolio(stage2_pool, cross_score, top_n, weight_mode):
    ranked = stage2_pool.sort_values(['date', cross_score, 'retained_votes', 'zms_score'], ascending=[True, False, False, False]).copy()
    ranked['_final_rank'] = ranked.groupby('date', sort=False)[cross_score].rank(ascending=False, method='first')
    sel = ranked[ranked['_final_rank'] <= top_n].copy()
    if sel.empty:
        return pd.DataFrame()
    ret = pd.to_numeric(sel['future_avg_daily_ret'], errors='coerce').fillna(0.0)
    if weight_mode == 'vote':
        sel['_w_raw'] = pd.to_numeric(sel['retained_votes'], errors='coerce').fillna(1.0).clip(lower=1.0)
    elif weight_mode == 'sqrt_vote':
        sel['_w_raw'] = np.sqrt(pd.to_numeric(sel['retained_votes'], errors='coerce').fillna(1.0).clip(lower=1.0))
    else:
        sel['_w_raw'] = 1.0
    sel['_w_sum'] = sel.groupby('date', sort=False)['_w_raw'].transform('sum').replace(0, np.nan)
    sel['_w'] = sel['_w_raw'] / sel['_w_sum']
    sel['_wret'] = sel['_w'] * ret
    daily = sel.groupby('date', sort=False).agg(
        portfolio_ret=('_wret','sum'),
        n_selected=('symbol','count'),
        fold_id=('fold_id','first'),
        top_symbol=('symbol','first'),
        top_retained_votes=('retained_votes','first'),
        avg_selected_votes=('retained_votes','mean'),
        max_selected_ret=('future_avg_daily_ret','max'),
        min_selected_ret=('future_avg_daily_ret','min'),
    ).reset_index()
    daily['cross_score'] = cross_score
    daily['top_n'] = top_n
    daily['weight_mode'] = weight_mode
    return daily


def run_two_stage(df, out_dir, logger, shrink_rules=None, shrink_ks=(3,5), stage2_methods=None, stage2_top_ns=(8,10,12,15,20), portfolio_ns=(1,2,3,5), weight_modes=('equal','vote','sqrt_vote')):
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    df = build_p9_scores(df)
    if shrink_rules is None:
        shrink_rules = ['score_kline_combo','score_kline_trend_volume','score_short_momentum','score_trend180','score_kline_balanced','score_seed_strength']
    if stage2_methods is None:
        stage2_methods = ['stage2_retained_votes','stage2_multi_rule_votes','stage2_retained_votes_zms','stage2_retained_votes_kline','stage2_quality_filter_zms']
    cross_scores = ['cross_zms_score','cross_consensus_score','cross_stage2_score']

    # Save reference metrics.
    ref = [
        {'name':'seed_original_rank1', **row_metrics(df[df['seed_rank']==1], 'future_avg_daily_ret')},
        {'name':'seed_local_oracle_top10_upper_bound', **row_metrics(df[df['is_local_oracle']==1], 'future_avg_daily_ret')},
    ]
    pd.DataFrame(ref).to_csv(out_dir/'V20_P11_TRUE_reference_metric_summary.csv', index=False, encoding='utf-8-sig')

    stage1_summaries = []
    stage1_oracles = []
    stage2_oracles = []
    portfolio_summaries = []
    byfold_frames = []
    daily_frames = []
    stage2_pool_frames = []

    logger.log(f'TRUE P11 two-stage shrink start | shrink_rules={shrink_rules} | shrink_ks={shrink_ks} | stage2_methods={stage2_methods} | stage2_top_ns={stage2_top_ns}')

    # Precompute stage1 kept per rule/k.
    for k in tqdm(shrink_ks, desc='stage1_k'):
        kept_by_rule = []
        for rule in tqdm(shrink_rules, desc=f'stage1_rules_k{k}', leave=False):
            if rule not in df.columns:
                logger.log(f'skip missing stage1 rule: {rule}')
                continue
            use_cols = ['date','seed','fold_id','symbol','seed_rank','future_ret_h','future_avg_daily_ret','is_local_oracle',rule]
            extra = [c for c in df.columns if c in [
                'top10_votes','top5_votes','top3_votes','top1_votes','rank_min','rank_mean','rank_std',
                'score_mean','score_std','zscore_mean','zscore_std','rankpct_mean','rankpct_std',
                'ret_1','ret_3','ret_5','ret_10','ret_20','ret_60','ret_180','pos_60','pos_180',
                'ma20_ratio','ma60_ratio','ma180_ratio','amount_ratio_1_20','amount_ratio_5_60',
                'close_pos_1','upper_shadow_1','score_trend180','score_short_momentum','score_volume',
                'score_kline_combo','score_kline_trend_volume','score_kline_balanced','score_seed_strength'
            ]]
            for c in extra:
                if c not in use_cols: use_cols.append(c)
            tmp = df[use_cols].copy()
            tmp['_shrink_score'] = pd.to_numeric(tmp[rule], errors='coerce').fillna(-999.0)
            tmp['_shrink_rank'] = tmp.groupby(['date','seed'], sort=False)['_shrink_score'].rank(ascending=False, method='first')
            kept = tmp[tmp['_shrink_rank'] <= k].copy()
            kept['rule_name'] = rule
            kept_by_rule.append(kept)
            cov = kept.groupby(['date','seed'], sort=False)['is_local_oracle'].max().mean()
            top1 = tmp[tmp['_shrink_rank']==1]
            ss = {'shrink_rule':rule, 'shrink_top_k':k, 'local_oracle_coverage':float(cov), 'avg_kept_per_seed':float(kept.groupby(['date','seed']).size().mean())}
            ss.update(row_metrics(top1, 'future_avg_daily_ret', prefix='shrink_top1_'))
            stage1_summaries.append(ss)
            pool = aggregate_stage1_pool(kept, source_label=rule, shrink_rule=rule, shrink_top_k=k)
            stage1_oracles.append(oracle_summary(pool, {'source_label':rule,'shrink_rule':rule,'shrink_top_k':k,'stage':'stage1_retained_pool'}))
            # A/C/D/E on per-rule stage1 pool.
            scored_pool = add_stage2_scores(pool)
            for method in [m for m in stage2_methods if m != 'stage2_multi_rule_votes']:
                for stn in stage2_top_ns:
                    st2 = stage2_select(scored_pool, method, stn)
                    pref = {'source_label':rule,'shrink_rule':rule,'shrink_top_k':k,'stage2_method':method,'stage2_top_n':stn}
                    stage2_oracles.append(oracle_summary(st2, {**pref,'stage':'stage2_pool'}))
                    if len(stage2_pool_frames) < 80:  # keep file size moderate; still enough diagnostics
                        stage2_pool_frames.append(st2.assign(**pref))
                    for cs in cross_scores:
                        for pn in portfolio_ns:
                            for wm in weight_modes:
                                if pn == 1 and wm != 'equal':
                                    continue
                                daily = daily_portfolio(st2, cs, pn, wm)
                                if daily.empty:
                                    continue
                                daily = daily.assign(**pref)
                                daily_frames.append(daily)
                                summ = metric_summary(daily, 'portfolio_ret')
                                summ.update(pref)
                                summ.update({'cross_score':cs,'top_n':pn,'weight_mode':wm,'avg_selected':float(daily['n_selected'].mean()),'avg_stage2_pool_size':float(st2.groupby('date').size().mean()),'avg_top_votes':float(daily['top_retained_votes'].mean()),'avg_selected_votes':float(daily['avg_selected_votes'].mean())})
                                summ.update(positive_fold_count(daily))
                                portfolio_summaries.append(summ)
                                bf = daily.groupby('fold_id', sort=False).apply(lambda g: pd.Series(metric_summary(g,'portfolio_ret'))).reset_index()
                                bf = bf.assign(**pref, cross_score=cs, top_n=pn, weight_mode=wm)
                                byfold_frames.append(bf)
            del tmp, kept, pool, scored_pool
            gc.collect()
        # B multi-rule votes per k, combine all rules.
        if kept_by_rule:
            all_kept = pd.concat(kept_by_rule, ignore_index=True)
            pool = aggregate_multi_rule_pool(all_kept, shrink_top_k=k)
            stage1_oracles.append(oracle_summary(pool, {'source_label':'ALL_RULES','shrink_rule':'ALL_RULES','shrink_top_k':k,'stage':'stage1_retained_pool_multi_rule'}))
            scored_pool = add_stage2_scores(pool)
            for method in stage2_methods:
                for stn in stage2_top_ns:
                    st2 = stage2_select(scored_pool, method, stn)
                    pref = {'source_label':'ALL_RULES','shrink_rule':'ALL_RULES','shrink_top_k':k,'stage2_method':method,'stage2_top_n':stn}
                    stage2_oracles.append(oracle_summary(st2, {**pref,'stage':'stage2_pool'}))
                    if len(stage2_pool_frames) < 120:
                        stage2_pool_frames.append(st2.assign(**pref))
                    for cs in cross_scores:
                        for pn in portfolio_ns:
                            for wm in weight_modes:
                                if pn == 1 and wm != 'equal':
                                    continue
                                daily = daily_portfolio(st2, cs, pn, wm)
                                if daily.empty:
                                    continue
                                daily = daily.assign(**pref)
                                daily_frames.append(daily)
                                summ = metric_summary(daily, 'portfolio_ret')
                                summ.update(pref)
                                summ.update({'cross_score':cs,'top_n':pn,'weight_mode':wm,'avg_selected':float(daily['n_selected'].mean()),'avg_stage2_pool_size':float(st2.groupby('date').size().mean()),'avg_top_votes':float(daily['top_retained_votes'].mean()),'avg_selected_votes':float(daily['avg_selected_votes'].mean())})
                                summ.update(positive_fold_count(daily))
                                portfolio_summaries.append(summ)
                                bf = daily.groupby('fold_id', sort=False).apply(lambda g: pd.Series(metric_summary(g,'portfolio_ret'))).reset_index()
                                bf = bf.assign(**pref, cross_score=cs, top_n=pn, weight_mode=wm)
                                byfold_frames.append(bf)
            del all_kept, pool, scored_pool, kept_by_rule
            gc.collect()
        # checkpoint by k
        pd.DataFrame(stage1_summaries).to_csv(out_dir/'V20_P11_TRUE_stage1_seedlocal_shrink_summary.csv', index=False, encoding='utf-8-sig')
        pd.DataFrame(stage1_oracles).to_csv(out_dir/'V20_P11_TRUE_stage1_retained_pool_oracle_summary.csv', index=False, encoding='utf-8-sig')
        pd.DataFrame(stage2_oracles).to_csv(out_dir/'V20_P11_TRUE_stage2_pool_oracle_summary.csv', index=False, encoding='utf-8-sig')
        pd.DataFrame(portfolio_summaries).to_csv(out_dir/'V20_P11_TRUE_consensus_portfolio_summary.csv', index=False, encoding='utf-8-sig')
        logger.log(f'checkpoint saved after shrink_top_k={k} | portfolio_summaries={len(portfolio_summaries)} | stage2_oracles={len(stage2_oracles)}')

    if daily_frames:
        pd.concat(daily_frames, ignore_index=True).to_csv(out_dir/'V20_P11_TRUE_consensus_portfolio_daily.csv', index=False, encoding='utf-8-sig')
    if byfold_frames:
        pd.concat(byfold_frames, ignore_index=True).to_csv(out_dir/'V20_P11_TRUE_consensus_portfolio_by_fold.csv', index=False, encoding='utf-8-sig')
    if stage2_pool_frames:
        pd.concat(stage2_pool_frames, ignore_index=True).to_csv(out_dir/'V20_P11_TRUE_stage2_pool_sample.csv', index=False, encoding='utf-8-sig')
    logger.log('TRUE P11 two-stage shrink finished')
