V20_P8FOLD_P11_FUSION_30SEED_19FOLD_FIX3

目的：修复旧 10fold 与新 19fold 续跑混在同一 output_dir 时，fold_11~fold_19 与 fold_02~fold_10 日期段重复的问题。

核心修复：
1. 默认 output_dir 改为 runs/V20_P8_19FOLD_CLEAN_FIX3，避免复用旧 runs/V20_P8。
2. P8 每个 fold 都写 date_range_check.json，并生成 V20_P8_EXPECTED_FOLD_SCHEDULE_LAST.csv。
3. skip completed fold 前会校验已有 fold 的真实 train/valid/test 日期；日期不一致会自动移动到 _stale_mixed_fold_backup 后重跑。
4. embedding cache 加入日期指纹，避免 fold_01 名字相同但日期不同导致误读旧缓存。
5. ensemble 前严格审计所有 seed/exp 的 19 个 fold 日期一致性；发现重复日期段或缺 fold 直接报错。
6. P11 输入 candidate pool 再次审计 fold 日期段；默认要求 19 个唯一、按编号递增的时间 fold。

推荐一键运行：
run_v20_p8fold_p11_fusion_clean19_all.bat

等价 CMD：
python run_v20_p8fold_p11_fusion.py ^
  --mode all ^
  --config conf/v20_p8fold_p11_base.yaml ^
  --experiments conf/v20_p8fold_p11_experiments.csv ^
  --structure W160_60_30 ^
  --recent_folds 19 ^
  --output_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (3)/runs/V20_P8_19FOLD_CLEAN_FIX3" ^
  --db_path "C:/Users/魏儒翌/Desktop/新建文件夹 (3)/data/ashare.duckdb" ^
  --daily_table stock_daily_mainboard ^
  --p11_out_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (3)/V20_P11_TRUE_TWO_STAGE_SHRINK_19FOLD_CLEAN_FIX3_out" ^
  --p11_allow_low_coverage

跑完先看这些审计文件：
- runs/V20_P8_19FOLD_CLEAN_FIX3/ensemble/V20_P8_ensemble_clean_19fold_schedule.csv
- V20_P11_TRUE_TWO_STAGE_SHRINK_19FOLD_CLEAN_FIX3_out/V20_P11_TRUE_candidate_fold_schedule_audit.csv
- V20_P11_TRUE_TWO_STAGE_SHRINK_19FOLD_CLEAN_FIX3_out/V20_P11_TRUE_candidate_fold_duplicate_ranges.csv

正常条件：
- fold_id 数 = 19
- unique date ranges = 19
- duplicate ranges = 0
