# V20_P11_TRUE_TWO_STAGE_SHRINK

真正二层缩池版本：

1. 每个 seed top10 使用 P9/P10 K线规则缩到 top3/top5。
2. 跨 seed retained pool 再按 stage2 method 缩到 top8/top10/top12/top15/top20。
3. 在 stage2 pool 内用 cross_zms / cross_consensus / cross_stage2 做 top1/top2/top3/top5 portfolio。

关键输出字段包含：`stage2_method`, `stage2_top_n`, `avg_stage2_pool_size`。

## CMD

```bat
cd /d "C:\Users\魏儒翌\Desktop\新建文件夹 (2)\V20_P11_TRUE_TWO_STAGE_SHRINK_build"
python run_v20_p11_true_two_stage_shrink.py --ensemble_zip "C:\Users\魏儒翌\Desktop\V20_P8_SEED30_ensemble.zip" --duckdb_path "C:\Users\魏儒翌\Desktop\新建文件夹 (3)\data\ashare.duckdb" --out_dir "C:\Users\魏儒翌\Desktop\新建文件夹 (3)\V20_P11_TRUE_TWO_STAGE_SHRINK_out" --daily_table stock_daily_mainboard --structure W160_60_30 --allow_low_coverage --force_rebuild_cache
```

## 主要输出

- `V20_P11_TRUE_stage1_seedlocal_shrink_summary.csv`
- `V20_P11_TRUE_stage1_retained_pool_oracle_summary.csv`
- `V20_P11_TRUE_stage2_pool_oracle_summary.csv`
- `V20_P11_TRUE_consensus_portfolio_summary.csv`
- `V20_P11_TRUE_consensus_portfolio_by_fold.csv`
- `V20_P11_TRUE_consensus_portfolio_daily.csv`
- `V20_P11_TRUE_stage2_pool_sample.csv`
