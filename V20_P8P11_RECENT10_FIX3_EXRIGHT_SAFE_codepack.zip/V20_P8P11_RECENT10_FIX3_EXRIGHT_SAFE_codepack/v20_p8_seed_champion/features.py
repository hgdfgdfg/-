import re
import numpy as np
import pandas as pd
from tqdm import tqdm
from .data import normalize_symbol

def read_daily_panel(duckdb_path, daily_table, cand, calendar_buffer_days, logger):
    import duckdb
    date_min=pd.to_datetime(cand["date"]).min()-pd.Timedelta(days=int(calendar_buffer_days))
    date_max=pd.to_datetime(cand["date"]).max()+pd.Timedelta(days=5)
    symbols=set(cand["symbol"].dropna().unique())
    logger.log(f"read DuckDB | db={duckdb_path} | table={daily_table} | date={date_min.date()}..{date_max.date()}")
    con=duckdb.connect(duckdb_path, read_only=True)
    df=con.execute(f"""
        SELECT symbol as raw_symbol, code as raw_code, market as raw_market, date, open, high, low, close, volume, amount
        FROM {daily_table}
        WHERE date >= ? AND date <= ?
    """,[date_min,date_max]).fetch_df()
    con.close()
    def make_sym(row):
        for col in ["raw_symbol","raw_code"]:
            ns=normalize_symbol(row.get(col))
            if ns and re.match(r"^(sh|sz|bj)\d{6}$",ns): return ns
        m=str(row.get("raw_market","")).strip().lower()
        c=re.sub(r"\D","",str(row.get("raw_code",""))).zfill(6)[-6:]
        if m in ("sh","sz","bj") and re.match(r"^\d{6}$",c): return m+c
        return normalize_symbol(row.get("raw_symbol"))
    df["symbol"]=df.apply(make_sym, axis=1)
    df["date"]=pd.to_datetime(df["date"]).dt.normalize()
    before=len(df)
    df=df[df["symbol"].isin(symbols)].copy()
    logger.log(f"daily rows read={before:,} | after symbol filter={len(df):,} | symbols matched={df['symbol'].nunique()}/{len(symbols)}")
    return df.dropna(subset=["date","symbol","close"]).sort_values(["symbol","date"]).reset_index(drop=True)

def build_180d_features(daily, logger):
    rows=[]
    for sym,g in tqdm(daily.groupby("symbol"), desc="build_180d_features"):
        g=g.sort_values("date").reset_index(drop=True)
        close=g["close"].astype(float); high=g["high"].astype(float); low=g["low"].astype(float); amount=g["amount"].astype(float)
        prev=close.shift(1)
        feat=pd.DataFrame({"date":g["date"].to_numpy(),"symbol":sym})
        for w in [5,10,20,60,120,180]:
            feat[f"ret_{w}"]=(prev/close.shift(w+1)-1.0).to_numpy()
        for w in [20,60,120,180]:
            rh=high.shift(1).rolling(w, min_periods=max(5,w//3)).max()
            rl=low.shift(1).rolling(w, min_periods=max(5,w//3)).min()
            feat[f"pos_{w}"]=((prev-rl)/(rh-rl).replace(0,np.nan)).clip(0,1).to_numpy()
            ma=close.shift(1).rolling(w,min_periods=max(5,w//3)).mean()
            feat[f"ma{w}_ratio"]=(prev/ma-1.0).to_numpy()
            feat[f"volatility_{w}"]=close.pct_change().shift(1).rolling(w,min_periods=max(5,w//3)).std().to_numpy()
            feat[f"amp_{w}"]=(high.shift(1).rolling(w,min_periods=max(5,w//3)).max()/low.shift(1).rolling(w,min_periods=max(5,w//3)).min()-1.0).to_numpy()
        feat["amount_ratio_5_60"]=(amount.shift(1).rolling(5,min_periods=3).mean()/amount.shift(1).rolling(60,min_periods=20).mean()).to_numpy()
        feat["amount_ratio_20_180"]=(amount.shift(1).rolling(20,min_periods=8).mean()/amount.shift(1).rolling(180,min_periods=60).mean()).to_numpy()
        rows.append(feat)
    return pd.concat(rows, ignore_index=True)

def merge_features_to_candidates(cand, feats, logger, tolerance_days=10):
    cand=cand.copy(); feats=feats.copy()
    cand["date"]=pd.to_datetime(cand["date"]).dt.normalize()
    feats["date"]=pd.to_datetime(feats["date"]).dt.normalize()
    out=cand.merge(feats,on=["date","symbol"],how="left")
    logger.log(f"exact merge pos_180 nonnull={out.get('pos_180',pd.Series(dtype=float)).notna().sum()}/{len(out):,}")
    if "pos_180" in out.columns and out["pos_180"].notna().mean()>0.95:
        return out
    parts=[]; tol=pd.Timedelta(days=int(tolerance_days)).value
    for sym,cg in tqdm(cand.groupby("symbol"), desc="merge_asof"):
        fg=feats[feats["symbol"]==sym].drop(columns=["symbol"]).sort_values("date").copy()
        cg=cg.sort_values("date").copy()
        if fg.empty:
            parts.append(cg); continue
        cg["_date_ns"]=pd.to_datetime(cg["date"]).astype("int64")
        fg["_date_ns"]=pd.to_datetime(fg["date"]).astype("int64")
        tmp=pd.merge_asof(cg,fg.drop(columns=["date"]),on="_date_ns",direction="backward",tolerance=tol).drop(columns=["_date_ns"])
        parts.append(tmp)
    out=pd.concat(parts,ignore_index=True)
    logger.log(f"asof merge pos_180 nonnull={out.get('pos_180',pd.Series(dtype=float)).notna().sum()}/{len(out):,}")
    return out

def add_relative_features(df):
    out=df.copy()
    if {"zscore_mean","zscore_std"}.issubset(out.columns): out["zscore_mean_minus_std"]=out["zscore_mean"]-out["zscore_std"]
    if {"score_mean","score_std"}.issubset(out.columns): out["score_mean_minus_std"]=out["score_mean"]-out["score_std"]
    if {"rankpct_mean","rankpct_std"}.issubset(out.columns): out["rankpct_mean_minus_std"]=out["rankpct_mean"]-out["rankpct_std"]
    base=["ret_20","ret_60","ret_180","pos_60","pos_180","ma60_ratio","amount_ratio_5_60","volatility_60","amp_20","zscore_mean","zscore_std","score_mean","score_std","rankpct_mean","rankpct_std"]
    for c in base:
        if c in out.columns:
            out[f"{c}_day_pct"]=out.groupby("date")[c].rank(pct=True,method="average")
            mu=out.groupby("date")[c].transform("mean")
            sd=out.groupby("date")[c].transform("std").replace(0,np.nan)
            out[f"{c}_day_z"]=((out[c]-mu)/sd).fillna(0)
    return out
