import os, argparse, json, gc
import pandas as pd
from .utils import Logger, ensure_dir
from .data import extract_p5_files, load_candidate_pool
from .features import read_daily_panel, build_180d_features, merge_features_to_candidates, add_relative_features
from .portfolio import build_seed_champions, aggregate_champions, add_cross_scores, pick_portfolio, summarize_daily

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--ensemble_zip", required=True)
    ap.add_argument("--duckdb_path", required=True)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--daily_table", default="stock_daily_mainboard")
    ap.add_argument("--structure", default="W160_60_30")
    ap.add_argument("--calendar_buffer_days", type=int, default=520)
    ap.add_argument("--force_rebuild_cache", action="store_true")
    ap.add_argument("--asof_tolerance_days", type=int, default=10)
    args=ap.parse_args()
    out_dir=ensure_dir(args.out_dir); logger=Logger(out_dir)
    logger.log("V20_P8_SEED_CHAMPION_PORTFOLIO start")
    logger.log(json.dumps(vars(args),ensure_ascii=False,indent=2))
    work=ensure_dir(os.path.join(out_dir,"_work"))
    cand_path=extract_p5_files(args.ensemble_zip,work,logger)
    cand=load_candidate_pool(cand_path,args.structure,logger)
    cache=ensure_dir(os.path.join(out_dir,"_cache"))
    cand_cache=os.path.join(cache,f"V20_P8_candidate_features_{args.structure}.csv")
    feat_cache=os.path.join(cache,f"V20_P8_180d_features_{args.structure}.csv")
    if os.path.exists(cand_cache) and not args.force_rebuild_cache:
        cf=pd.read_csv(cand_cache,parse_dates=["date"])
        logger.log(f"load candidate feature cache: {cand_cache}")
    else:
        if os.path.exists(feat_cache) and not args.force_rebuild_cache:
            feats=pd.read_csv(feat_cache,parse_dates=["date"])
            logger.log(f"load 180d feature cache: {feat_cache}")
        else:
            daily=read_daily_panel(args.duckdb_path,args.daily_table,cand,args.calendar_buffer_days,logger)
            feats=build_180d_features(daily,logger)
            feats.to_csv(feat_cache,index=False,encoding="utf-8-sig")
            del daily; gc.collect()
        cf=merge_features_to_candidates(cand,feats,logger,args.asof_tolerance_days)
        cov=[]
        for c in ["ret_20","ret_60","pos_60","pos_180","ma60_ratio","amount_ratio_5_60"]:
            if c in cf.columns: cov.append({"feature":c,"nonnull":int(cf[c].notna().sum()),"total":len(cf),"coverage":float(cf[c].notna().mean())})
        pd.DataFrame(cov).to_csv(os.path.join(out_dir,"V20_P8_feature_coverage_diag.csv"),index=False,encoding="utf-8-sig")
        logger.log("feature coverage:\n"+pd.DataFrame(cov).to_string(index=False))
        cf=add_relative_features(cf)
        cf.to_csv(cand_cache,index=False,encoding="utf-8-sig")
    logger.log(f"candidate features ready | rows={len(cf):,} | cols={len(cf.columns)}")

    champions,seeds=build_seed_champions(cf)
    logger.log(f"seed champions | rows={len(champions):,} | seeds={len(seeds)} | dates={champions['date'].nunique()}")
    champions.to_csv(os.path.join(out_dir,"V20_P8_seed_champions_daily.csv"),index=False,encoding="utf-8-sig")
    pool=aggregate_champions(champions)
    pool=add_cross_scores(pool)
    pool.to_csv(os.path.join(out_dir,"V20_P8_champion_pool_daily.csv"),index=False,encoding="utf-8-sig")
    logger.log(f"champion pool | rows={len(pool):,} | avg unique/day={len(pool)/pool['date'].nunique():.2f}")

    dist=pool.groupby("date").agg(unique_champions=("symbol","count"),max_votes=("champion_votes","max"),mean_votes=("champion_votes","mean"),top_vote_gap=("champion_votes",lambda s:s.sort_values(ascending=False).iloc[0]-(s.sort_values(ascending=False).iloc[1] if len(s)>1 else 0))).reset_index()
    dist.to_csv(os.path.join(out_dir,"V20_P8_champion_votes_distribution.csv"),index=False,encoding="utf-8-sig")

    daily_list=[]; sums=[]; bfs=[]
    for sc in ["cross_consensus_score","cross_consensus_trend_score","cross_safe_score","cross_zms_score"]:
        for topn in [1,2,3,5]:
            for wm in ["equal","vote","sqrt_vote"]:
                d=pick_portfolio(pool,sc,topn,wm)
                strat=f"{sc}__top{topn}__{wm}"
                d["strategy"]=strat
                daily_list.append(d)
                sums.append(summarize_daily(d,strat))
                bf=d.groupby("fold_id").agg(n_days=("date","count"),avg_daily_ret=("portfolio_avg_daily_ret","mean"),hit20=("portfolio_avg_daily_ret",lambda s:(s>=0.02).mean()),big_loss=("portfolio_avg_daily_ret",lambda s:(s<=-0.05).mean()),positive_days=("portfolio_avg_daily_ret",lambda s:(s>0).mean()),worst_day=("portfolio_avg_daily_ret","min")).reset_index()
                bf["strategy"]=strat
                bfs.append(bf)
    daily_all=pd.concat(daily_list,ignore_index=True)
    summary=pd.DataFrame(sums).sort_values(["avg_daily_ret","big_loss"],ascending=[False,True])
    byfold=pd.concat(bfs,ignore_index=True)
    daily_all.to_csv(os.path.join(out_dir,"V20_P8_portfolio_daily.csv"),index=False,encoding="utf-8-sig")
    summary.to_csv(os.path.join(out_dir,"V20_P8_portfolio_summary.csv"),index=False,encoding="utf-8-sig")
    byfold.to_csv(os.path.join(out_dir,"V20_P8_portfolio_by_fold.csv"),index=False,encoding="utf-8-sig")
    logger.log("top summary:\n"+summary.head(20).to_string(index=False))
    oracle=pool.sort_values("future_avg_daily_ret",ascending=False).groupby("date").head(1)
    oracle.to_csv(os.path.join(out_dir,"V20_P8_champion_pool_oracle_top1.csv"),index=False,encoding="utf-8-sig")
    logger.log("V20_P8_SEED_CHAMPION_PORTFOLIO done")

if __name__=="__main__":
    main()
