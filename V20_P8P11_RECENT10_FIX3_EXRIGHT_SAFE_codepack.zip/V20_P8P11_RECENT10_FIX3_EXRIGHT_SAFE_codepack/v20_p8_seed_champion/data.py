import os, re, zipfile
import pandas as pd
import numpy as np

def _find_member(zf, names):
    members=zf.namelist()
    for n in names:
        for m in members:
            if m.endswith(n): return m
    return None

def extract_p5_files(ensemble_zip, work_dir, logger):
    os.makedirs(work_dir, exist_ok=True)
    names=["seed30_candidate_pool.csv","seed20_candidate_pool.csv","seed10_candidate_pool.csv","candidate_pool.csv"]
    with zipfile.ZipFile(ensemble_zip,"r") as zf:
        m=_find_member(zf,names)
        if m is None: raise FileNotFoundError("candidate_pool csv not found in zip")
        dst=os.path.join(work_dir, os.path.basename(m))
        with zf.open(m) as src, open(dst,"wb") as f: f.write(src.read())
        logger.log(f"extracted candidate_pool: {m} -> {dst}")
    return dst

def normalize_symbol(s):
    if pd.isna(s): return None
    x=str(s).strip().lower().replace(".","")
    m=re.match(r"^([a-z]{2})(\d{6})$",x)
    if m: return m.group(1)+m.group(2)
    m=re.match(r"^(\d{6})(sh|sz|bj)$",x)
    if m: return m.group(2)+m.group(1)
    if re.match(r"^\d{6}$",x):
        if x.startswith(("60","68","90")): return "sh"+x
        if x.startswith(("00","30","20")): return "sz"+x
        if x.startswith(("43","83","87")): return "bj"+x
    return x

def load_candidate_pool(path, structure, logger):
    df=pd.read_csv(path)
    if "structure" in df.columns:
        df=df[df["structure"].astype(str)==str(structure)].copy()
    if "trade_date" in df.columns and "date" not in df.columns:
        df["date"]=df["trade_date"]
    if "date" not in df.columns: raise ValueError("candidate_pool needs date/trade_date")
    if "symbol" not in df.columns: raise ValueError("candidate_pool needs symbol")
    df["date"]=pd.to_datetime(df["date"]).dt.normalize()
    df["symbol"]=df["symbol"].map(normalize_symbol)
    if "fold_id" not in df.columns:
        if "fold" in df.columns:
            df["fold_id"]=df["fold"].astype(str)
        else:
            dates=sorted(df["date"].dropna().unique())
            chunks=np.array_split(dates,15)
            mp={}
            for i,ch in enumerate(chunks,1):
                for d in ch: mp[pd.Timestamp(d)]=f"fold_{i:02d}"
            df["fold_id"]=df["date"].map(mp)
    logger.log(f"candidate_pool loaded | rows={len(df):,} | dates={df['date'].nunique()} | symbols={df['symbol'].nunique()}")
    return df

def detect_seed_ids(df):
    seeds=set()
    for c in df.columns:
        m=re.match(r"rank_S(\d+)$",c)
        if m: seeds.add(m.group(1))
        m=re.match(r"rank_(\d+)$",c)
        if m: seeds.add(m.group(1))
    return sorted(seeds)

def seed_col(df, kind, seed):
    for c in [f"{kind}_S{seed}",f"{kind}_{seed}",f"{kind}S{seed}"]:
        if c in df.columns: return c
    return None
