import os
from datetime import datetime

class Logger:
    def __init__(self, out_dir):
        self.out_dir=out_dir
        os.makedirs(os.path.join(out_dir,"logs"), exist_ok=True)
        self.path=os.path.join(out_dir,"logs","run.log")
    def log(self,msg):
        s=f"[time] {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {msg}"
        print(s, flush=True)
        with open(self.path,"a",encoding="utf-8") as f: f.write(s+"\n")

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)
    return p
