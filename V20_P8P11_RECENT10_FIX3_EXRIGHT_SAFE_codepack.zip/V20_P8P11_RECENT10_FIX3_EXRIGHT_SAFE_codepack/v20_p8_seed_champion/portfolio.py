import numpy as np
import pandas as pd
from .data import detect_seed_ids, seed_col

def build_seed_champions(cand):
    seeds=detect_seed_ids(cand)
    rows=[]
    for seed in seeds:
        rc=seed_col(cand,"rank",seed); sc=seed_col(cand,"score",seed); zc=seed_col(cand,"z",seed); pc=seed_col(cand,"pct",seed)
        if rc is None: continue
        sub=cand[cand[rc].notna()].copy()
        sub["_seed_rank"]=pd.to_numeric(sub[rc],errors="coerce")
        idx=sub.sort_values(["date","_seed_rank"]).groupby("date",sort=False).head(1).index
        ch=sub.loc[idx].copy()
        ch["seed"]=seed
        ch["seed_score"]=pd.to_numeric(ch[sc],errors="coerce") if sc else np.nan
        ch["seed_z"]=pd.to_numeric(ch[zc],errors="coerce") if zc else np.nan
        ch["seed_pct"]=pd.to_numeric(ch[pc],errors="coerce") if pc else np.nan
        rows.append(ch)
    if not rows: raise ValueError("No seed champion rows built")
    return pd.concat(rows,ignore_index=True), seeds

def aggregate_champions(ch):
    agg={
        "seed":lambda x:"|".join(sorted(map(str,x))),
        "seed_score":"mean","seed_z":"mean","seed_pct":"mean",
        "future_ret_h":"first","future_avg_daily_ret":"first","fold_id":"first"
    }
    for c in ["zscore_mean","zscore_std","score_mean","score_std","rankpct_mean","rankpct_std","zscore_mean_minus_std","score_mean_minus_std","rankpct_mean_minus_std","ret_20","ret_60","ret_180","pos_60","pos_180","ma60_ratio","amount_ratio_5_60","volatility_60","amp_20"]:
        if c in ch.columns: agg[c]="first"
    g=ch.groupby(["date","symbol"],as_index=False).agg(agg)
    g["champion_votes"]=g["seed"].astype(str).str.count(r"\|")+1
    return g

def add_cross_scores(p):
    p=p.copy()
    for c in ["ret_20","ret_60","ret_180","pos_180","ma60_ratio","amount_ratio_5_60","volatility_60","amp_20"]:
        if c in p.columns: p[f"champ_{c}_pct"]=p.groupby("date")[c].rank(pct=True,method="average")
    trend=[c for c in ["champ_ret_20_pct","champ_ret_60_pct","champ_ret_180_pct","champ_pos_180_pct","champ_ma60_ratio_pct","champ_amount_ratio_5_60_pct"] if c in p.columns]
    risk=[c for c in ["champ_volatility_60_pct","champ_amp_20_pct"] if c in p.columns]
    p["champ_trend_score"]=p[trend].mean(axis=1) if trend else 0.0
    p["champ_risk_score"]=p[risk].mean(axis=1) if risk else 0.0
    p["cross_zms_score"]=p["zscore_mean_minus_std"] if "zscore_mean_minus_std" in p.columns else p.get("seed_z",0)
    p["cross_consensus_score"]=100*p["champion_votes"]+p["cross_zms_score"].fillna(0)
    p["cross_consensus_trend_score"]=100*p["champion_votes"]+p["cross_zms_score"].fillna(0)+2*p["champ_trend_score"].fillna(0)
    p["cross_safe_score"]=100*p["champion_votes"]+p["cross_zms_score"].fillna(0)+p["champ_trend_score"].fillna(0)-p["champ_risk_score"].fillna(0)
    return p

def pick_portfolio(pool, score_col, topn, weight_mode):
    rows=[]
    for d,g in pool.groupby("date"):
        gg=g.sort_values([score_col,"champion_votes","cross_zms_score"],ascending=[False,False,False]).head(topn).copy()
        if gg.empty: continue
        if weight_mode=="vote":
            vals=gg["champion_votes"].astype(float).to_numpy(); w=vals/vals.sum()
        elif weight_mode=="sqrt_vote":
            vals=np.sqrt(gg["champion_votes"].astype(float).to_numpy()); w=vals/vals.sum()
        else:
            w=np.ones(len(gg))/len(gg)
        r=np.nansum(gg["future_avg_daily_ret"].astype(float).to_numpy()*w)
        rh=np.nansum(gg["future_ret_h"].astype(float).to_numpy()*w)
        rows.append({"date":d,"fold_id":gg["fold_id"].iloc[0],"score_col":score_col,"topn":topn,"weight_mode":weight_mode,"n_hold":len(gg),"portfolio_avg_daily_ret":r,"portfolio_ret_h":rh,"symbols":"|".join(gg["symbol"].astype(str)),"weights":"|".join(f"{x:.4f}" for x in w),"champion_votes":"|".join(gg["champion_votes"].astype(str))})
    return pd.DataFrame(rows)

def summarize_daily(daily,strategy):
    r=daily["portfolio_avg_daily_ret"].astype(float)
    by=daily.groupby("fold_id")["portfolio_avg_daily_ret"].mean()
    return {"strategy":strategy,"n_days":len(daily),"avg_daily_ret":r.mean(),"median_daily_ret":r.median(),"hit16":(r>=0.016).mean(),"hit20":(r>=0.020).mean(),"big_loss":(r<=-0.05).mean(),"very_big_loss":(r<=-0.08).mean(),"positive_days":(r>0).mean(),"worst_day":r.min(),"best_day":r.max(),"n_folds":by.shape[0],"positive_fold_count":(by>0).sum(),"worst_fold":by.min(),"best_fold":by.max(),"fold_std":by.std()}
