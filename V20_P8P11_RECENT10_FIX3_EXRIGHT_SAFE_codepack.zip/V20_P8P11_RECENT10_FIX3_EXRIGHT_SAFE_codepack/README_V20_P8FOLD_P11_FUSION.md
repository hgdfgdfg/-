# V20_P8FOLD + P11 缩池融合扩充版

目标：
- 基于 P8 训练底子，扩展到 `30 seed × recent19fold`
- 输出目录仍然是：
  `C:\Users\魏儒翌\Desktop\新建文件夹 (3)\runs\V20_P8`
- 每个 seed/fold 会检测 `test_eval.csv/test_ranked.csv/top1/top10/features` 是否齐全，已完成则自动跳过。
- 训练和 ensemble 完成后，自动调用内置 P11 TRUE 二层缩池，输出到：
  `C:\Users\魏儒翌\Desktop\新建文件夹 (3)\V20_P11_TRUE_TWO_STAGE_SHRINK_out`

## 推荐运行顺序

先检查已有 fold：

```bat
check_v20_p8fold_status.bat
```

一键全流程：

```bat
run_v20_p8fold_p11_fusion_all.bat
```

或者手动：

```bat
python run_v20_p8fold_p11_fusion.py --mode all --recent_folds 19 --output_dir "C:\Users\魏儒翌\Desktop\新建文件夹 (3)\runs\V20_P8" --db_path "C:\Users\魏儒翌\Desktop\新建文件夹 (3)\data\ashare.duckdb" --p11_out_dir "C:\Users\魏儒翌\Desktop\新建文件夹 (3)\V20_P11_TRUE_TWO_STAGE_SHRINK_out" --p11_allow_low_coverage
```

只补训练：

```bat
run_v20_p8fold_train_only.bat
```

只做 ensemble + P11：

```bat
run_v20_p8fold_ensemble_then_p11.bat
```

## 关键输出

P8:
- `runs\V20_P8\V20_P8_W160_60_30_H2_S202604\fold_xx\test_ranked.csv`
- `runs\V20_P8\p8seed30_train_all_folds.csv`
- `runs\V20_P8\ensemble\W160_60_30\seed30_candidate_pool.csv`
- `runs\V20_P8\ensemble\seed30_ensemble_leaderboard.csv`

P11:
- `V20_P11_TRUE_TWO_STAGE_SHRINK_out\V20_P11_TRUE_stage2_pool_oracle_summary.csv`
- `V20_P11_TRUE_TWO_STAGE_SHRINK_out\V20_P11_TRUE_consensus_portfolio_summary.csv`
- `V20_P11_TRUE_TWO_STAGE_SHRINK_out\V20_P11_TRUE_consensus_portfolio_by_fold.csv`
- `V20_P11_TRUE_TWO_STAGE_SHRINK_out\V20_P11_TRUE_stage2_pool_sample.csv`

## 注意

- 不要加 `--force`，除非你真的想重跑已经完成的 fold。
- 如果 10fold 已经跑过，这版会自动跳过已有 fold，只补 recent19fold 里新增缺失的 fold。
- P11 直接读取 `runs\V20_P8\ensemble` 目录，不需要手动压缩 ensemble zip。


## FIX 版说明

- 修复 `conf/v20_p8fold_p11_base.yaml` 中 Windows 路径 `C:\Users...` 在 YAML 双引号下触发 `\U` 转义的问题；本版统一用 `C:/Users/...` 正斜杠路径。
- 已删除旧入口 bat，仅保留：
  - `check_v20_p8fold_status.bat`
  - `run_v20_p8fold_p11_fusion_all.bat`
  - `run_v20_p8fold_train_only.bat`
  - `run_v20_p8fold_ensemble_then_p11.bat`
- 训练主循环已增加每 fold 后的 `hard_cleanup()`：
  - `cleanup_torch()`
  - `gc.collect()`
  - 原有 torch/cuda cache 释放逻辑继续保留
- 不要直接运行 `run_v20_p11_true_two_stage_shrink.py`，除非手动提供完整参数。


## FIX2

- 修复 `run_v20_p8fold_p11_fusion.py` 中 argparse 默认路径被替换成非法 Python 代码的问题。
- 已通过 `py_compile` 语法检查。
