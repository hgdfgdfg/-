# -*- coding: utf-8 -*-
from __future__ import annotations
import pandas as pd

def load_yaml(path):
    import yaml
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def load_experiments(path):
    df = pd.read_csv(path)
    df = df.dropna(how="all").copy()
    if "exp_name" in df.columns:
        df = df[df["exp_name"].notna()].copy()
        df["exp_name"] = df["exp_name"].astype(str).str.strip()
        df = df[df["exp_name"] != ""].copy()
    if "enable" in df.columns:
        enable = pd.to_numeric(df["enable"], errors="coerce").fillna(0).astype(int)
        df = df[enable == 1].copy()
    return df.reset_index(drop=True)
