#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import runpy
from pathlib import Path
_ROOT = Path(__file__).resolve().parents[1]
runpy.run_path(str(_ROOT / "run_v20_p8.py"), run_name="__main__")
