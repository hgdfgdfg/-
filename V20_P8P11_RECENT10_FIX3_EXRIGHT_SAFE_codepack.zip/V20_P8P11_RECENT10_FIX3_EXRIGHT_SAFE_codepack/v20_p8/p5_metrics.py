from __future__ import annotations

import numpy as np
import pandas as pd


def _rate(s) -> float:
    return float(pd.to_numeric(s, errors="coerce").fillna(0).mean()) if len(s) else np.nan


def summarize_daily(df: pd.DataFrame, structure: str, rule_name: str, base_rule: str) -> dict:
    trade = df[df.get("is_trade", 1).fillna(1).astype(int) == 1].copy()
    ret = pd.to_numeric(trade.get("future_ret_h", pd.Series(dtype=float)), errors="coerce")
    all_days = int(df["date"].nunique()) if "date" in df.columns else len(df)
    folds = sorted(df["fold"].dropna().astype(str).unique().tolist()) if "fold" in df.columns else []
    out = {
        "structure": structure,
        "rule_name": rule_name,
        "base_rule": base_rule,
        "n_folds": len(folds),
        "n_days": all_days,
        "trade_days": int(len(trade)),
        "no_trade_days": int(all_days - len(trade)),
        "top1_avg_ret": float(ret.mean()) if len(ret) else np.nan,
        "top1_avg_daily_ret": float(ret.mean() / 2.0) if len(ret) else np.nan,
        "top1_median_ret": float(ret.median()) if len(ret) else np.nan,
        "hit16": _rate(trade.get("hit16", [])) if len(trade) else np.nan,
        "hit20": _rate(trade.get("hit20", [])) if len(trade) else np.nan,
        "big_loss": _rate(trade.get("big_loss", [])) if len(trade) else np.nan,
        "very_big_loss": _rate(trade.get("very_big_loss", [])) if len(trade) else np.nan,
        "positive_days": float((ret > 0).mean()) if len(ret) else np.nan,
        "max_single_loss": float(ret.min()) if len(ret) else np.nan,
        "max_single_gain": float(ret.max()) if len(ret) else np.nan,
    }
    return out


def summarize_by_fold(df: pd.DataFrame, structure: str, rule_name: str, base_rule: str) -> pd.DataFrame:
    rows = []
    for fold, g in df.groupby("fold", dropna=False, sort=True):
        trade = g[g.get("is_trade", 1).fillna(1).astype(int) == 1].copy()
        ret = pd.to_numeric(trade.get("future_ret_h", pd.Series(dtype=float)), errors="coerce")
        rows.append({
            "structure": structure,
            "rule_name": rule_name,
            "base_rule": base_rule,
            "fold_id": fold,
            "fold_start_date": g["date"].min(),
            "fold_end_date": g["date"].max(),
            "n_days": int(g["date"].nunique()),
            "trade_days": int(len(trade)),
            "top1_avg_ret": float(ret.mean()) if len(ret) else np.nan,
            "top1_avg_daily_ret": float(ret.mean() / 2.0) if len(ret) else np.nan,
            "hit16": _rate(trade.get("hit16", [])) if len(trade) else np.nan,
            "hit20": _rate(trade.get("hit20", [])) if len(trade) else np.nan,
            "big_loss": _rate(trade.get("big_loss", [])) if len(trade) else np.nan,
            "very_big_loss": _rate(trade.get("very_big_loss", [])) if len(trade) else np.nan,
            "positive_days": float((ret > 0).mean()) if len(ret) else np.nan,
            "max_single_loss": float(ret.min()) if len(ret) else np.nan,
            "max_single_gain": float(ret.max()) if len(ret) else np.nan,
        })
    return pd.DataFrame(rows)


def add_fold_stability(summary: pd.DataFrame, by_fold: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (structure, rule_name, base_rule), g in by_fold.groupby(["structure", "rule_name", "base_rule"], dropna=False):
        x = pd.to_numeric(g["top1_avg_daily_ret"], errors="coerce")
        rows.append({
            "structure": structure,
            "rule_name": rule_name,
            "base_rule": base_rule,
            "positive_fold_count": int((x > 0).sum()),
            "negative_fold_count": int((x <= 0).sum()),
            "worst_fold_avg_daily_ret": float(x.min()) if len(x) else np.nan,
            "best_fold_avg_daily_ret": float(x.max()) if len(x) else np.nan,
            "fold_avg_daily_ret_mean": float(x.mean()) if len(x) else np.nan,
            "fold_avg_daily_ret_std": float(x.std(ddof=0)) if len(x) else np.nan,
            "fold_avg_daily_ret_min": float(x.min()) if len(x) else np.nan,
            "fold_avg_daily_ret_max": float(x.max()) if len(x) else np.nan,
        })
    stab = pd.DataFrame(rows)
    return summary.merge(stab, on=["structure", "rule_name", "base_rule"], how="left")


def seed_baseline_from_candidates(candidate: pd.DataFrame, structure: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    rank_cols = sorted([c for c in candidate.columns if c.startswith("rank_S")])
    daily_parts = []
    for rc in rank_cols:
        seed = rc.replace("rank_S", "")
        d = candidate[pd.to_numeric(candidate[rc], errors="coerce").notna()].copy()
        if d.empty:
            continue
        d["_seed_rank"] = pd.to_numeric(d[rc], errors="coerce")
        d = d.sort_values(["date", "_seed_rank", "symbol"], ascending=[True, True, True], kind="mergesort")
        top = d.groupby("date", sort=False).head(1).copy()
        top["seed"] = seed
        daily_parts.append(top)
    if not daily_parts:
        return pd.DataFrame(), pd.DataFrame()
    daily = pd.concat(daily_parts, ignore_index=True)
    rows = []
    for (seed, fold), g in daily.groupby(["seed", "fold"], dropna=False):
        ret = pd.to_numeric(g["future_ret_h"], errors="coerce")
        rows.append({
            "structure": structure,
            "seed": seed,
            "fold_id": fold,
            "n_days": int(g["date"].nunique()),
            "top1_avg_ret": float(ret.mean()),
            "top1_avg_daily_ret": float(ret.mean() / 2.0),
            "hit16": _rate(g.get("hit16", [])),
            "hit20": _rate(g.get("hit20", [])),
            "big_loss": _rate(g.get("big_loss", [])),
            "positive_days": float((ret > 0).mean()),
            "max_single_loss": float(ret.min()),
            "max_single_gain": float(ret.max()),
        })
    return daily, pd.DataFrame(rows)
