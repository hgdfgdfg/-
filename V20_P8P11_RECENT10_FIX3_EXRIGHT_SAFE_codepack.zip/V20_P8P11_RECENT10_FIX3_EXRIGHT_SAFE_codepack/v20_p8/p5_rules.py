from __future__ import annotations

import numpy as np
import pandas as pd


def add_default_labels(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    ret = pd.to_numeric(df.get("future_ret_h", np.nan), errors="coerce")
    if "hit16" not in df.columns:
        df["hit16"] = (ret >= 0.032).astype(float)
    if "hit20" not in df.columns:
        df["hit20"] = (ret >= 0.040).astype(float)
    if "big_loss" not in df.columns:
        df["big_loss"] = (ret <= -0.020).astype(float)
    df["very_big_loss"] = (ret <= -0.080).astype(float)
    df["future_avg_daily_ret"] = ret / 2.0
    return df


def add_risk_flags(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    def num(c):
        return pd.to_numeric(df.get(c, np.nan), errors="coerce")

    pos180 = num("pos_180")
    pos60 = num("pos_60")
    ret5 = num("ret_5")
    ret20 = num("ret_20")
    ret60 = num("ret_60")
    ma60 = num("ma60_ratio")
    amount_5_60 = num("amount_ratio_5_60")

    # S2 中验证有效的 light：低位 + 20日弱势/破位。
    low_break = (
        ((pos180 < 0.25) & (ret20 < -0.10)) |
        ((pos60 < 0.18) & (ret20 < -0.12)) |
        ((ma60 < -0.08) & (ret20 < -0.12))
    )
    # 只用于 recent15fold 验证是否该废掉；不建议作为主规则。
    high_accel = (
        ((pos180 > 0.90) & (ret20 > 0.35) & (amount_5_60 > 1.80)) |
        ((pos180 > 0.95) & (ret60 > 0.80) & (ret5 > 0.15))
    )
    df["risk_low_break_light"] = low_break.fillna(False).astype(int)
    df["risk_high_accel_light"] = high_accel.fillna(False).astype(int)
    df["risk_double_side_light"] = ((df["risk_low_break_light"] == 1) | (df["risk_high_accel_light"] == 1)).astype(int)
    return df


def _safe_num(s, default=np.nan):
    return pd.to_numeric(s, errors="coerce").fillna(default)


def select_top1_by_rule(candidates: pd.DataFrame, rule_name: str, base_rule: str) -> pd.DataFrame:
    df = candidates.copy()
    if rule_name == "RISK_180_low_break_light_rank_min":
        df = df[df.get("risk_low_break_light", 0).astype(int) == 0].copy()
    elif rule_name == "RISK_180_high_accel_light_rank_min":
        df = df[df.get("risk_high_accel_light", 0).astype(int) == 0].copy()
    elif rule_name == "RISK_180_double_side_light_rank_min":
        df = df[df.get("risk_double_side_light", 0).astype(int) == 0].copy()

    if df.empty:
        return pd.DataFrame(columns=list(candidates.columns) + ["rule_name", "base_rule", "is_trade"])

    # 组内排序用稳定排序，避免不同系统 pandas tie 行为差异。
    if base_rule == "rank_min":
        sort_cols = ["date", "rank_min", "top1_votes", "top3_votes", "top10_votes", "zscore_mean", "score_mean", "symbol"]
        ascending = [True, True, False, False, False, False, False, True]
    elif base_rule == "votes_then_score_zscore":
        sort_cols = ["date", "top10_votes", "top3_votes", "top1_votes", "zscore_mean", "rank_min", "symbol"]
        ascending = [True, False, False, False, False, True, True]
    else:
        raise ValueError(f"unknown base_rule={base_rule}")

    for c in sort_cols:
        if c not in df.columns:
            if c == "symbol":
                df[c] = ""
            else:
                df[c] = np.nan
    df = df.sort_values(sort_cols, ascending=ascending, kind="mergesort")
    out = df.groupby("date", as_index=False, sort=False).head(1).copy()
    out["rule_name"] = rule_name
    out["base_rule"] = base_rule
    out["is_trade"] = 1
    return out


def experiment_plan() -> list[tuple[str, str]]:
    # 高位/双侧仅用于验证是否废掉，不做参数搜索。
    return [
        ("BASE_rank_min", "rank_min"),
        ("BASE_votes_then_score_zscore", "votes_then_score_zscore"),
        ("RISK_180_low_break_light_rank_min", "rank_min"),
        ("RISK_180_high_accel_light_rank_min", "rank_min"),
        ("RISK_180_double_side_light_rank_min", "rank_min"),
    ]


def classify_loss_type(row: pd.Series) -> str:
    if int(row.get("risk_low_break_light", 0) or 0) == 1:
        return "low_break"
    if int(row.get("risk_high_accel_light", 0) or 0) == 1:
        return "high_accel"
    pos180 = pd.to_numeric(row.get("pos_180", np.nan), errors="coerce")
    ret20 = pd.to_numeric(row.get("ret_20", np.nan), errors="coerce")
    ma60 = pd.to_numeric(row.get("ma60_ratio", np.nan), errors="coerce")
    if pd.notna(pos180) and pos180 > 0.85 and pd.notna(ret20) and ret20 < 0:
        return "high_position_reversal"
    if pd.notna(pos180) and 0.25 <= pos180 <= 0.65 and pd.notna(ma60) and ma60 < -0.05:
        return "weak_middle"
    return "unknown"
