
# -*- coding: utf-8 -*-
from __future__ import annotations
import numpy as np
import pandas as pd

def evaluate_ranked(df, score_col="rank_score", hold_days=2):
    out={}
    rows=[]
    for d,g in df.groupby("date"):
        g=g.sort_values(score_col, ascending=False)
        for k in [1,3,5,10]:
            sub=g.head(k)
            rows.append({"date":d,"k":k,"avg_ret":sub["future_ret_h"].mean(),"hit16":sub["hit16"].mean(),"hit20":sub["hit20"].mean(),"big_loss":(sub["future_ret_h"]/hold_days<=-0.01).mean()})
    tk=pd.DataFrame(rows)
    for k in [1,3,5,10]:
        sub=tk[tk["k"]==k]
        out[f"top{k}_avg_ret"]=sub["avg_ret"].mean()
        out[f"top{k}_hit16_rate"]=sub["hit16"].mean()
        out[f"top{k}_hit20_rate"]=sub["hit20"].mean()
        out[f"top{k}_big_loss_rate"]=sub["big_loss"].mean()
    # rank layer
    rank_rows=[]
    for d,g in df.groupby("date"):
        g=g.sort_values(score_col,ascending=False).head(10).copy()
        for i,(_,r) in enumerate(g.iterrows(),start=1):
            rank_rows.append({"rank":i,"ret":r["future_ret_h"],"hit16":r["hit16"],"hit20":r["hit20"]})
    rr=pd.DataFrame(rank_rows)
    if len(rr):
        for r in [1,2,3,5,10]:
            sub=rr[rr["rank"]==r]
            if len(sub):
                out[f"rank{r}_avg_ret"]=sub["ret"].mean()
                out[f"rank{r}_hit16_rate"]=sub["hit16"].mean()
    return out
