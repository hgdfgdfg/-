
# -*- coding: utf-8 -*-
from __future__ import annotations
import warnings
warnings.filterwarnings("ignore", message="No further splits with positive gain.*")
from pathlib import Path
import pickle
import numpy as np
import pandas as pd

def make_rank_targets(df, target_type):
    out=df.copy()
    out["rank_norm"]=np.nan; out["top20_label"]=0; out["top10_label"]=0
    for d,g in out.groupby("date"):
        idx=g.index
        r=g["future_ret_h"].rank(pct=True, method="average")
        out.loc[idx,"rank_norm"]=r.values
        out.loc[idx,"top20_label"]=(r>=0.80).astype(int).values
        out.loc[idx,"top10_label"]=(r>=0.90).astype(int).values
    if target_type=="top20": return out, "top20_label", "clf"
    if target_type=="top10": return out, "top10_label", "clf"
    return out, "rank_norm", "reg"

def select_features(df, feature_set, cfg):
    emb = [c for c in df.columns if c.startswith("emb_")]
    score = ["tcn_score"] if "tcn_score" in df.columns else []
    base = [c for c in cfg.get("base_rank_feature_columns", []) if c in df.columns]

    if feature_set == "score":
        cols = score
    elif feature_set == "emb":
        cols = emb
    elif feature_set == "emb_base":
        cols = emb + base
    else:
        cols = emb + base

    cols = list(dict.fromkeys(cols))
    forbidden = cfg.get("forbidden_feature_keywords", [])
    safe_cols = []
    for c in cols:
        lc = c.lower()
        if any(k.lower() in lc for k in forbidden):
            continue
        safe_cols.append(c)
    return safe_cols

def train_ranker(train_df, valid_df, features, target_col, mode, cfg):
    X=train_df[features].replace([np.inf,-np.inf],np.nan).fillna(0.0)
    y=train_df[target_col]
    sample_weight=None
    if "sample_weight" in train_df.columns:
        sample_weight=train_df["sample_weight"].values
    ranker_type=cfg.get("ranker_type","auto")
    if ranker_type in ["auto","lightgbm"]:
        try:
            import lightgbm as lgb
            if mode=="clf":
                model=lgb.LGBMClassifier(
                    n_estimators=int(cfg.get("ranker_n_estimators",200)),
                    learning_rate=float(cfg.get("ranker_learning_rate",0.05)),
                    max_depth=int(cfg.get("ranker_max_depth",5)),
                    subsample=0.9,
                    colsample_bytree=0.9,
                    random_state=int(cfg.get("seed",202604)),
                    n_jobs=-1,
                    verbosity=-1,
                )
            else:
                model=lgb.LGBMRegressor(
                    n_estimators=int(cfg.get("ranker_n_estimators",200)),
                    learning_rate=float(cfg.get("ranker_learning_rate",0.05)),
                    max_depth=int(cfg.get("ranker_max_depth",5)),
                    subsample=0.9,
                    colsample_bytree=0.9,
                    random_state=int(cfg.get("seed",202604)),
                    n_jobs=-1,
                    verbosity=-1,
                )
            model.fit(X,y,sample_weight=sample_weight)
            return model, "lightgbm"
        except Exception:
            if ranker_type=="lightgbm": raise
    from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
    if mode=="clf":
        model=HistGradientBoostingClassifier(max_iter=int(cfg.get("ranker_n_estimators",200)), learning_rate=float(cfg.get("ranker_learning_rate",0.05)), max_leaf_nodes=31, random_state=int(cfg.get("seed",202604)))
    else:
        model=HistGradientBoostingRegressor(max_iter=int(cfg.get("ranker_n_estimators",200)), learning_rate=float(cfg.get("ranker_learning_rate",0.05)), max_leaf_nodes=31, random_state=int(cfg.get("seed",202604)))
    model.fit(X,y,sample_weight=sample_weight)
    return model, "sklearn"

def predict_ranker(model, df, features, mode):
    X=df[features].replace([np.inf,-np.inf],np.nan).fillna(0.0)
    if mode=="clf" and hasattr(model,"predict_proba"):
        return model.predict_proba(X)[:,1]
    return model.predict(X)

def save_model(path, model, meta):
    with open(path,"wb") as f:
        pickle.dump({"model":model,"meta":meta},f)
