
# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from .model import TCNFactorNet
from .data import DateFilteredSequenceDataset, fit_standardizer, apply_standardizer
from .utils import ensure_dir, log_time, cleanup_torch

def _predict(model, ds, cfg):
    loader=DataLoader(ds,batch_size=int(cfg.get("tcn_batch_size",1024)),shuffle=False,num_workers=int(cfg.get("num_workers",0)))
    model.eval(); device=cfg["_device"]; scores=[]; embs=[]
    with torch.no_grad():
        for x,y in loader:
            x=x.to(device)
            pred,emb=model(x,return_embedding=True)
            scores.append(pred.detach().cpu().numpy()); embs.append(emb.detach().cpu().numpy())
    scores=np.concatenate(scores) if scores else np.array([])
    embs=np.concatenate(embs) if embs else np.zeros((0,int(cfg.get("embedding_dim",16))))
    meta=pd.DataFrame(ds.meta,columns=["symbol","date","future_ret_h","hit16","hit20"])
    meta["date"]=pd.to_datetime(meta["date"]); meta["tcn_score"]=scores
    for i in range(embs.shape[1]):
        meta[f"emb_{i:02d}"]=embs[:,i]
    return meta

def train_or_load_embeddings(data, fold, feature_cols, seq_len, target_col, cfg, emb_dir):
    emb_dir=ensure_dir(emb_dir)
    train_path=emb_dir/"train_embeddings.csv"; valid_path=emb_dir/"valid_embeddings.csv"; test_path=emb_dir/"test_embeddings.csv"
    if train_path.exists() and valid_path.exists() and test_path.exists():
        return (
            pd.read_csv(train_path,parse_dates=["date"]),
            pd.read_csv(valid_path,parse_dates=["date"]),
            pd.read_csv(test_path,parse_dates=["date"]),
        )

    tr_for_std=data[(data["date"]>=fold["train_start"])&(data["date"]<=fold["train_end"])].copy()
    mu,sd=fit_standardizer(tr_for_std, feature_cols)
    context=data[data["date"]<=fold["test_end"]].copy()
    context=apply_standardizer(context, feature_cols, mu, sd)

    train_ds=DateFilteredSequenceDataset(context,feature_cols,seq_len,target_col,fold["train_start"],fold["train_end"])
    valid_ds=DateFilteredSequenceDataset(context,feature_cols,seq_len,target_col,fold["valid_start"],fold["valid_end"])
    test_ds=DateFilteredSequenceDataset(context,feature_cols,seq_len,target_col,fold["test_start"],fold["test_end"])
    log_time(f"TCN datasets train={len(train_ds)} valid={len(valid_ds)} test={len(test_ds)}")
    if len(train_ds)<1000 or len(valid_ds)<100 or len(test_ds)<100:
        raise RuntimeError("TCN样本过少，检查seq_len/fold/特征缺失")

    model=TCNFactorNet(
        input_dim=len(feature_cols),
        channels=cfg.get("tcn_channels",[32,32,64]),
        kernel_size=int(cfg.get("tcn_kernel_size",3)),
        dropout=float(cfg.get("tcn_dropout",0.15)),
        embedding_dim=int(cfg.get("embedding_dim",16)),
    ).to(cfg["_device"])
    loader=DataLoader(train_ds,batch_size=int(cfg.get("tcn_batch_size",1024)),shuffle=True,num_workers=int(cfg.get("num_workers",0)))
    vloader=DataLoader(valid_ds,batch_size=int(cfg.get("tcn_batch_size",1024)),shuffle=False,num_workers=int(cfg.get("num_workers",0)))
    opt=torch.optim.AdamW(model.parameters(),lr=float(cfg.get("tcn_lr",0.001)),weight_decay=float(cfg.get("tcn_weight_decay",0.0001)))
    loss_fn=torch.nn.HuberLoss(delta=0.03)
    best=None; best_state=None; bad=0; patience=int(cfg.get("early_stop_patience",3))
    logs=[]
    for ep in range(1,int(cfg.get("tcn_epochs",8))+1):
        model.train(); losses=[]
        for x,y in tqdm(loader, desc=f"TCN epoch {ep}", leave=False):
            x=x.to(cfg["_device"]); y=y.to(cfg["_device"])
            pred=model(x); loss=loss_fn(pred,y)
            opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),2.0); opt.step()
            losses.append(float(loss.detach().cpu()))
        model.eval(); vloss=[]
        with torch.no_grad():
            for x,y in vloader:
                x=x.to(cfg["_device"]); y=y.to(cfg["_device"])
                vloss.append(float(loss_fn(model(x),y).detach().cpu()))
        tr=float(np.mean(losses)); va=float(np.mean(vloss)) if vloss else np.nan
        logs.append({"epoch":ep,"train_loss":tr,"valid_loss":va})
        log_time(f"TCN epoch={ep} train_loss={tr:.6f} valid_loss={va:.6f}")
        if best is None or va<best:
            best=va; best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}; bad=0
        else:
            bad+=1
            if bad>=patience:
                break
    if best_state: model.load_state_dict(best_state)
    pd.DataFrame(logs).to_csv(emb_dir/"tcn_train_log.csv",index=False,encoding="utf-8-sig")
    torch.save(model.state_dict(), emb_dir/"tcn_model.pt")

    train_emb=_predict(model,train_ds,cfg); valid_emb=_predict(model,valid_ds,cfg); test_emb=_predict(model,test_ds,cfg)
    train_emb.to_csv(train_path,index=False,encoding="utf-8-sig")
    valid_emb.to_csv(valid_path,index=False,encoding="utf-8-sig")
    test_emb.to_csv(test_path,index=False,encoding="utf-8-sig")
    del model,train_ds,valid_ds,test_ds,loader,vloader,context,tr_for_std
    cleanup_torch()
    return train_emb, valid_emb, test_emb
