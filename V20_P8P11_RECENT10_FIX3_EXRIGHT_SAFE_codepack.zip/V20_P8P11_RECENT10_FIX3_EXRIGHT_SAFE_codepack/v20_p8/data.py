
# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
from typing import Dict, List
import duckdb
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from .utils import ensure_dir, log_time

def _detect_table(con, preferred="auto"):
    tables = [r[0] for r in con.execute("SHOW TABLES").fetchall()]
    if preferred and preferred != "auto":
        return preferred
    for c in ["stock_daily_mainboard", "stock_daily", "daily", "ashare_daily"]:
        if c in tables: return c
    for t in tables:
        cols = [r[1].lower() for r in con.execute(f"PRAGMA table_info('{t}')").fetchall()]
        if all(x in cols for x in ["date","open","high","low","close"]):
            return t
    raise ValueError(f"无法自动识别日线表，可用表={tables}")

def _standardize_daily(df):
    """Standardize raw daily table while preserving optional adjusted-price columns.

    Raw open/high/low/close are kept for labels and real trading prices.
    Optional adjusted/qfq columns, if present, are preserved for ex-right-safe
    feature calculation.  If no adjusted columns exist, build_features() will
    synthesize a continuous front-adjusted series for feature-only use.
    """
    cols = {c.lower(): c for c in df.columns}
    def f(names):
        for n in names:
            if n in cols: return cols[n]
        return None
    date_col = f(["date","trade_date","k_date"])
    sym_col = f(["symbol","ts_code","code","code6","symbol_raw"])
    ren = {date_col:"date", sym_col:"symbol"}
    for n in ["open","high","low","close","volume","vol","amount"]:
        c = f([n])
        if c: ren[c] = "volume" if n == "vol" else n
    # Optional adjusted / qfq price columns.  Different data vendors use different names.
    opt_map = {
        "qfq_open": ["qfq_open","open_qfq","adj_open","open_adj","前复权开盘","qfqopen"],
        "qfq_high": ["qfq_high","high_qfq","adj_high","high_adj","前复权最高","qfqhigh"],
        "qfq_low":  ["qfq_low","low_qfq","adj_low","low_adj","前复权最低","qfqlow"],
        "qfq_close":["qfq_close","close_qfq","adj_close","close_adj","前复权收盘","qfqclose"],
        "adj_factor":["adj_factor","qfq_factor","复权因子","factor"],
        "name": ["name","stock_name","sec_name","证券简称","股票简称"],
    }
    for std_name, aliases in opt_map.items():
        c = f(aliases)
        if c: ren[c] = std_name
    out = df.rename(columns=ren)
    if "volume" not in out.columns: out["volume"] = np.nan
    if "amount" not in out.columns: out["amount"] = np.nan
    out["date"] = pd.to_datetime(out["date"])
    out["symbol"] = out["symbol"].astype(str)
    keep = ["date","symbol","open","high","low","close","volume","amount"]
    for c in ["qfq_open","qfq_high","qfq_low","qfq_close","adj_factor","name"]:
        if c in out.columns and c not in keep:
            keep.append(c)
    return out[keep].sort_values(["symbol","date"]).reset_index(drop=True)

def load_daily(cfg):
    db_path = cfg["db_path"]
    log_time(f"loading DuckDB | {db_path}")
    con = duckdb.connect(db_path, read_only=True)
    table = _detect_table(con, cfg.get("daily_table","auto"))
    log_time(f"daily_table={table}")
    df = con.execute(f"SELECT * FROM {table}").fetchdf()
    con.close()
    return _standardize_daily(df)

def _detect_exright_jumps_one_symbol(g: pd.DataFrame, threshold: float) -> pd.DataFrame:
    """Build a synthetic front-adjusted OHLC series for feature engineering only.

    The synthetic adjustment is anchored to the latest raw price and adjusts older
    prices across large adjacent close jumps.  It is intentionally NOT used for
    labels / real trading prices.
    """
    g = g.sort_values("date").copy()
    raw_close = pd.to_numeric(g["close"], errors="coerce").astype(float).values
    n = len(g)
    factor = np.ones(n, dtype=float)
    jump_flag = np.zeros(n, dtype=np.int8)
    ratio_arr = np.full(n, np.nan, dtype=float)
    cur = 1.0
    for i in range(n - 2, -1, -1):
        prev = raw_close[i]
        nxt = raw_close[i + 1]
        if np.isfinite(prev) and np.isfinite(nxt) and prev > 0:
            ratio = nxt / prev
            ratio_arr[i + 1] = ratio
            # A-share normal limit moves are usually <=20%; use a slightly wider
            # threshold to avoid treating ordinary volatility as ex-right.
            if ratio < (1.0 - threshold) or ratio > (1.0 + threshold):
                cur *= ratio
                jump_flag[i + 1] = 1
        factor[i] = cur
    for c in ["open", "high", "low", "close"]:
        g[f"_px_{c}"] = pd.to_numeric(g[c], errors="coerce").astype(float) * factor
    g["exright_suspect_jump"] = jump_flag
    g["exright_jump_ratio"] = ratio_arr
    g["exright_cum_factor"] = factor
    g["exright_jump_count"] = int(jump_flag.sum())
    if jump_flag.sum() > 0:
        idx = np.where(jump_flag == 1)[0][-1]
        g["exright_last_jump_date"] = g["date"].iloc[idx]
    else:
        g["exright_last_jump_date"] = pd.NaT
    g["exright_adjust_method"] = "synthetic_front_adjusted" if jump_flag.sum() > 0 else "raw_no_jump"
    return g


def _attach_feature_prices(df: pd.DataFrame, cfg) -> pd.DataFrame:
    """Attach feature-only OHLC columns _px_open/_px_high/_px_low/_px_close.

    Priority:
      1) explicit qfq/adj columns if available and enabled;
      2) synthetic front-adjusted raw OHLC if a large ex-right jump is detected;
      3) raw OHLC when no jump is detected.
    """
    out = df.sort_values(["symbol", "date"]).copy()
    use_exright_safe = bool(cfg.get("exright_safe_features", True))
    threshold = float(cfg.get("exright_jump_threshold", 0.22))
    explicit = all(c in out.columns for c in ["qfq_open", "qfq_high", "qfq_low", "qfq_close"])
    if (not use_exright_safe):
        for c in ["open","high","low","close"]:
            out[f"_px_{c}"] = pd.to_numeric(out[c], errors="coerce")
        out["exright_adjust_method"] = "raw_disabled"
        out["exright_suspect_jump"] = 0
        out["exright_jump_count"] = 0
        out["exright_last_jump_date"] = pd.NaT
        return out
    if explicit:
        for src, dst in [("qfq_open","_px_open"),("qfq_high","_px_high"),("qfq_low","_px_low"),("qfq_close","_px_close")]:
            out[dst] = pd.to_numeric(out[src], errors="coerce")
        out["exright_adjust_method"] = "explicit_qfq_or_adj"
        out["exright_suspect_jump"] = 0
        out["exright_jump_count"] = 0
        out["exright_last_jump_date"] = pd.NaT
        return out
    parts = []
    for _, g in out.groupby("symbol", sort=False):
        parts.append(_detect_exright_jumps_one_symbol(g, threshold))
    return pd.concat(parts, ignore_index=True).sort_values(["symbol","date"]).reset_index(drop=True)


def build_features(daily, cfg):
    df = daily.sort_values(["symbol","date"]).copy()
    # Feature-only prices are ex-right safe.  Raw OHLC remains unchanged for labels
    # and actual trading / buyability checks.
    df = _attach_feature_prices(df, cfg)
    g = df.groupby("symbol", group_keys=False)
    prev = g["_px_close"].shift(1)
    df["ret_1"] = df["_px_close"] / prev - 1
    for n in [2,3,5,10,20,60,120]:
        df[f"ret_{n}"] = df["_px_close"] / g["_px_close"].shift(n) - 1
    df["amp_1"] = (df["_px_high"] - df["_px_low"]) / df["_px_close"].replace(0, np.nan)
    rng = (df["_px_high"] - df["_px_low"]).replace(0, np.nan)
    df["close_pos"] = (df["_px_close"] - df["_px_low"]) / rng
    df["upper_shadow"] = (df["_px_high"] - df[["_px_open","_px_close"]].max(axis=1)) / rng
    df["lower_shadow"] = (df[["_px_open","_px_close"]].min(axis=1) - df["_px_low"]) / rng
    for n in [5,10,20]:
        df[f"vol_{n}"] = g["ret_1"].rolling(n, min_periods=max(3,n//2)).std().reset_index(level=0, drop=True)
        df[f"amp_{n}"] = g["amp_1"].rolling(n, min_periods=max(3,n//2)).mean().reset_index(level=0, drop=True)
    for n in [5,10,20,60]:
        ma = g["_px_close"].rolling(n, min_periods=max(3,n//2)).mean().reset_index(level=0, drop=True)
        df[f"ma{n}_bias"] = df["_px_close"] / ma - 1
    for n in [5,20]:
        ma = g["amount"].rolling(n, min_periods=max(3,n//2)).mean().reset_index(level=0, drop=True)
        df[f"amount_ratio_{n}"] = df["amount"] / ma.replace(0, np.nan)
    bench = None
    for code in ["sh000001","000001","399001","sh000300"]:
        b = df[df["symbol"].astype(str).str.contains(code, regex=False)]
        if len(b):
            bench = b[["date","ret_1","ret_5","ret_20"]].rename(columns={"ret_1":"bench_ret_1","ret_5":"bench_ret_5","ret_20":"bench_ret_20"})
            break
    if bench is not None:
        df = df.merge(bench, on="date", how="left")
        df["rel_ret_1"] = df["ret_1"] - df["bench_ret_1"]
        df["rel_ret_5"] = df["ret_5"] - df["bench_ret_5"]
        df["rel_ret_20"] = df["ret_20"] - df["bench_ret_20"]
    else:
        df["rel_ret_1"], df["rel_ret_5"], df["rel_ret_20"] = df["ret_1"], df["ret_5"], df["ret_20"]
    return df.replace([np.inf,-np.inf], np.nan)

def add_labels(feat, cfg):
    df = feat.sort_values(["symbol","date"]).copy()
    g = df.groupby("symbol", group_keys=False)
    hold = int(cfg.get("hold_days",2)); entry_lag=int(cfg.get("entry_lag",1)); exit_lag=entry_lag+hold
    df["entry_open"] = g["open"].shift(-entry_lag)
    df["exit_open"] = g["open"].shift(-exit_lag)
    df["future_ret_h"] = df["exit_open"] / df["entry_open"].replace(0, np.nan) - 1
    bench = None
    for code in ["sh000001","000001","399001","sh000300"]:
        b = df[df["symbol"].astype(str).str.contains(code, regex=False)]
        if len(b):
            bench = b[["date","future_ret_h"]].rename(columns={"future_ret_h":"bench_future_ret_h"})
            break
    if bench is not None:
        df = df.merge(bench, on="date", how="left")
        df["future_excess_ret_h"] = df["future_ret_h"] - df["bench_future_ret_h"]
    else:
        df["future_excess_ret_h"] = df["future_ret_h"]
    th16=float(cfg.get("daily_target_16",0.016))*hold; th20=float(cfg.get("daily_target_20",0.020))*hold
    df["hit16"]=(df["future_ret_h"]>=th16).astype(int)
    df["hit20"]=(df["future_ret_h"]>=th20).astype(int)
    df["big_loss"]=(df["future_ret_h"]/hold <= -0.01).astype(int)
    return df

def get_feature_table(cfg):
    cache_dir=ensure_dir(cfg.get("cache_dir","cache/V20_P3STAB_EMB"))
    base_path=cache_dir/"base_features.csv"; lab_path=cache_dir/f"labels_h{int(cfg.get('hold_days',2))}.csv"
    if lab_path.exists():
        log_time(f"loading label cache | {lab_path}")
        return pd.read_csv(lab_path, parse_dates=["date"])
    if base_path.exists():
        log_time(f"loading base cache | {base_path}")
        base=pd.read_csv(base_path, parse_dates=["date"])
    else:
        daily=load_daily(cfg); log_time("building base features")
        base=build_features(daily,cfg)
        base.to_csv(base_path,index=False,encoding="utf-8-sig")
        log_time(f"saved {base_path}")
    log_time("building labels")
    df=add_labels(base,cfg)
    df.to_csv(lab_path,index=False,encoding="utf-8-sig")
    log_time(f"saved {lab_path}")
    return df

def make_recent_folds(df, train_days, valid_days, test_days, recent_folds):
    dates = sorted(pd.to_datetime(df["date"].dropna().unique()))
    total=train_days+valid_days+test_days
    folds=[]
    for i in range(recent_folds):
        end=len(dates)-i*test_days
        start=end-total
        if start<0: break
        folds.append({
            "fold":f"fold_{recent_folds-i:02d}",
            "train_start":dates[start], "train_end":dates[start+train_days-1],
            "valid_start":dates[start+train_days], "valid_end":dates[start+train_days+valid_days-1],
            "test_start":dates[start+train_days+valid_days], "test_end":dates[end-1],
        })
    return list(reversed(folds))

def fit_standardizer(df, cols):
    mu=df[cols].mean(); sd=df[cols].std().replace(0,np.nan)
    return mu, sd

def apply_standardizer(df, cols, mu, sd):
    out=df.copy()
    out[cols]=(out[cols]-mu)/sd
    out[cols]=out[cols].replace([np.inf,-np.inf],np.nan).fillna(0.0)
    return out

class DateFilteredSequenceDataset(Dataset):
    def __init__(self, df, feature_cols, seq_len, target_col, start_date, end_date):
        self.samples=[]; self.meta=[]; self.seq_len=int(seq_len)
        s=pd.to_datetime(start_date); e=pd.to_datetime(end_date)
        df=df.sort_values(["symbol","date"]).copy()
        for sym,g in df.groupby("symbol", sort=False):
            g=g.reset_index(drop=True)
            xarr=g[feature_cols].astype("float32").values
            yarr=g[target_col].astype("float32").values
            dates=pd.to_datetime(g["date"]).values
            fut=g["future_ret_h"].astype("float32").values
            h16=g["hit16"].astype("int8").values; h20=g["hit20"].astype("int8").values
            for i in range(seq_len-1, len(g)):
                d=pd.to_datetime(dates[i])
                if d<s or d>e: continue
                if not np.isfinite(yarr[i]): continue
                x=xarr[i-seq_len+1:i+1]
                if not np.isfinite(x).all(): continue
                self.samples.append((x,yarr[i]))
                self.meta.append((sym, dates[i], float(fut[i]), int(h16[i]), int(h20[i])))
    def __len__(self): return len(self.samples)
    def __getitem__(self, idx):
        x,y=self.samples[idx]
        return torch.tensor(x,dtype=torch.float32), torch.tensor(y,dtype=torch.float32)
