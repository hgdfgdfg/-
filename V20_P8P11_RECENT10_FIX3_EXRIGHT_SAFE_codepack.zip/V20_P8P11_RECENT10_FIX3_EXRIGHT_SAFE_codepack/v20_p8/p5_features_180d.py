from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import duckdb
import numpy as np
import pandas as pd

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    def tqdm(x, **kwargs):
        return x


def _pick(cols: List[str], candidates: List[str], required: bool = True) -> Optional[str]:
    lower = {c.lower(): c for c in cols}
    for cand in candidates:
        if cand.lower() in lower:
            return lower[cand.lower()]
    if required:
        raise ValueError(f"cannot find any of {candidates}; available={cols}")
    return None


def _table_columns(duckdb_path: str, table: str) -> List[str]:
    con = duckdb.connect(duckdb_path, read_only=True)
    try:
        return con.execute(f"PRAGMA table_info('{table}')").fetchdf()["name"].astype(str).tolist()
    finally:
        con.close()


def read_daily_panel_subset(
    duckdb_path: str,
    table: str,
    symbols: List[str],
    start_date: str,
    end_date: str,
    logger,
) -> pd.DataFrame:
    if not Path(duckdb_path).exists():
        raise FileNotFoundError(f"duckdb_path not found: {duckdb_path}")
    cols = _table_columns(duckdb_path, table)
    date_col = _pick(cols, ["date", "trade_date", "datetime", "dt"])
    symbol_col = _pick(cols, ["symbol", "code", "ts_code", "ticker"])
    open_col = _pick(cols, ["open", "open_price"], required=False)
    high_col = _pick(cols, ["high", "high_price"])
    low_col = _pick(cols, ["low", "low_price"])
    close_col = _pick(cols, ["close", "close_price"])
    vol_col = _pick(cols, ["volume", "vol"], required=False)
    amount_col = _pick(cols, ["amount", "turnover", "turnover_value", "money"], required=False)
    select = [
        f"{date_col} AS date",
        f"{symbol_col} AS symbol",
        f"{high_col} AS high",
        f"{low_col} AS low",
        f"{close_col} AS close",
        f"{open_col or close_col} AS open",
        f"{vol_col} AS volume" if vol_col else "NULL AS volume",
        f"{amount_col} AS amount" if amount_col else "NULL AS amount",
    ]
    # symbols can be large; use temp table to avoid huge IN clause.
    con = duckdb.connect(duckdb_path, read_only=True)
    try:
        sym_df = pd.DataFrame({"symbol": pd.Series(symbols, dtype="object")})
        con.register("_v20_p8_symbols", sym_df)
        sql = f"""
        SELECT {', '.join(select)}
        FROM {table}
        WHERE CAST({date_col} AS DATE) >= CAST(? AS DATE)
          AND CAST({date_col} AS DATE) <= CAST(? AS DATE)
          AND CAST({symbol_col} AS VARCHAR) IN (SELECT symbol FROM _v20_p8_symbols)
        """
        logger.info(f"read DuckDB panel | symbols={len(symbols):,} | {start_date} -> {end_date}")
        df = con.execute(sql, [start_date, end_date]).fetchdf()
    finally:
        con.close()
    df.columns = [str(c).strip() for c in df.columns]
    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
    df["symbol"] = df["symbol"].astype(str)
    for c in ["open", "high", "low", "close", "volume", "amount"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    logger.info(f"daily panel rows={len(df):,}")
    return df


def build_180d_features(panel: pd.DataFrame, logger) -> pd.DataFrame:
    df = panel.sort_values(["symbol", "date"]).copy()
    out_parts = []
    symbols = df["symbol"].drop_duplicates().tolist()
    logger.info(f"build 180D no-leak features | symbols={len(symbols):,}")
    for sym, g in tqdm(df.groupby("symbol", sort=False), total=len(symbols), desc="180D features"):
        g = g.sort_values("date").copy()
        close = g["close"].astype(float)
        high = g["high"].astype(float)
        low = g["low"].astype(float)
        amount = g["amount"].astype(float)
        prev_close = close.shift(1)
        feat = pd.DataFrame({"date": g["date"].values, "symbol": sym})
        for n in [5, 10, 20, 60, 120, 180]:
            feat[f"ret_{n}"] = prev_close / close.shift(1 + n) - 1.0
        for n in [20, 60, 120, 180]:
            rh = high.shift(1).rolling(n, min_periods=max(5, min(n, 20))).max()
            rl = low.shift(1).rolling(n, min_periods=max(5, min(n, 20))).min()
            feat[f"pos_{n}"] = (prev_close - rl) / (rh - rl).replace(0, np.nan)
            ma = close.shift(1).rolling(n, min_periods=max(5, min(n, 20))).mean()
            feat[f"ma{n}_ratio"] = prev_close / ma - 1.0
            amp = (rh - rl) / prev_close.replace(0, np.nan)
            feat[f"amp_{n}"] = amp
        ret1 = close.pct_change().shift(1)
        for n in [20, 60, 120, 180]:
            feat[f"volatility_{n}"] = ret1.rolling(n, min_periods=max(5, min(n, 20))).std()
        for short, long in [(5, 60), (10, 120), (20, 180)]:
            a_short = amount.shift(1).rolling(short, min_periods=max(2, short // 2)).mean()
            a_long = amount.shift(1).rolling(long, min_periods=max(5, min(long, 20))).mean()
            feat[f"amount_ratio_{short}_{long}"] = a_short / a_long.replace(0, np.nan)
        # trend consistency: percentage of positive daily returns in trailing window ending at T-1.
        for n in [60, 120, 180]:
            feat[f"trend_consistency_{n}"] = (ret1 > 0).astype(float).rolling(n, min_periods=max(5, min(n, 20))).mean()
        out_parts.append(feat)
    out = pd.concat(out_parts, ignore_index=True)
    # Bound positions to a reasonable range while preserving NaN.
    for c in ["pos_20", "pos_60", "pos_120", "pos_180"]:
        if c in out.columns:
            out[c] = out[c].clip(-0.5, 1.5)
    return out


def load_or_build_features(
    candidate: pd.DataFrame,
    duckdb_path: str,
    daily_table: str,
    out_dir: str,
    structure: str,
    calendar_buffer_days: int,
    force_rebuild_cache: bool,
    logger,
) -> pd.DataFrame:
    cache_dir = Path(out_dir) / "_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_path = cache_dir / f"V20_P8_180D_features_{structure}.csv"
    if cache_path.exists() and not force_rebuild_cache:
        logger.info(f"reuse feature cache | {cache_path}")
        return pd.read_csv(cache_path, low_memory=False)
    dates = pd.to_datetime(candidate["date"])
    start_date = (dates.min() - pd.Timedelta(days=calendar_buffer_days)).strftime("%Y-%m-%d")
    end_date = dates.max().strftime("%Y-%m-%d")
    symbols = sorted(candidate["symbol"].astype(str).unique().tolist())
    panel = read_daily_panel_subset(duckdb_path, daily_table, symbols, start_date, end_date, logger)
    feats = build_180d_features(panel, logger)
    need_keys = candidate[["date", "symbol"]].drop_duplicates()
    feats = need_keys.merge(feats, on=["date", "symbol"], how="left")
    feats.to_csv(cache_path, index=False, encoding="utf-8-sig")
    logger.info(f"saved feature cache | rows={len(feats):,} | {cache_path}")
    return feats
