from __future__ import annotations

# 支持直接运行本 py：python path/to/run_v20_p8.py ...
if __package__ is None or __package__ == "":
    import os, sys
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import argparse
import gc
import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    def tqdm(x, **kwargs):
        return x

from v20_p8.p5_features_180d import load_or_build_features
from v20_p8.p5_metrics import add_fold_stability, seed_baseline_from_candidates, summarize_by_fold, summarize_daily
from v20_p8.p5_rules import add_default_labels, add_risk_flags, classify_loss_type, experiment_plan, select_top1_by_rule


def _merge_features(candidate: pd.DataFrame, feats: pd.DataFrame) -> pd.DataFrame:
    feats = feats.copy()
    feats["date"] = pd.to_datetime(feats["date"]).dt.strftime("%Y-%m-%d")
    feats["symbol"] = feats["symbol"].astype(str)
    return candidate.merge(feats, on=["date", "symbol"], how="left")


def _make_daily_outputs(candidate: pd.DataFrame, structure: str, logger) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    daily_parts = []
    summary_rows = []
    by_fold_parts = []
    for rule_name, base_rule in tqdm(experiment_plan(), desc="experiments"):
        logger.info(f"run experiment | {rule_name} | base_rule={base_rule}")
        sel = select_top1_by_rule(candidate, rule_name=rule_name, base_rule=base_rule)
        # If risk rule filters all candidates for a date, this package does NOT no_trade by design.
        # Missing dates are rare but keep them explicit for diagnostics if they occur.
        all_dates = candidate[["date", "fold"]].drop_duplicates()
        if len(sel) < len(all_dates):
            sel = all_dates.merge(sel, on=["date", "fold"], how="left")
            sel["rule_name"] = sel["rule_name"].fillna(rule_name)
            sel["base_rule"] = sel["base_rule"].fillna(base_rule)
            sel["is_trade"] = sel["symbol"].notna().astype(int)
        daily_parts.append(sel)
        summary_rows.append(summarize_daily(sel, structure, rule_name, base_rule))
        by_fold_parts.append(summarize_by_fold(sel, structure, rule_name, base_rule))
    daily = pd.concat(daily_parts, ignore_index=True)
    by_fold = pd.concat(by_fold_parts, ignore_index=True)
    summary = pd.DataFrame(summary_rows)
    summary = add_fold_stability(summary, by_fold)
    summary = summary.sort_values(
        ["positive_fold_count", "top1_avg_daily_ret", "big_loss"],
        ascending=[False, False, True],
        kind="mergesort",
    )
    return daily, summary, by_fold


def _replacement_tables(daily: pd.DataFrame, base_rule_name: str, compare_rules: List[str]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    base = daily[daily["rule_name"] == base_rule_name].copy()
    rows = []
    for r in compare_rules:
        new = daily[daily["rule_name"] == r].copy()
        m = base.merge(new, on=["date", "fold"], how="inner", suffixes=("_base", "_new"))
        m = m[m["symbol_base"].astype(str) != m["symbol_new"].astype(str)].copy()
        if m.empty:
            continue
        m["delta_future_ret_h"] = pd.to_numeric(m["future_ret_h_new"], errors="coerce") - pd.to_numeric(m["future_ret_h_base"], errors="coerce")
        m["delta_avg_daily_ret"] = m["delta_future_ret_h"] / 2.0
        m["base_is_big_loss"] = pd.to_numeric(m.get("big_loss_base", 0), errors="coerce").fillna(0).astype(int)
        m["new_is_big_loss"] = pd.to_numeric(m.get("big_loss_new", 0), errors="coerce").fillna(0).astype(int)
        m["base_is_hit20"] = pd.to_numeric(m.get("hit20_base", 0), errors="coerce").fillna(0).astype(int)
        m["new_is_hit20"] = pd.to_numeric(m.get("hit20_new", 0), errors="coerce").fillna(0).astype(int)
        def repl_type(row):
            if row["base_is_big_loss"] == 1 and row["new_is_big_loss"] == 0:
                return "avoided_big_loss"
            if row["base_is_big_loss"] == 0 and row["new_is_big_loss"] == 1:
                return "created_big_loss"
            if row["delta_future_ret_h"] > 0.01:
                return "improved_profit"
            if row["delta_future_ret_h"] < -0.01:
                return "worsened_profit"
            return "neutral"
        m["replacement_type"] = m.apply(repl_type, axis=1)
        m["risk_rule"] = r
        rows.append(m)
    if not rows:
        return pd.DataFrame(), pd.DataFrame()
    comp = pd.concat(rows, ignore_index=True)

    keep_cols = [
        "date", "fold", "risk_rule",
        "symbol_base", "symbol_new",
        "future_ret_h_base", "future_ret_h_new", "delta_future_ret_h",
        "future_avg_daily_ret_base", "future_avg_daily_ret_new", "delta_avg_daily_ret",
        "base_is_big_loss", "new_is_big_loss", "base_is_hit20", "new_is_hit20",
        "top10_votes_base", "top3_votes_base", "top1_votes_base",
        "top10_votes_new", "top3_votes_new", "top1_votes_new",
        "ret_20_base", "pos_180_base", "ma60_ratio_base",
        "ret_20_new", "pos_180_new", "ma60_ratio_new",
        "replacement_type",
    ]
    keep = [c for c in keep_cols if c in comp.columns]
    comp_out = comp[keep].copy()

    srows = []
    for r, g in comp.groupby("risk_rule"):
        br = pd.to_numeric(g["future_ret_h_base"], errors="coerce")
        nr = pd.to_numeric(g["future_ret_h_new"], errors="coerce")
        srows.append({
            "risk_rule": r,
            "n_replaced_days": int(len(g)),
            "replace_ratio_vs_all_days": np.nan,  # filled by caller only if needed
            "base_avg_ret_on_replaced": float(br.mean()),
            "new_avg_ret_on_replaced": float(nr.mean()),
            "delta_avg_ret_on_replaced": float((nr - br).mean()),
            "base_big_loss_on_replaced": float(g["base_is_big_loss"].mean()),
            "new_big_loss_on_replaced": float(g["new_is_big_loss"].mean()),
            "big_loss_net_reduced": int(((g["base_is_big_loss"] == 1) & (g["new_is_big_loss"] == 0)).sum() - ((g["base_is_big_loss"] == 0) & (g["new_is_big_loss"] == 1)).sum()),
            "base_hit20_on_replaced": float(g["base_is_hit20"].mean()),
            "new_hit20_on_replaced": float(g["new_is_hit20"].mean()),
            "hit20_delta": float(g["new_is_hit20"].mean() - g["base_is_hit20"].mean()),
            "improved_days": int((g["delta_future_ret_h"] > 0).sum()),
            "worsened_days": int((g["delta_future_ret_h"] < 0).sum()),
            "avoided_big_loss_days": int((g["replacement_type"] == "avoided_big_loss").sum()),
            "created_big_loss_days": int((g["replacement_type"] == "created_big_loss").sum()),
        })
    return comp_out, pd.DataFrame(srows)


def _big_loss_profile(daily: pd.DataFrame) -> pd.DataFrame:
    bl = daily[pd.to_numeric(daily.get("big_loss", 0), errors="coerce").fillna(0).astype(int) == 1].copy()
    if bl.empty:
        return bl
    bl["loss_type"] = bl.apply(classify_loss_type, axis=1)
    cols = [
        "date", "fold", "rule_name", "base_rule", "symbol", "future_ret_h", "future_avg_daily_ret",
        "rank_min", "score_zscore_mean", "zscore_mean", "score_mean", "top10_votes", "top3_votes", "top1_votes",
        "ret_5", "ret_20", "ret_60", "ret_120", "ret_180",
        "pos_20", "pos_60", "pos_120", "pos_180",
        "ma20_ratio", "ma60_ratio", "ma120_ratio", "ma180_ratio",
        "amount_ratio_5_60", "amount_ratio_20_180",
        "risk_low_break_light", "risk_high_accel_light", "risk_double_side_light", "loss_type",
    ]
    return bl[[c for c in cols if c in bl.columns]].sort_values(["rule_name", "future_ret_h"], ascending=[True, True])


def _oracle_gap(candidate: pd.DataFrame, daily: pd.DataFrame, structure: str) -> pd.DataFrame:
    # Oracle: each date chooses max future_ret_h from union seed top10 candidate pool.
    tmp = candidate.copy()
    tmp["_ret"] = pd.to_numeric(tmp["future_ret_h"], errors="coerce")
    oracle_daily = tmp.sort_values(["date", "_ret"], ascending=[True, False], kind="mergesort").groupby("date", sort=False).head(1)
    rows = []
    for rule, g in daily.groupby("rule_name"):
        m = g[["date", "fold", "future_ret_h", "hit20", "big_loss"]].merge(
            oracle_daily[["date", "future_ret_h", "hit20", "big_loss"]],
            on="date", how="left", suffixes=("_ensemble", "_oracle")
        )
        for fold, fg in m.groupby("fold", dropna=False):
            er = pd.to_numeric(fg["future_ret_h_ensemble"], errors="coerce")
            orr = pd.to_numeric(fg["future_ret_h_oracle"], errors="coerce")
            rows.append({
                "structure": structure,
                "fold_id": fold,
                "rule_name": rule,
                "ensemble_top1_avg_daily_ret": float(er.mean() / 2.0),
                "oracle_union_top10_avg_daily_ret": float(orr.mean() / 2.0),
                "oracle_gap": float((orr.mean() - er.mean()) / 2.0),
                "oracle_hit20": float(pd.to_numeric(fg["hit20_oracle"], errors="coerce").fillna(0).mean()),
                "ensemble_hit20": float(pd.to_numeric(fg["hit20_ensemble"], errors="coerce").fillna(0).mean()),
                "oracle_big_loss": float(pd.to_numeric(fg["big_loss_oracle"], errors="coerce").fillna(0).mean()),
                "ensemble_big_loss": float(pd.to_numeric(fg["big_loss_ensemble"], errors="coerce").fillna(0).mean()),
            })
    return pd.DataFrame(rows)


def _removed_by_risk(candidate: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for risk_col in ["risk_low_break_light", "risk_high_accel_light", "risk_double_side_light"]:
        if risk_col not in candidate.columns:
            continue
        g = candidate[candidate[risk_col].fillna(0).astype(int) == 1].copy()
        if g.empty:
            continue
        ret = pd.to_numeric(g["future_ret_h"], errors="coerce")
        rows.append({
            "risk_col": risk_col,
            "n_removed_candidates": int(len(g)),
            "removed_avg_ret": float(ret.mean()),
            "removed_avg_daily_ret": float(ret.mean() / 2.0),
            "removed_hit20": float(pd.to_numeric(g.get("hit20", 0), errors="coerce").fillna(0).mean()),
            "removed_big_loss": float(pd.to_numeric(g.get("big_loss", 0), errors="coerce").fillna(0).mean()),
            "removed_top10_votes_avg": float(pd.to_numeric(g.get("top10_votes", np.nan), errors="coerce").mean()),
        })
    return pd.DataFrame(rows)



from contextlib import contextmanager
import time
from v20_p8.utils import ensure_dir, log_time, save_json

class _SimpleLogger:
    def __init__(self, log_path: Path):
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
    def info(self, msg: str):
        line = f"[{pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
        print(line, flush=True)
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")

@contextmanager
def time_block(logger, name: str):
    t0 = time.time()
    logger.info(f"START | {name}")
    try:
        yield
    finally:
        logger.info(f"DONE  | {name} | cost={time.time()-t0:.2f}s")

def save_csv(df: pd.DataFrame, path: str | Path, logger):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if df is None:
        df = pd.DataFrame()
    df.to_csv(path, index=False, encoding="utf-8-sig")
    logger.info(f"saved | rows={len(df):,} | {path}")

def read_candidate_pool_from_p4_output(out_root: Path, structure: str, logger) -> pd.DataFrame:
    candidates = [
        out_root / "ensemble" / structure / "seed10_candidate_pool.csv",
        out_root / "ensemble" / "seed10_candidate_pool.csv",
        out_root / "ensemble" / structure / "seed15_candidate_pool.csv",
        out_root / "ensemble" / structure / "seed20_candidate_pool.csv",
    ]
    for p in candidates:
        if p.exists():
            logger.info(f"read candidate pool | {p}")
            df = pd.read_csv(p, low_memory=False)
            break
    else:
        raise FileNotFoundError("找不到 candidate_pool。请先运行 --mode train 或 --mode ensemble，候选路径应为 output_dir/ensemble/<structure>/seed10_candidate_pool.csv")
    if "date" not in df.columns:
        raise ValueError("candidate_pool 缺少 date 列")
    if "symbol" not in df.columns:
        raise ValueError("candidate_pool 缺少 symbol 列")
    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
    df["symbol"] = df["symbol"].astype(str)
    if "fold" not in df.columns:
        df["fold"] = "fold_unknown"
    logger.info(f"candidate rows={len(df):,} | dates={df['date'].nunique():,} | symbols={df['symbol'].nunique():,}")
    return df


def run_p5_validation(cfg: dict, structure: str = "W160_60_30", force_rebuild_cache: bool = False) -> Path:
    """按照 P4 输出结构读取 runs/.../ensemble/<structure>/seed10_candidate_pool.csv，
    输出完整 P8 recent15fold 验证结果。"""
    out_root = Path(cfg.get("output_dir", "runs/V20_P8"))
    daily_table = str(cfg.get("daily_table", "stock_daily_mainboard"))
    duckdb_path = str(cfg.get("db_path", "data/ashare.duckdb"))
    calendar_buffer_days = int(cfg.get("p5_calendar_buffer_days", 300))

    p5_out = ensure_dir(out_root / "ensemble" / "V20_P8_validation" / structure)
    ensure_dir(p5_out / "logs")
    logger = _SimpleLogger(p5_out / "logs" / "run.log")
    logger.info(f"V20_P8 validation start | structure={structure} | db={duckdb_path} | table={daily_table}")
    save_json(p5_out / "V20_P8_experiment_config.json", {
        "project": "V20_P8",
        "structure": structure,
        "output_dir": str(out_root),
        "duckdb_path": duckdb_path,
        "daily_table": daily_table,
        "calendar_buffer_days": calendar_buffer_days,
        "force_rebuild_cache": bool(force_rebuild_cache),
        "input_candidate_pool": str(out_root / "ensemble" / structure / "seed10_candidate_pool.csv"),
    })

    with time_block(logger, "read P4-style candidate pool"):
        candidate = read_candidate_pool_from_p4_output(out_root, structure, logger)
        candidate = add_default_labels(candidate)

    with time_block(logger, "build/load 180D risk features"):
        feats = load_or_build_features(
            candidate=candidate,
            duckdb_path=duckdb_path,
            daily_table=daily_table,
            out_dir=str(p5_out),
            structure=structure,
            calendar_buffer_days=calendar_buffer_days,
            force_rebuild_cache=force_rebuild_cache,
            logger=logger,
        )
        candidate = _merge_features(candidate, feats)
        del feats
        gc.collect()
        candidate = add_risk_flags(candidate)

    with time_block(logger, "run fixed validation rules"):
        daily, summary, by_fold = _make_daily_outputs(candidate, structure, logger)

    with time_block(logger, "build diagnostics"):
        replacement_compare, replacement_summary = _replacement_tables(
            daily,
            base_rule_name="BASE_rank_min",
            compare_rules=[
                "RISK_180_low_break_light_rank_min",
                "RISK_180_high_accel_light_rank_min",
                "RISK_180_double_side_light_rank_min",
            ],
        )
        if not replacement_summary.empty:
            n_dates = candidate["date"].nunique()
            replacement_summary["replace_ratio_vs_all_days"] = replacement_summary["n_replaced_days"] / max(n_dates, 1)
        big_loss_profile = _big_loss_profile(daily)
        oracle_gap = _oracle_gap(candidate, daily, structure)
        removed_by_risk = _removed_by_risk(candidate)
        seed_daily, seed_baseline = seed_baseline_from_candidates(candidate, structure)
        seed_summary = pd.DataFrame()
        if not seed_baseline.empty:
            srows = []
            for seed, g in seed_baseline.groupby("seed"):
                x = pd.to_numeric(g["top1_avg_daily_ret"], errors="coerce")
                srows.append({
                    "structure": structure,
                    "seed": seed,
                    "fold_count": int(g["fold_id"].nunique()),
                    "top1_avg_daily_ret_mean": float(x.mean()),
                    "top1_avg_daily_ret_std": float(x.std(ddof=0)),
                    "hit20_mean": float(pd.to_numeric(g["hit20"], errors="coerce").mean()),
                    "big_loss_mean": float(pd.to_numeric(g["big_loss"], errors="coerce").mean()),
                    "positive_fold_count": int((x > 0).sum()),
                    "worst_fold_avg_daily_ret": float(x.min()),
                })
            seed_summary = pd.DataFrame(srows).sort_values("top1_avg_daily_ret_mean", ascending=False)

    with time_block(logger, "save complete P8 outputs"):
        save_csv(summary, p5_out / "V20_P8_recent15_summary.csv", logger)
        save_csv(by_fold, p5_out / "V20_P8_recent15_by_fold.csv", logger)
        save_csv(daily, p5_out / "V20_P8_recent15_daily_top1.csv", logger)
        save_csv(replacement_compare, p5_out / "V20_P8_recent15_replacement_compare.csv", logger)
        save_csv(replacement_summary, p5_out / "V20_P8_recent15_replacement_summary.csv", logger)
        save_csv(big_loss_profile, p5_out / "V20_P8_recent15_big_loss_profile.csv", logger)
        save_csv(seed_baseline, p5_out / "V20_P8_recent15_seed_baseline.csv", logger)
        save_csv(seed_summary, p5_out / "V20_P8_recent15_seed_summary.csv", logger)
        save_csv(seed_daily, p5_out / "V20_P8_recent15_seed_daily_top1.csv", logger)
        save_csv(oracle_gap, p5_out / "V20_P8_recent15_oracle_gap.csv", logger)
        save_csv(removed_by_risk, p5_out / "V20_P8_recent15_removed_by_risk.csv", logger)
    logger.info(f"V20_P8 validation done | output={p5_out}")
    del candidate, daily, summary, by_fold
    gc.collect()
    return p5_out
