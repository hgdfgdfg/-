
# -*- coding: utf-8 -*-
from __future__ import annotations
import torch
import torch.nn as nn

class Chomp1d(nn.Module):
    def __init__(self, chomp_size):
        super().__init__(); self.chomp_size = int(chomp_size)
    def forward(self, x):
        return x if self.chomp_size == 0 else x[:, :, :-self.chomp_size].contiguous()

class TemporalBlock(nn.Module):
    def __init__(self, n_inputs, n_outputs, kernel_size, dilation, dropout):
        super().__init__()
        padding = (kernel_size - 1) * dilation
        self.net = nn.Sequential(
            nn.Conv1d(n_inputs, n_outputs, kernel_size, padding=padding, dilation=dilation),
            Chomp1d(padding), nn.BatchNorm1d(n_outputs), nn.ReLU(), nn.Dropout(dropout),
            nn.Conv1d(n_outputs, n_outputs, kernel_size, padding=padding, dilation=dilation),
            Chomp1d(padding), nn.BatchNorm1d(n_outputs), nn.ReLU(), nn.Dropout(dropout),
        )
        self.downsample = nn.Conv1d(n_inputs, n_outputs, 1) if n_inputs != n_outputs else None
        self.relu = nn.ReLU()
    def forward(self, x):
        out = self.net(x)
        res = x if self.downsample is None else self.downsample(x)
        return self.relu(out + res)

class TCNFactorNet(nn.Module):
    def __init__(self, input_dim, channels, kernel_size=3, dropout=0.15, embedding_dim=16):
        super().__init__()
        layers = []
        prev = input_dim
        for i, ch in enumerate(channels):
            layers.append(TemporalBlock(prev, ch, kernel_size, dilation=2**i, dropout=dropout))
            prev = ch
        self.tcn = nn.Sequential(*layers)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.embedding = nn.Sequential(nn.Linear(prev, embedding_dim), nn.ReLU(), nn.LayerNorm(embedding_dim))
        self.head = nn.Linear(embedding_dim, 1)
    def forward(self, x, return_embedding=False):
        z = x.transpose(1, 2)
        h = self.tcn(z)
        h = self.pool(h).squeeze(-1)
        emb = self.embedding(h)
        y = self.head(emb).squeeze(-1)
        return (y, emb) if return_embedding else y
