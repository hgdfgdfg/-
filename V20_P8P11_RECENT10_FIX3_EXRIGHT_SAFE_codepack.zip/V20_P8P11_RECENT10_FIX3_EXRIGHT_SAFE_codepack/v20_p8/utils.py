
# -*- coding: utf-8 -*-
from __future__ import annotations
import os
import gc, json, random, time
from pathlib import Path
import numpy as np

def now_str():
    return time.strftime("%Y-%m-%d %H:%M:%S")

def log_time(msg: str):
    print(f"[time] {now_str()} | {msg}", flush=True)

def ensure_dir(p):
    p = Path(p); p.mkdir(parents=True, exist_ok=True); return p

def seed_everything(seed: int, deterministic: bool = False, cublas_workspace_config: str = ":4096:8"):
    import random
    import numpy as np
    import torch
    os.environ["PYTHONHASHSEED"] = str(seed)
    if deterministic:
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = str(cublas_workspace_config)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        try:
            torch.use_deterministic_algorithms(True, warn_only=True)
        except TypeError:
            torch.use_deterministic_algorithms(True)

def pick_device(device="auto"):
    if device == "auto":
        try:
            import torch
            return "cuda" if torch.cuda.is_available() else "cpu"
        except Exception:
            return "cpu"
    return device

def cleanup_torch():
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            try: torch.cuda.ipc_collect()
            except Exception: pass
    except Exception:
        pass

def save_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
