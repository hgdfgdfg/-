
# -*- coding: utf-8 -*-
from __future__ import annotations
import gc
import json
import zipfile
from pathlib import Path
import pandas as pd

from v20_p8.utils import ensure_dir, log_time, save_json
from v20_p8_seed_champion.data import load_candidate_pool
from v20_p8_seed_champion.features import read_daily_panel, build_180d_features, merge_features_to_candidates, add_relative_features
from v20_p8_seed_champion.portfolio import (
    build_seed_champions, aggregate_champions, add_cross_scores,
    pick_portfolio, summarize_daily
)

def _seed_prefix(exps) -> str:
    try:
        return f"seed{int(exps['seed'].nunique())}"
    except Exception:
        return "seed30"

def _zip_ensemble_dir(ens_dir: Path, seed_prefix: str, logger=log_time) -> Path:
    zip_path = ens_dir / f"V20_P8_{seed_prefix.upper()}_ensemble.zip"
    members = [
        f"{seed_prefix}_candidate_pool.csv",
        f"{seed_prefix}_ensemble_daily_top1.csv",
        f"{seed_prefix}_ensemble_leaderboard.csv",
        f"{seed_prefix}_ensemble_by_fold.csv",
        f"{seed_prefix}_oracle_gap.csv",
        "overview.json",
    ]
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in ens_dir.rglob("*"):
            if p.is_file() and (p.name in members or p.parent.name == "W160_60_30"):
                zf.write(p, arcname=str(p.relative_to(ens_dir.parent)))
    logger(f"V20_P8 ensemble zip saved | {zip_path}")
    return zip_path

def _portfolio_by_fold(daily: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (strategy, fold_id), g in daily.groupby(["strategy", "fold_id"], dropna=False):
        r = g["portfolio_avg_daily_ret"].astype(float)
        rows.append({
            "strategy": strategy,
            "fold_id": fold_id,
            "n_days": int(len(g)),
            "avg_daily_ret": float(r.mean()),
            "median_daily_ret": float(r.median()),
            "hit16": float((r >= 0.016).mean()),
            "hit20": float((r >= 0.020).mean()),
            "big_loss": float((r <= -0.05).mean()),
            "very_big_loss": float((r <= -0.08).mean()),
            "positive_days": float((r > 0).mean()),
            "worst_day": float(r.min()),
            "best_day": float(r.max()),
        })
    return pd.DataFrame(rows)

def run_p8_champion_from_ensemble(cfg: dict, exps, structure: str = "W160_60_30", force_rebuild_cache: bool = False):
    """P8 seed champion portfolio stage.

    只使用 P5/P8 训练阶段生成的 seed{N}_candidate_pool.csv。
    每个 seed 每天只取原始 rank1，再做 cross-seed consensus top1/top2/top3/top5 组合。
    """
    out_root = Path(cfg.get("output_dir", "runs/V20_P8"))
    ens_dir = out_root / "ensemble"
    seed_prefix = _seed_prefix(exps)
    cand_paths = [
        ens_dir / structure / f"{seed_prefix}_candidate_pool.csv",
        ens_dir / f"{seed_prefix}_candidate_pool.csv",
    ]
    cand_path = next((p for p in cand_paths if p.exists()), None)
    if cand_path is None:
        raise FileNotFoundError(f"找不到 {seed_prefix}_candidate_pool.csv。请先运行 --mode ensemble。查找路径: {cand_paths}")

    champion_out = ensure_dir(out_root / "seed_champion" / structure)
    log_time(f"V20_P8 seed champion start | structure={structure} | seed_prefix={seed_prefix} | candidate={cand_path}")
    save_json(champion_out / "V20_P8_seed_champion_config.json", {
        "project": "V20_P8_INTEGRATED_30SEED_10FOLD",
        "structure": structure,
        "seed_prefix": seed_prefix,
        "candidate_pool": str(cand_path),
        "out_dir": str(champion_out),
        "mode": "each_seed_rank1_then_cross_seed_consensus",
        "portfolio_topn": [1,2,3,5],
        "weight_modes": ["equal","vote","sqrt_vote"],
    })

    cand = load_candidate_pool(str(cand_path), structure, type("LoggerProxy", (), {"log": staticmethod(log_time)})())
    if "future_avg_daily_ret" not in cand.columns:
        hold_days = int(cfg.get("hold_days", 2))
        cand["future_avg_daily_ret"] = cand["future_ret_h"].astype(float) / hold_days

    cache_dir = ensure_dir(champion_out / "_cache")
    cand_cache = cache_dir / f"V20_P8_candidate_features_{structure}_{seed_prefix}.csv"
    feat_cache = cache_dir / f"V20_P8_180d_features_{structure}_{seed_prefix}.csv"
    if cand_cache.exists() and not force_rebuild_cache:
        cf = pd.read_csv(cand_cache, parse_dates=["date"])
        log_time(f"load P8 candidate feature cache | {cand_cache}")
    else:
        if feat_cache.exists() and not force_rebuild_cache:
            feats = pd.read_csv(feat_cache, parse_dates=["date"])
            log_time(f"load P8 180D feature cache | {feat_cache}")
        else:
            daily = read_daily_panel(
                cfg.get("db_path", "data/ashare.duckdb"),
                cfg.get("daily_table", "stock_daily_mainboard"),
                cand,
                int(cfg.get("p8_calendar_buffer_days", 520)),
                type("LoggerProxy", (), {"log": staticmethod(log_time)})(),
            )
            feats = build_180d_features(daily, type("LoggerProxy", (), {"log": staticmethod(log_time)})())
            feats.to_csv(feat_cache, index=False, encoding="utf-8-sig")
            del daily
            gc.collect()

        cf = merge_features_to_candidates(cand, feats, type("LoggerProxy", (), {"log": staticmethod(log_time)})(), int(cfg.get("p8_asof_tolerance_days", 10)))
        cov = []
        for c in ["ret_20","ret_60","pos_60","pos_180","ma60_ratio","amount_ratio_5_60"]:
            if c in cf.columns:
                cov.append({"feature": c, "nonnull": int(cf[c].notna().sum()), "total": int(len(cf)), "coverage": float(cf[c].notna().mean())})
        pd.DataFrame(cov).to_csv(champion_out / "V20_P8_feature_coverage_diag.csv", index=False, encoding="utf-8-sig")
        log_time("P8 feature coverage:\n" + pd.DataFrame(cov).to_string(index=False))
        cf = add_relative_features(cf)
        cf.to_csv(cand_cache, index=False, encoding="utf-8-sig")
        del feats
        gc.collect()

    log_time(f"P8 candidate features ready | rows={len(cf):,} | cols={len(cf.columns)}")

    champions, seeds = build_seed_champions(cf)
    log_time(f"P8 seed champions | rows={len(champions):,} | seeds={len(seeds)} | dates={champions['date'].nunique()}")
    champions.to_csv(champion_out / "V20_P8_seed_champions_daily.csv", index=False, encoding="utf-8-sig")

    pool = aggregate_champions(champions)
    pool = add_cross_scores(pool)
    pool.to_csv(champion_out / "V20_P8_champion_pool_daily.csv", index=False, encoding="utf-8-sig")
    log_time(f"P8 champion pool | rows={len(pool):,} | avg unique/day={len(pool)/pool['date'].nunique():.2f}")

    dist = pool.groupby("date").agg(
        unique_champions=("symbol", "count"),
        max_votes=("champion_votes", "max"),
        mean_votes=("champion_votes", "mean"),
        top_vote_gap=("champion_votes", lambda s: s.sort_values(ascending=False).iloc[0] - (s.sort_values(ascending=False).iloc[1] if len(s)>1 else 0)),
    ).reset_index()
    dist.to_csv(champion_out / "V20_P8_champion_votes_distribution.csv", index=False, encoding="utf-8-sig")

    daily_list = []
    sums = []
    bfs = []
    score_cols = ["cross_consensus_score","cross_consensus_trend_score","cross_safe_score","cross_zms_score"]
    for sc in score_cols:
        if sc not in pool.columns:
            continue
        for topn in [1,2,3,5]:
            for wm in ["equal","vote","sqrt_vote"]:
                d = pick_portfolio(pool, sc, topn, wm)
                strat = f"{sc}__top{topn}__{wm}"
                d["strategy"] = strat
                daily_list.append(d)
                sums.append(summarize_daily(d, strat))
                bf = _portfolio_by_fold(d)
                bfs.append(bf)

    daily_all = pd.concat(daily_list, ignore_index=True)
    summary = pd.DataFrame(sums).sort_values(["avg_daily_ret","big_loss"], ascending=[False,True])
    byfold = pd.concat(bfs, ignore_index=True)
    daily_all.to_csv(champion_out / "V20_P8_portfolio_daily.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(champion_out / "V20_P8_portfolio_summary.csv", index=False, encoding="utf-8-sig")
    byfold.to_csv(champion_out / "V20_P8_portfolio_by_fold.csv", index=False, encoding="utf-8-sig")

    oracle = pool.sort_values("future_avg_daily_ret", ascending=False).groupby("date").head(1)
    oracle.to_csv(champion_out / "V20_P8_champion_pool_oracle_top1.csv", index=False, encoding="utf-8-sig")
    log_time("P8 top summary:\n" + summary.head(20).to_string(index=False))
    log_time(f"V20_P8 seed champion done | output={champion_out}")
    try:
        _zip_ensemble_dir(ens_dir, seed_prefix)
    except Exception as e:
        log_time(f"warn: zip ensemble failed: {e}")
