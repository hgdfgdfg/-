from run_v20_p8fold_p11_fusion import main
if __name__ == '__main__':
    main()
