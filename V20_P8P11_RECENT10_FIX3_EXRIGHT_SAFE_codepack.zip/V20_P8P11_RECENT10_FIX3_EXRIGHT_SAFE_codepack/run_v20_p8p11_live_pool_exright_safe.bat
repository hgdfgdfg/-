@echo off
python run_v20_p8fold_p11_fusion.py ^
  --mode live_pool ^
  --config conf/v20_p8fold_p11_base.yaml ^
  --experiments conf/v20_p8fold_p11_experiments.csv ^
  --structure W160_60_30 ^
  --recent_folds 10 ^
  --output_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/runs/V20_P8_RECENT10_EXRIGHT_SAFE_FIX3" ^
  --db_path "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/data/ashare.duckdb" ^
  --daily_table stock_daily_mainboard ^
  --p11_out_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/V20_P11_TRUE_TWO_STAGE_SHRINK_RECENT10_EXRIGHT_SAFE_FIX3_out" ^
  --live_decision_date 2026-05-08 ^
  --live_buy_date 2026-05-11
pause
