# V20_P8_INTEGRATED_30SEED_10FOLD

这是 P8 整合版：基于 P5 训练底子，一键完成：

1. W160_60_30 × 30 seed × recent10fold 训练/预测；
2. 生成每个 seed 的 top10 / top1；
3. 不再做 union top10 二次模型排序；
4. 每个 seed 每天只取原始 top1，作为 seed champion；
5. 对 30 个 seed champion 做 cross-seed consensus；
6. 输出 top1 / top2 / top3 / top5 组合结果，支持 equal / vote / sqrt_vote 权重。

## 运行

建议先检查环境：

```bat
cd /d "C:\Users\魏儒翌\Desktop\新建文件夹 (2)\V20_P8_INTEGRATED_30SEED_10FOLD_build"
check_v20_p8_env.bat
```

一键全流程：

```bat
python run_v20_p8_integrated.py --config conf/v20_p8_base.yaml --experiments conf/v20_p8_experiments.csv --mode all --structure W160_60_30
```

或者：

```bat
run_v20_p8_integrated.bat
```

只训练：

```bat
python run_v20_p8_integrated.py --config conf/v20_p8_base.yaml --experiments conf/v20_p8_experiments.csv --mode train --structure W160_60_30
```

只 ensemble：

```bat
python run_v20_p8_integrated.py --config conf/v20_p8_base.yaml --experiments conf/v20_p8_experiments.csv --mode ensemble --structure W160_60_30
```

只跑 seed champion 组合：

```bat
python run_v20_p8_integrated.py --config conf/v20_p8_base.yaml --experiments conf/v20_p8_experiments.csv --mode champion --structure W160_60_30 --force_rebuild_p8_cache
```

## 默认参数

- structure: W160_60_30
- seeds: 202604 ~ 202633，共 30 个
- recent_folds: 10
- hold_days: 2
- 每个 seed 仍输出 top10 / top1
- P8 champion 只使用每个 seed 的原始 rank1

## 主要输出

训练输出：

```text
runs/V20_P8/
  V20_P8_W160_60_30_H2_S202604/
  ...
  V20_P8_W160_60_30_H2_S202633/
  p8seed30_train_all_folds.csv
```

ensemble 输出：

```text
runs/V20_P8/ensemble/W160_60_30/
  seed30_candidate_pool.csv
  seed30_ensemble_daily_top1.csv

runs/V20_P8/ensemble/
  seed30_ensemble_leaderboard.csv
  seed30_ensemble_by_fold.csv
  seed30_oracle_gap.csv
  V20_P8_SEED30_ensemble.zip
```

P8 seed champion 输出：

```text
runs/V20_P8/seed_champion/W160_60_30/
  V20_P8_seed_champions_daily.csv
  V20_P8_champion_pool_daily.csv
  V20_P8_champion_votes_distribution.csv
  V20_P8_portfolio_daily.csv
  V20_P8_portfolio_summary.csv
  V20_P8_portfolio_by_fold.csv
  V20_P8_champion_pool_oracle_top1.csv
  V20_P8_feature_coverage_diag.csv
  V20_P8_seed_champion_config.json
```

重点看：

```text
V20_P8_portfolio_summary.csv
V20_P8_portfolio_by_fold.csv
V20_P8_champion_votes_distribution.csv
```

## 设计原则

P8 不继承 P6/P6B 的二阶段模型排序，不做 LightGBM / XGBoost / RankNet / ListNet。

P8 只验证 seed 多层共识：

```text
30 seed 各自原始 top1
→ 去重
→ champion_votes 共识排序
→ top1/top2/top3/top5 组合
```

这样避免 union top10 大池带来的排序噪声。
