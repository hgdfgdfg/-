@echo off
setlocal
cd /d "%~dp0"
python run_v20_p8fold_p11_fusion.py --mode all --config conf/v20_p8fold_p11_base.yaml --experiments conf/v20_p8fold_p11_experiments.csv --structure W160_60_30 --recent_folds 10 --output_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (3)/runs/V20_P8_RECENT10_CLEAN_FIX1" --db_path "C:/Users/魏儒翌/Desktop/新建文件夹 (3)/data/ashare.duckdb" --daily_table stock_daily_mainboard --p11_out_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (3)/V20_P11_TRUE_TWO_STAGE_SHRINK_RECENT10_CLEAN_FIX1_out" --p11_allow_low_coverage
if errorlevel 1 (
  echo [ERROR] V20_P8FOLD_P11_FUSION failed.
  pause
  exit /b 1
)
echo [OK] V20_P8FOLD_P11_FUSION finished.
pause
