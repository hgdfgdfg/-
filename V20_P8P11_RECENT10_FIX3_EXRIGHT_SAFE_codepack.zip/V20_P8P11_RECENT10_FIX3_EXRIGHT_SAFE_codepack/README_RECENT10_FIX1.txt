V20_P8FOLD_P11_FUSION_30SEED_RECENT10_FIX1

用途：从 FIX3 改出的干净最近10fold源头包。

核心变化：
1. 默认 recent_folds=10。
2. 默认输出目录 runs/V20_P8_RECENT10_CLEAN_FIX1，避免复用旧19fold/10fold混合目录。
3. P8 每个 fold 仍写 date_range_check.json，并在 skip 前检查日期指纹。
4. P11 阶段严格要求 10 个唯一时间段：fold_id=10、unique date ranges=10、duplicate ranges=0。
5. 给 P30_5 使用：P30_5 默认 6train+3valid+1test，只跑最近1个test fold。

推荐运行：
python run_v20_p8fold_p11_fusion.py ^
  --mode all ^
  --config conf/v20_p8fold_p11_base.yaml ^
  --experiments conf/v20_p8fold_p11_experiments.csv ^
  --structure W160_60_30 ^
  --recent_folds 10 ^
  --output_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (3)/runs/V20_P8_RECENT10_CLEAN_FIX1" ^
  --db_path "C:/Users/魏儒翌/Desktop/新建文件夹 (3)/data/ashare.duckdb" ^
  --daily_table stock_daily_mainboard ^
  --p11_out_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (3)/V20_P11_TRUE_TWO_STAGE_SHRINK_RECENT10_CLEAN_FIX1_out" ^
  --p11_allow_low_coverage
