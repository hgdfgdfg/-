from v20_p11_true_two_stage.run import main
if __name__ == '__main__':
    main()
