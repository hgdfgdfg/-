
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse
import sys
import gc
import json
import shutil
from datetime import datetime
from pathlib import Path

# Robust entry: allow direct execution from the package root.
_THIS_DIR = Path(__file__).resolve().parent
if str(_THIS_DIR) not in sys.path:
    sys.path.insert(0, str(_THIS_DIR))

import numpy as np
import pandas as pd
from tqdm import tqdm

from v20_p8.config import load_yaml, load_experiments
from v20_p8.data import get_feature_table, make_recent_folds
from v20_p8.tcn import train_or_load_embeddings
from v20_p8.ranker import make_rank_targets, select_features, train_ranker, predict_ranker, save_model
from v20_p8.eval import evaluate_ranked
from v20_p8.utils import log_time, ensure_dir, seed_everything, pick_device, cleanup_torch, save_json
from v20_p8.champion import run_p8_champion_from_ensemble



def _as_date_str(x):
    return str(pd.to_datetime(x).date())

def _fold_expected_meta(fold: dict) -> dict:
    return {
        "train_start": _as_date_str(fold["train_start"]),
        "train_end": _as_date_str(fold["train_end"]),
        "valid_start": _as_date_str(fold["valid_start"]),
        "valid_end": _as_date_str(fold["valid_end"]),
        "test_start": _as_date_str(fold["test_start"]),
        "test_end": _as_date_str(fold["test_end"]),
    }

def _read_existing_date_meta(fold_dir: Path):
    p = Path(fold_dir) / "date_range_check.json"
    if not p.exists():
        return None
    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
        return {k: _as_date_str(obj.get(k)) for k in ["train_start","train_end","valid_start","valid_end","test_start","test_end"] if obj.get(k) is not None}
    except Exception:
        return None

def _fold_date_matches(fold_dir: Path, fold: dict) -> bool:
    got = _read_existing_date_meta(fold_dir)
    if got is None:
        return False
    exp = _fold_expected_meta(fold)
    return all(str(got.get(k)) == str(exp.get(k)) for k in exp)

def _move_stale_fold_dir(fold_dir: Path, reason: str):
    if not fold_dir.exists():
        return None
    backup_root = fold_dir.parents[1] / "_stale_mixed_fold_backup"
    backup_root.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dst = backup_root / fold_dir.parent.name / f"{fold_dir.name}_{ts}_{reason}"
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        shutil.rmtree(dst, ignore_errors=True)
    shutil.move(str(fold_dir), str(dst))
    return dst

def _fold_cache_tag(fold: dict) -> str:
    # date fingerprint prevents old 10fold embedding cache from being reused when fold_01..fold_10 are redefined by recent_folds=10
    return f"{fold['fold']}_{_as_date_str(fold['train_start']).replace('-','')}_{_as_date_str(fold['test_start']).replace('-','')}_{_as_date_str(fold['test_end']).replace('-','')}"

def _write_expected_schedule(out_root: Path, structure: str, exp_name: str, hold_days: int, train_days: int, valid_days: int, test_days: int, recent_folds: int, folds: list):
    rows=[]
    for i, f in enumerate(folds, 1):
        r={"temporal_order": i, "structure": structure, "exp_name": exp_name, "hold_days": int(hold_days), "train_days": int(train_days), "valid_days": int(valid_days), "test_days": int(test_days), "recent_folds": int(recent_folds), "fold": f["fold"]}
        r.update(_fold_expected_meta(f))
        rows.append(r)
    df=pd.DataFrame(rows)
    suffix=f"{structure}_H{int(hold_days)}_W{int(train_days)}_{int(valid_days)}_{int(test_days)}"
    df.to_csv(Path(out_root)/f"V20_P8_EXPECTED_RECENT10FOLD_SCHEDULE_{suffix}.csv", index=False, encoding="utf-8-sig")
    # also maintain a generic last-run schedule for ensemble/status tools
    df.to_csv(Path(out_root)/"V20_P8_EXPECTED_FOLD_SCHEDULE_LAST.csv", index=False, encoding="utf-8-sig")
    # hard fail on duplicate test date ranges inside the expected schedule itself
    key=df["test_start"].astype(str)+"__"+df["test_end"].astype(str)
    if key.duplicated().any():
        raise RuntimeError("Expected fold schedule itself has duplicate test date ranges; check make_recent_folds parameters/data calendar.")
    return df

FORBIDDEN_EXACT = {
    "future_ret_h", "future_excess_ret_h", "hit16", "hit20", "big_loss",
    "entry_open", "exit_open", "rank_norm", "top20_label", "top10_label",
    "sample_weight"
}

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="conf/v20_p8_base.yaml")
    p.add_argument("--experiments", default="conf/v20_p8_experiments.csv")
    p.add_argument("--mode", default="all", choices=["all","train","ensemble","champion"])
    p.add_argument("--only", default=None)
    p.add_argument("--force", action="store_true")
    p.add_argument("--structure", default="W160_60_30", help="P5 validation structure, default W160_60_30")
    p.add_argument("--force_rebuild_p8_cache", action="store_true", help="强制重建 P8 seed champion 180D 缓存")
    return p.parse_args()


def hard_cleanup():
    """Algorithm-level cache/memory cleanup after each fold/seed."""
    try:
        cleanup_torch()
    except Exception:
        pass
    try:
        gc.collect()
    except Exception:
        pass

def is_mainboard_symbol(sym: str) -> bool:
    s = str(sym).strip()
    digits = "".join([c for c in s if c.isdigit()])
    code = digits[-6:] if len(digits) >= 6 else s.zfill(6)
    if code.startswith(("300", "301", "688", "689")):
        return False
    return code.startswith(("600","601","603","605","000","001","002","003"))

def filter_trade_universe(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    if not cfg.get("mainboard_only", True):
        return df.copy()
    before_rows = len(df)
    before_symbols = df["symbol"].nunique()
    out = df[df["symbol"].astype(str).map(is_mainboard_symbol)].copy()
    log_time(f"mainboard filter | rows {before_rows}->{len(out)} | symbols {before_symbols}->{out['symbol'].nunique()}")
    return out

def merge_tabular(base_df, emb_df):
    key = ["symbol", "date"]
    meta_cols = key + ["future_ret_h", "hit16", "hit20", "big_loss"]
    exclude = set(meta_cols + ["future_excess_ret_h", "entry_open", "exit_open"])
    extra = [c for c in base_df.columns if c not in exclude and c not in emb_df.columns]
    small = base_df[meta_cols + extra].copy()
    return emb_df.merge(small, on=key, how="left", suffixes=("", "_base"))

def write_feature_diagnostics(fold_dir, features, fold, cfg, exp_seed, hold_days):
    fold_dir = Path(fold_dir)
    with open(fold_dir / "features_used.txt", "w", encoding="utf-8") as f:
        for c in features:
            f.write(str(c) + "\n")
    forbidden_keywords = [str(x).lower() for x in cfg.get("forbidden_feature_keywords", [])]
    rows = []
    for c in features:
        lc = c.lower()
        rows.append({"feature": c, "forbidden_exact": c in FORBIDDEN_EXACT, "forbidden_keyword": any(k in lc for k in forbidden_keywords)})
    pd.DataFrame(rows).to_csv(fold_dir / "forbidden_feature_check.csv", index=False, encoding="utf-8-sig")
    save_json(fold_dir / "date_range_check.json", {
        "seed": int(exp_seed), "hold_days": int(hold_days),
        "train_start": str(fold["train_start"]), "train_end": str(fold["train_end"]),
        "valid_start": str(fold["valid_start"]), "valid_end": str(fold["valid_end"]),
        "test_start": str(fold["test_start"]), "test_end": str(fold["test_end"]),
    })

def write_trade_details(fold_dir, ranked):
    ranked = ranked.sort_values(["date", "rank_score"], ascending=[True, False]).copy()
    ranked["rank"] = ranked.groupby("date").cumcount() + 1
    cols = ["date","symbol","rank","rank_score","future_ret_h","hit16","hit20","big_loss","tcn_score"]
    cols = [c for c in cols if c in ranked.columns]
    ranked[ranked["rank"] == 1][cols].to_csv(Path(fold_dir) / "top1_trade_detail.csv", index=False, encoding="utf-8-sig")
    ranked[ranked["rank"] <= 10][cols].to_csv(Path(fold_dir) / "top10_trade_detail.csv", index=False, encoding="utf-8-sig")

def fold_complete(fold_dir: Path, expected_fold: dict | None = None):
    required = ["test_eval.csv","test_ranked.csv","top1_trade_detail.csv","top10_trade_detail.csv","features_used.txt","forbidden_feature_check.csv","date_range_check.json"]
    ok = all((fold_dir/f).exists() and (fold_dir/f).stat().st_size > 0 for f in required)
    if not ok:
        return False
    if expected_fold is not None and not _fold_date_matches(fold_dir, expected_fold):
        return False
    return True

def train_all(cfg, exps, force=False):
    cfg["_device"] = pick_device(cfg.get("device", "auto"))
    out_root = ensure_dir(cfg.get("output_dir", "runs/V20_P8"))
    cache_dir = ensure_dir(cfg.get("cache_dir", "cache/V20_P8"))
    emb_cache = ensure_dir(cache_dir / "embeddings")
    log_time(f"V20_P8 train start | device={cfg['_device']} | experiments={len(exps)} | force={force}")

    data_by_hold = {}
    all_rows = []
    for _, exp in tqdm(exps.iterrows(), total=len(exps), desc="P5 train experiments"):
        exp_name = str(exp["exp_name"])
        train_days, valid_days, test_days = int(exp["train_days"]), int(exp["valid_days"]), int(exp["test_days"])
        hold_days, seq_len = int(exp["hold_days"]), int(exp["seq_len"])
        rank_target, feature_set = str(exp["rank_target"]), str(exp["feature_set"])
        exp_seed = int(exp.get("seed", cfg.get("seed", 202604)))
        structure = str(exp.get("structure", f"W{train_days}_{valid_days}_{test_days}"))

        local_cfg = dict(cfg)
        local_cfg["hold_days"] = hold_days
        local_cfg["seed"] = exp_seed
        seed_everything(exp_seed, deterministic=bool(local_cfg.get("deterministic", True)), cublas_workspace_config=str(local_cfg.get("cublas_workspace_config", ":4096:8")))

        if hold_days not in data_by_hold:
            log_time(f"loading/building feature table for H{hold_days}")
            raw_data = get_feature_table(local_cfg)
            raw_data = raw_data.replace([np.inf, -np.inf], np.nan)
            data_by_hold[hold_days] = filter_trade_universe(raw_data, local_cfg)
            del raw_data
            hard_cleanup()

        data = data_by_hold[hold_days]
        feature_cols = [c for c in local_cfg.get("feature_columns", []) if c in data.columns]
        exp_dir = ensure_dir(out_root / exp_name)
        log_time(f"Experiment {exp_name} | {structure} | W{train_days}_{valid_days}_{test_days} | H{hold_days} | seed={exp_seed}")

        folds = make_recent_folds(data, train_days, valid_days, test_days, int(local_cfg.get("recent_folds", 5)))
        _write_expected_schedule(out_root, structure, exp_name, hold_days, train_days, valid_days, test_days, int(local_cfg.get("recent_folds", 5)), folds)
        fold_rows = []
        for fold in tqdm(folds, desc=exp_name, leave=False):
            fold_name = fold["fold"]
            fold_dir = ensure_dir(exp_dir / fold_name)
            if (not force) and fold_dir.exists() and fold_complete(fold_dir) and (not _fold_date_matches(fold_dir, fold)):
                moved = _move_stale_fold_dir(fold_dir, "date_mismatch")
                log_time(f"stale fold dir moved because date range mismatched expected recent10fold schedule | {exp_name} | {fold_name} -> {moved}")
                fold_dir = ensure_dir(exp_dir / fold_name)

            if (not force) and fold_complete(fold_dir, fold):
                try:
                    row = pd.read_csv(fold_dir / "test_eval.csv").iloc[0].to_dict()
                    row.update({"exp_name": exp_name, "structure": structure, "fold": fold_name, "seed": exp_seed, "hold_days": hold_days, "train_days": train_days, "valid_days": valid_days, "test_days": test_days})
                    fold_rows.append(row); all_rows.append(row)
                    log_time(f"skip completed fold | {exp_name} | {fold_name} | date_range_ok")
                    continue
                except Exception:
                    pass

            emb_dir = ensure_dir(emb_cache / f"H{hold_days}_W{train_days}_{valid_days}_{test_days}_L{seq_len}_SEED{exp_seed}_{_fold_cache_tag(fold)}")
            log_time(f"Fold start | {exp_name} | {fold_name}")
            tr_emb, va_emb, te_emb = train_or_load_embeddings(data, fold, feature_cols, seq_len, "future_ret_h", local_cfg, emb_dir)

            tr, va, te = merge_tabular(data, tr_emb), merge_tabular(data, va_emb), merge_tabular(data, te_emb)
            tr, target_col, mode = make_rank_targets(tr, rank_target)
            va, _, _ = make_rank_targets(va, rank_target)
            te, _, _ = make_rank_targets(te, rank_target)
            features = select_features(tr, feature_set, local_cfg)
            if len(features) == 0:
                raise RuntimeError(f"{exp_name} feature_set={feature_set} 没有可用特征")
            write_feature_diagnostics(fold_dir, features, fold, local_cfg, exp_seed, hold_days)
            model, model_type = train_ranker(tr, va, features, target_col, mode, local_cfg)
            te["rank_score"] = predict_ranker(model, te, features, mode)
            ranked = te.sort_values(["date", "rank_score"], ascending=[True, False]).copy()
            eval_row = evaluate_ranked(ranked, "rank_score", hold_days)
            for k in [1,3,5,10]:
                key = f"top{k}_avg_ret"
                if key in eval_row:
                    eval_row[f"top{k}_avg_daily_ret"] = eval_row[key] / hold_days
            eval_row.update({"exp_name": exp_name, "structure": structure, "fold": fold_name, "seed": exp_seed, "hold_days": hold_days, "model_type": model_type, "feature_count": len(features), "rank_target": rank_target, "feature_set": feature_set, "train_days": train_days, "valid_days": valid_days, "test_days": test_days, "seq_len": seq_len})
            fold_rows.append(eval_row); all_rows.append(eval_row)

            ranked.to_csv(fold_dir / "test_ranked.csv", index=False, encoding="utf-8-sig")
            pd.DataFrame([eval_row]).to_csv(fold_dir / "test_eval.csv", index=False, encoding="utf-8-sig")
            write_trade_details(fold_dir, ranked)
            save_model(fold_dir / "model.pkl", model, {"features": features, "mode": mode, "model_type": model_type, "seed": exp_seed, "hold_days": hold_days})
            del tr_emb, va_emb, te_emb, tr, va, te, ranked, model
            hard_cleanup()

        if fold_rows:
            pd.DataFrame(fold_rows).to_csv(exp_dir / "summary.csv", index=False, encoding="utf-8-sig")
        del fold_rows
        hard_cleanup()

    if all_rows:
        pd.DataFrame(all_rows).to_csv(out_root / "p8seed30_train_all_folds.csv", index=False, encoding="utf-8-sig")
    del data_by_hold
    hard_cleanup()
    log_time("V20_P8 train done")

def _read_ranked(path, seed_label):
    df = pd.read_csv(path, parse_dates=["date"])
    df = df.sort_values(["date", "rank_score"], ascending=[True, False]).copy()
    df[f"rank_{seed_label}"] = df.groupby("date").cumcount() + 1
    # daily normalization over whole cross-section
    g = df.groupby("date")["rank_score"]
    mu = g.transform("mean")
    sd = g.transform("std").replace(0, np.nan)
    df[f"score_{seed_label}"] = df["rank_score"]
    df[f"z_{seed_label}"] = ((df["rank_score"] - mu) / sd).fillna(0.0)
    df[f"pct_{seed_label}"] = df.groupby("date")["rank_score"].rank(pct=True)
    keep = ["date","symbol","future_ret_h","hit16","hit20","big_loss",f"rank_{seed_label}",f"score_{seed_label}",f"z_{seed_label}",f"pct_{seed_label}"]
    keep = [c for c in keep if c in df.columns]
    return df[keep].copy()

def _load_candidates(out_root, exp_names, seed_labels, fold, top_n):
    merged = None
    label_cols = ["future_ret_h","hit16","hit20","big_loss"]
    for exp_name, seed_label in zip(exp_names, seed_labels):
        path = Path(out_root) / exp_name / fold / "test_ranked.csv"
        if not path.exists():
            raise FileNotFoundError(f"找不到 {path}")
        part_all = _read_ranked(path, seed_label)
        part = part_all[part_all[f"rank_{seed_label}"] <= top_n].copy()
        if merged is None:
            merged = part
        else:
            merged = merged.merge(part, on=["date","symbol"], how="outer", suffixes=("","_new"))
            for c in label_cols:
                nc = c+"_new"
                if nc in merged.columns and c in merged.columns:
                    merged[c] = merged[c].combine_first(merged[nc])
                    merged = merged.drop(columns=[nc])
                elif nc in merged.columns:
                    merged = merged.rename(columns={nc:c})
    return merged

def _add_consensus(df, seed_labels, top_n):
    out = df.copy()
    rank_cols = [f"rank_{s}" for s in seed_labels]
    score_cols = [f"score_{s}" for s in seed_labels]
    z_cols = [f"z_{s}" for s in seed_labels]
    pct_cols = [f"pct_{s}" for s in seed_labels]
    for cols in [rank_cols, score_cols, z_cols, pct_cols]:
        for c in cols:
            if c not in out.columns:
                out[c] = np.nan
    rank_mat = out[rank_cols]
    filled = rank_mat.fillna(top_n+1)
    out["top10_votes"] = rank_mat.le(10).sum(axis=1).astype(int)
    out["top5_votes"] = rank_mat.le(5).sum(axis=1).astype(int)
    out["top3_votes"] = rank_mat.le(3).sum(axis=1).astype(int)
    out["top1_votes"] = rank_mat.eq(1).sum(axis=1).astype(int)
    out["rank_min"] = filled.min(axis=1)
    out["rank_mean"] = filled.mean(axis=1)
    out["rank_std"] = filled.std(axis=1).fillna(0.0)
    out["score_mean"] = out[score_cols].mean(axis=1)
    out["score_std"] = out[score_cols].std(axis=1).fillna(0.0)
    out["score_max"] = out[score_cols].max(axis=1)
    out["zscore_mean"] = out[z_cols].mean(axis=1)
    out["zscore_std"] = out[z_cols].std(axis=1).fillna(0.0)
    out["zscore_max"] = out[z_cols].max(axis=1)
    out["rankpct_mean"] = out[pct_cols].mean(axis=1)
    out["rankpct_std"] = out[pct_cols].std(axis=1).fillna(0.0)
    out["rankpct_max"] = out[pct_cols].max(axis=1)
    return out

def _filter_candidates(df, cfg):
    a = int(cfg.get("ensemble_min_top10_votes", 2))
    b = int(cfg.get("ensemble_allow_top3_votes", 1))
    c = int(cfg.get("ensemble_allow_top1_votes", 1))
    mask = (df["top10_votes"] >= a) | (df["top3_votes"] >= b) | (df["top1_votes"] >= c)
    return df[mask].copy()

def _select_rule(day, rule):
    d = day.copy()
    if rule == "oracle_union_top10":
        return d.sort_values("future_ret_h", ascending=False).iloc[0]
    if rule == "score_mean":
        cols, asc = ["score_mean","top10_votes","rank_mean"], [False,False,True]
    elif rule == "score_zscore_mean":
        cols, asc = ["zscore_mean","top10_votes","rank_mean"], [False,False,True]
    elif rule == "score_rankpct_mean":
        cols, asc = ["rankpct_mean","top10_votes","rank_mean"], [False,False,True]
    elif rule == "score_zscore_mean_minus_std":
        d["rule_score"] = d["zscore_mean"] - 0.35*d["zscore_std"]
        cols, asc = ["rule_score","top10_votes","rank_mean"], [False,False,True]
    elif rule == "score_rankpct_mean_minus_std":
        d["rule_score"] = d["rankpct_mean"] - 0.35*d["rankpct_std"]
        cols, asc = ["rule_score","top10_votes","rank_mean"], [False,False,True]
    elif rule == "score_rankpct_mean_plus_votes":
        d["rule_score"] = d["rankpct_mean"] + 0.015*d["top10_votes"] + 0.025*d["top5_votes"] + 0.040*d["top3_votes"] + 0.060*d["top1_votes"]
        cols, asc = ["rule_score","rank_mean"], [False,True]
    elif rule == "score_zscore_mean_plus_votes":
        d["rule_score"] = d["zscore_mean"] + 0.05*d["top10_votes"] + 0.10*d["top5_votes"] + 0.15*d["top3_votes"] + 0.20*d["top1_votes"]
        cols, asc = ["rule_score","rank_mean"], [False,True]
    elif rule == "votes_then_score_zscore":
        cols, asc = ["top10_votes","zscore_mean","rank_mean","zscore_std"], [False,False,True,True]
    elif rule == "votes_then_score_rankpct":
        cols, asc = ["top10_votes","rankpct_mean","rank_mean","rankpct_std"], [False,False,True,True]
    elif rule == "rank_mean":
        cols, asc = ["rank_mean","top10_votes","rank_std"], [True,False,True]
    elif rule == "rank_min":
        cols, asc = ["rank_min","top3_votes","top10_votes","rank_mean"], [True,False,False,True]
    elif rule == "votes_then_rank_mean":
        cols, asc = ["top10_votes","rank_mean","top3_votes","rank_std"], [False,True,False,True]
    elif rule == "top3_votes_then_rank_min":
        cols, asc = ["top3_votes","rank_min","top10_votes","rank_mean"], [False,True,False,True]
    else:
        raise ValueError(rule)
    return d.sort_values(cols, ascending=asc, kind="mergesort").iloc[0]

def _apply_rule(candidates, rule):
    rows = []
    for _, day in candidates.groupby("date", sort=True):
        if len(day):
            r = _select_rule(day, rule).copy()
            r["rule_name"] = rule
            rows.append(r)
    return pd.DataFrame(rows)

def _eval_daily(df, hold_days):
    if df is None or len(df)==0:
        return {}
    return {
        "n_days": int(len(df)),
        "top1_avg_ret": float(df["future_ret_h"].mean()),
        "top1_avg_daily_ret": float(df["future_ret_h"].mean()/hold_days),
        "top1_hit16_rate": float(df["hit16"].mean()),
        "top1_hit20_rate": float(df["hit20"].mean()),
        "top1_big_loss_rate": float(df["big_loss"].mean()),
        "top1_median_ret": float(df["future_ret_h"].median()),
        "sel_top10_votes_avg": float(df["top10_votes"].mean()) if "top10_votes" in df else np.nan,
        "sel_top3_votes_avg": float(df["top3_votes"].mean()) if "top3_votes" in df else np.nan,
        "sel_rank_mean_avg": float(df["rank_mean"].mean()) if "rank_mean" in df else np.nan,
    }


def _date_meta_from_json(p: Path):
    try:
        obj=json.loads(Path(p).read_text(encoding="utf-8"))
        return {k:_as_date_str(obj.get(k)) for k in ["train_start","train_end","valid_start","valid_end","test_start","test_end"]}
    except Exception as e:
        raise RuntimeError(f"Cannot read date_range_check.json: {p} | {e}")

def _discover_clean_ensemble_folds(out_root: Path, exp_names: list[str], expected_n: int):
    if not exp_names:
        raise RuntimeError("No experiments for ensemble")
    first=Path(out_root)/exp_names[0]
    rows=[]
    for fd in sorted([p for p in first.glob("fold_*") if p.is_dir()]):
        if not fold_complete(fd):
            continue
        meta=_date_meta_from_json(fd/"date_range_check.json")
        rows.append({"fold":fd.name, **meta})
    if not rows:
        raise FileNotFoundError(f"没有找到完整 fold: {first}")
    tbl=pd.DataFrame(rows)
    tbl["test_key"]=tbl["test_start"].astype(str)+"__"+tbl["test_end"].astype(str)
    dup=tbl[tbl["test_key"].duplicated(keep=False)].sort_values(["test_start","fold"])
    audit_dir=ensure_dir(Path(out_root)/"ensemble")
    tbl.sort_values(["test_start","test_end","fold"]).to_csv(audit_dir/"V20_P8_ensemble_fold_date_audit.csv", index=False, encoding="utf-8-sig")
    if len(dup):
        dup.to_csv(audit_dir/"V20_P8_ensemble_duplicate_fold_ranges_ERROR.csv", index=False, encoding="utf-8-sig")
        raise RuntimeError("P8 ensemble aborted: duplicate fold date ranges found. This output_dir is mixed/stale; rerun train with FIX3 or use a clean output_dir.")
    tbl=tbl.sort_values(["test_start","test_end","fold"]).reset_index(drop=True)
    if expected_n and len(tbl) != int(expected_n):
        raise RuntimeError(f"P8 ensemble aborted: expected {expected_n} clean folds, found {len(tbl)}. Check missing/stale folds before P11.")
    # validate all experiments have the same complete folds/date ranges
    expected={r["fold"]:{k:r[k] for k in ["train_start","train_end","valid_start","valid_end","test_start","test_end"]} for _,r in tbl.iterrows()}
    bad=[]
    for exp in exp_names:
        for fold,meta in expected.items():
            fd=Path(out_root)/exp/fold
            if not fold_complete(fd):
                bad.append({"exp_name":exp,"fold":fold,"error":"missing_or_incomplete"}); continue
            got=_date_meta_from_json(fd/"date_range_check.json")
            if any(str(got.get(k))!=str(meta.get(k)) for k in meta):
                bad.append({"exp_name":exp,"fold":fold,"error":"date_range_mismatch","got":json.dumps(got,ensure_ascii=False),"expected":json.dumps(meta,ensure_ascii=False)})
    if bad:
        pd.DataFrame(bad).to_csv(audit_dir/"V20_P8_ensemble_cross_seed_fold_audit_ERROR.csv", index=False, encoding="utf-8-sig")
        raise RuntimeError("P8 ensemble aborted: cross-seed fold date audit failed. See V20_P8_ensemble_cross_seed_fold_audit_ERROR.csv")
    tbl.to_csv(audit_dir/"V20_P8_ensemble_clean_recent10fold_schedule.csv", index=False, encoding="utf-8-sig")
    return tbl["fold"].astype(str).tolist(), tbl

def ensemble_all(cfg, exps):
    out_root = ensure_dir(cfg.get("output_dir", "runs/V20_P8"))
    ens_dir = ensure_dir(out_root / "ensemble")
    hold_days = int(cfg.get("hold_days", 2))
    top_n = int(cfg.get("ensemble_top_n", 10))
    rules = [
        "score_mean","score_zscore_mean","score_rankpct_mean",
        "score_zscore_mean_minus_std","score_rankpct_mean_minus_std",
        "score_rankpct_mean_plus_votes","score_zscore_mean_plus_votes",
        "votes_then_score_zscore","votes_then_score_rankpct",
        "rank_mean","rank_min","votes_then_rank_mean","top3_votes_then_rank_min",
        "oracle_union_top10"
    ]
    log_time(f"V20_P8 ensemble start | rules={len(rules)} | top_n={top_n}")
    leaderboard = []
    all_daily = []
    all_cand = []
    by_fold_rows = []
    oracle_rows = []

    for structure, grp in tqdm(exps.groupby("structure"), desc="P5 ensemble structures"):
        grp = grp.sort_values("seed")
        exp_names = grp["exp_name"].astype(str).tolist()
        seed_labels = [f"S{int(s)}" for s in grp["seed"].tolist()]
        seed_prefix = f"seed{len(seed_labels)}"
        folds, fold_schedule = _discover_clean_ensemble_folds(out_root, exp_names, int(cfg.get("recent_folds", 0)))
        log_time(f"P8 ensemble clean fold schedule OK | structure={structure} | folds={len(folds)} | first={folds[0]} last={folds[-1]}")

        struct_candidates = []
        struct_daily = []
        for fold in tqdm(folds, desc=structure, leave=False):
            c = _load_candidates(out_root, exp_names, seed_labels, fold, top_n)
            c = _add_consensus(c, seed_labels, top_n)
            c_all = c.copy()
            c_all["candidate_mode"] = "union_top10_all"
            c = _filter_candidates(c, cfg)
            c["candidate_mode"] = "filtered_votes"
            for dfx in [c_all, c]:
                dfx["structure"] = structure
                dfx["fold"] = fold
            struct_candidates.append(c)
            all_cand.append(c)

            # oracle diagnostics before filtering and after filtering
            for mode, cand in [("union_top10_all", c_all), ("filtered_votes", c)]:
                idx = cand.groupby("date")["future_ret_h"].idxmax()
                oracle = cand.loc[idx].copy()
                row = _eval_daily(oracle, hold_days)
                row.update({"structure": structure, "fold": fold, "candidate_mode": mode, "candidate_pool_size_avg": float(cand.groupby("date")["symbol"].nunique().mean())})
                oracle_rows.append(row)

            for rule in rules:
                cand_for_rule = c_all if rule == "oracle_union_top10" else c
                daily = _apply_rule(cand_for_rule, rule)
                if len(daily)==0:
                    continue
                daily["structure"] = structure
                daily["fold"] = fold
                daily["candidate_mode"] = "union_top10_all" if rule == "oracle_union_top10" else "filtered_votes"
                struct_daily.append(daily)
                all_daily.append(daily)
                fr = _eval_daily(daily, hold_days)
                fr.update({"structure": structure, "rule_name": rule, "fold": fold})
                by_fold_rows.append(fr)

        cand_df = pd.concat(struct_candidates, ignore_index=True)
        daily_df = pd.concat(struct_daily, ignore_index=True)
        sdir = ensure_dir(ens_dir / structure)
        cand_df.to_csv(sdir / f"{seed_prefix}_candidate_pool.csv", index=False, encoding="utf-8-sig")
        daily_df.to_csv(sdir / f"{seed_prefix}_ensemble_daily_top1.csv", index=False, encoding="utf-8-sig")

        for rule, g in daily_df.groupby("rule_name"):
            row = _eval_daily(g, hold_days)
            row.update({"structure": structure, "rule_name": rule})
            # fold metrics
            for fold, fg in g.groupby("fold"):
                er = _eval_daily(fg, hold_days)
                for k in ["top1_avg_ret","top1_hit16_rate","top1_hit20_rate","top1_big_loss_rate","n_days"]:
                    row[f"{fold}_{k}"] = er.get(k, np.nan)
            # oracle hit rate vs union oracle symbol
            try:
                oracle = daily_df[daily_df["rule_name"]=="oracle_union_top10"][["date","fold","symbol"]].rename(columns={"symbol":"oracle_symbol"})
                sel = g[["date","fold","symbol"]].merge(oracle, on=["date","fold"], how="left")
                row["oracle_hit_rate"] = float((sel["symbol"] == sel["oracle_symbol"]).mean())
            except Exception:
                row["oracle_hit_rate"] = np.nan
            leaderboard.append(row)

    leader = pd.DataFrame(leaderboard)
    if len(leader):
        leader = leader.sort_values(["top1_avg_ret","top1_hit20_rate","top1_big_loss_rate"], ascending=[False,False,True])
    leader.to_csv(ens_dir / f"{seed_prefix}_ensemble_leaderboard.csv", index=False, encoding="utf-8-sig")
    if all_daily:
        pd.concat(all_daily, ignore_index=True).to_csv(ens_dir / f"{seed_prefix}_ensemble_daily_top1.csv", index=False, encoding="utf-8-sig")
    if all_cand:
        pd.concat(all_cand, ignore_index=True).to_csv(ens_dir / f"{seed_prefix}_candidate_pool.csv", index=False, encoding="utf-8-sig")
    if by_fold_rows:
        pd.DataFrame(by_fold_rows).to_csv(ens_dir / f"{seed_prefix}_ensemble_by_fold.csv", index=False, encoding="utf-8-sig")
    if oracle_rows:
        pd.DataFrame(oracle_rows).to_csv(ens_dir / f"{seed_prefix}_oracle_gap.csv", index=False, encoding="utf-8-sig")
    save_json(ens_dir / "overview.json", {"project":"V20_P8_INTEGRATED_30SEED_10FOLD", "seed_count": int(len(exps)), "structures": sorted(exps["structure"].unique()), "rules": rules, "candidate_filter": "top10_votes>=2 OR top3_votes>=1 OR top1_votes>=1"})
    log_time("V20_P8 ensemble done")

def main():
    args = parse_args()
    cfg = load_yaml(args.config)
    exps = load_experiments(args.experiments)
    if args.only:
        exps = exps[exps["exp_name"] == args.only].copy()
        if len(exps)==0:
            raise ValueError(f"--only={args.only} 未找到")
    if args.mode in ["all","train"]:
        train_all(cfg, exps, force=args.force)
    if args.mode in ["all","ensemble"]:
        ensemble_all(cfg, exps)
    if args.mode in ["all","champion"]:
        run_p8_champion_from_ensemble(cfg, exps, structure=args.structure, force_rebuild_cache=args.force_rebuild_p8_cache)
    log_time("V20_P8 integrated all done")

if __name__ == "__main__":
    main()
