V20_P8P11_RECENT10_FIX3_EXRIGHT_SAFE

用途：
- 在 P8/P11 训练和 live_pool 推理两端统一使用“复权/除权安全”的特征价格。
- raw open/high/low/close 不变，仍用于真实交易标签、T日开盘买入、T+2开盘卖出、成交额、涨跌停/买入可行性。
- ret/MA/vol/position/shadow 等模型特征使用：
  1) DuckDB 中显式 qfq/adj 字段（如果存在）；
  2) 否则自动检测相邻 close 大跳变（默认阈值 22%），构造 synthetic front-adjusted 连续价格，仅用于特征工程。

重要：
- 这是需要重新 --mode all 全量训练的版本。
- 不要用旧 FIX2 artifacts 直接跑这个 FIX3 live_pool；训练/推理口径必须一致。

全量训练命令：
python run_v20_p8fold_p11_fusion.py ^
  --mode all ^
  --config conf/v20_p8fold_p11_base.yaml ^
  --experiments conf/v20_p8fold_p11_experiments.csv ^
  --structure W160_60_30 ^
  --recent_folds 10 ^
  --output_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/runs/V20_P8_RECENT10_EXRIGHT_SAFE_FIX3" ^
  --db_path "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/data/ashare.duckdb" ^
  --daily_table stock_daily_mainboard ^
  --p11_out_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/V20_P11_TRUE_TWO_STAGE_SHRINK_RECENT10_EXRIGHT_SAFE_FIX3_out" ^
  --p11_allow_low_coverage

每日 live_pool 命令：
python run_v20_p8fold_p11_fusion.py ^
  --mode live_pool ^
  --config conf/v20_p8fold_p11_base.yaml ^
  --experiments conf/v20_p8fold_p11_experiments.csv ^
  --structure W160_60_30 ^
  --recent_folds 10 ^
  --output_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/runs/V20_P8_RECENT10_EXRIGHT_SAFE_FIX3" ^
  --db_path "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/data/ashare.duckdb" ^
  --daily_table stock_daily_mainboard ^
  --p11_out_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/V20_P11_TRUE_TWO_STAGE_SHRINK_RECENT10_EXRIGHT_SAFE_FIX3_out" ^
  --live_decision_date 2026-05-08 ^
  --live_buy_date 2026-05-11
