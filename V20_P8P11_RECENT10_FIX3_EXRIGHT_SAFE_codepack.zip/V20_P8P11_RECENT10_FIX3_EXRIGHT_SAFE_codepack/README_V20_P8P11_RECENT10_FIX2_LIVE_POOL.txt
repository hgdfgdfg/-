V20_P8P11_RECENT10_FIX2_LIVE_POOL

作用：每天收盘后，不训练、不回测，只读取已经训练好的 recent10/30seed artifacts，
用截至 live_decision_date 的 K线特征，对最新无标签日做 30seed 缩池，输出给 P30_5 使用。

前提：你已经完整跑过 V20_P8FOLD_P11_FUSION_30SEED_RECENT10_FIX1，并且 output_dir 里有 clean recent10 的 fold artifacts。

示例：
python run_v20_p8fold_p11_fusion.py ^
  --mode live_pool ^
  --config conf/v20_p8fold_p11_base.yaml ^
  --experiments conf/v20_p8fold_p11_experiments.csv ^
  --structure W160_60_30 ^
  --recent_folds 10 ^
  --output_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/runs/V20_P8_RECENT10_CLEAN_FIX1" ^
  --db_path "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/data/ashare.duckdb" ^
  --daily_table stock_daily_mainboard ^
  --p11_out_dir "C:/Users/魏儒翌/Desktop/新建文件夹 (4)/V20_P11_TRUE_TWO_STAGE_SHRINK_RECENT10_CLEAN_FIX1_out" ^
  --live_decision_date 2026-04-30 ^
  --live_buy_date 2026-05-06

主要输出：
<p11_out_dir>/live_pool/V20_P11_TRUE_LIVE_POOL_latest_unlabeled.csv
<p11_out_dir>/live_pool/V20_P8P11_LIVE_POOL_multi_config_ensemble.csv
<p11_out_dir>/live_pool/V20_P8P11_LIVE_POOL_run_audit.csv

注意：live_pool 不使用 future_ret_h，不参与训练，只打分缩池。
