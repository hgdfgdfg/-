
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse
import json
import subprocess
import sys
import gc
from pathlib import Path
import pandas as pd

_THIS_DIR = Path(__file__).resolve().parent
if str(_THIS_DIR) not in sys.path:
    sys.path.insert(0, str(_THIS_DIR))

from v20_p8.config import load_yaml, load_experiments
from v20_p8.utils import log_time, ensure_dir, save_json
from run_v20_p8_integrated import train_all, ensemble_all

def parse_args():
    p = argparse.ArgumentParser(description="V20_P8P11_RECENT10_FIX3_EXRIGHT_SAFE: clean recent10 P8/P11 with ex-right-safe feature prices + live_pool")
    p.add_argument("--config", default="conf/v20_p8fold_p11_base.yaml")
    p.add_argument("--experiments", default="conf/v20_p8fold_p11_experiments.csv")
    p.add_argument("--mode", default="all", choices=["all","train","ensemble","p11","status","live_pool"])
    p.add_argument("--structure", default="W160_60_30")
    p.add_argument("--output_dir", default="C:/Users/魏儒翌/Desktop/新建文件夹 (3)/runs/V20_P8_RECENT10_EXRIGHT_SAFE_FIX3")
    p.add_argument("--cache_dir", default=None)
    p.add_argument("--db_path", default="C:/Users/魏儒翌/Desktop/新建文件夹 (3)/data/ashare.duckdb")
    p.add_argument("--daily_table", default="stock_daily_mainboard")
    p.add_argument("--recent_folds", type=int, default=10)
    p.add_argument("--force", action="store_true", help="retrain even if a fold is complete")
    p.add_argument("--only", default=None, help="only run one exp_name/seed")
    p.add_argument("--p11_out_dir", default="C:/Users/魏儒翌/Desktop/新建文件夹 (3)/V20_P11_TRUE_TWO_STAGE_SHRINK_RECENT10_EXRIGHT_SAFE_FIX3_out")
    p.add_argument("--p11_force_rebuild_cache", action="store_true")
    p.add_argument("--p11_allow_low_coverage", action="store_true", default=True)
    p.add_argument("--skip_p11", action="store_true")
    p.add_argument("--p11_allow_mixed_folds", action="store_true", help="debug only: pass through mixed/duplicate folds to P11; default is strict abort")
    # FIX2 live_pool: daily close -> next-open live candidate pool without retraining/backtest labels.
    p.add_argument("--live_decision_date", default="", help="T-1 close decision date for live_pool; default=max DuckDB date")
    p.add_argument("--live_buy_date", default="", help="T open buy date stored as live trade_date; required if next trading day is not in DB")
    p.add_argument("--live_top_n_per_seed", type=int, default=10, help="per-seed topN kept before 30seed consensus")
    p.add_argument("--live_pool_top_n", type=int, default=60, help="final live_pool topN by 30seed consensus")
    p.add_argument("--live_output_dir", default="", help="optional output dir for live_pool csv; default p11_out_dir/live_pool")
    return p.parse_args()

def _complete_fold(fold_dir: Path) -> bool:
    required = ["test_eval.csv","test_ranked.csv","top1_trade_detail.csv","top10_trade_detail.csv","features_used.txt","forbidden_feature_check.csv","date_range_check.json"]
    return all((fold_dir/f).exists() and (fold_dir/f).stat().st_size > 0 for f in required)

def status_report(cfg, exps, structure: str):
    out_root = Path(cfg["output_dir"])
    rows = []
    for _, r in exps.iterrows():
        exp = str(r["exp_name"])
        exp_dir = out_root / exp
        folds = sorted([p.name for p in exp_dir.glob("fold_*") if p.is_dir()]) if exp_dir.exists() else []
        complete = [f for f in folds if _complete_fold(exp_dir/f)]
        rows.append({
            "exp_name": exp, "seed": int(r["seed"]), "existing_folds": len(folds),
            "complete_folds": len(complete), "missing_to_recent_folds": max(0, int(cfg.get("recent_folds",10))-len(complete)),
            "complete_fold_list": ",".join(complete)
        })
    df = pd.DataFrame(rows)
    ensure_dir(out_root)
    path = out_root / f"V20_P8FOLD_status_{structure}.csv"
    df.to_csv(path, index=False, encoding="utf-8-sig")
    log_time(f"status saved | {path}")
    print(df[["exp_name","complete_folds","missing_to_recent_folds"]].to_string(index=False))

def run_p11_true(args, cfg):
    out_root = Path(cfg["output_dir"])
    ensemble_dir = out_root / "ensemble"
    if not ensemble_dir.exists():
        raise FileNotFoundError(f"ensemble dir not found: {ensemble_dir}. Run --mode ensemble first.")
    p11_script = _THIS_DIR / "run_v20_p11_true_two_stage_shrink.py"
    if not p11_script.exists():
        raise FileNotFoundError(f"P11 TRUE script not found: {p11_script}")
    cmd = [
        sys.executable, str(p11_script),
        "--ensemble_zip", str(ensemble_dir),
        "--duckdb_path", str(cfg["db_path"]),
        "--out_dir", str(args.p11_out_dir),
        "--daily_table", str(cfg.get("daily_table","stock_daily_mainboard")),
        "--structure", str(args.structure),
        "--expected_folds", str(int(cfg.get("recent_folds", 10))),
    ]
    if args.p11_allow_mixed_folds:
        cmd.append("--allow_mixed_folds")
    if args.p11_force_rebuild_cache:
        cmd.append("--force_rebuild_cache")
    if args.p11_allow_low_coverage:
        cmd.append("--allow_low_coverage")
    log_time("P11 TRUE auto start")
    log_time(" ".join([f'"{c}"' if " " in c else c for c in cmd]))
    subprocess.run(cmd, check=True)
    log_time("P11 TRUE auto done")


def _load_pickle_model(path: Path):
    import pickle
    with open(path, "rb") as f:
        obj = pickle.load(f)
    if isinstance(obj, dict) and "model" in obj and "meta" in obj:
        return obj["model"], obj.get("meta", {})
    return obj, {}


def _build_live_embedding_for_decision(data, fold, feature_cols, seq_len, cfg, emb_dir: Path, decision_date):
    """Load the fold TCN artifact and produce embeddings for one unlabeled decision date.

    Training remains historical. Live rows do not need future_ret_h; this function only uses
    bars up to decision_date and the train-window standardizer used by that fold.
    """
    from v20_p8.model import TCNFactorNet
    from v20_p8.data import fit_standardizer, apply_standardizer
    from v20_p8.utils import pick_device
    import torch
    import numpy as np
    import pandas as pd
    decision_date = pd.to_datetime(decision_date).normalize()
    model_path = Path(emb_dir) / "tcn_model.pt"
    if not model_path.exists():
        raise FileNotFoundError(f"live_pool needs existing TCN artifact: {model_path}. Run train once first.")
    if "_device" not in cfg:
        cfg["_device"] = pick_device(cfg.get("device", "auto"))
    tr_for_std = data[(data["date"] >= fold["train_start"]) & (data["date"] <= fold["train_end"])].copy()
    mu, sd = fit_standardizer(tr_for_std, feature_cols)
    context = data[data["date"] <= decision_date].copy()
    context = apply_standardizer(context, feature_cols, mu, sd)
    rows=[]; xs=[]
    for sym,g in context.sort_values(["symbol","date"]).groupby("symbol", sort=False):
        g=g.reset_index(drop=True)
        idxs=g.index[pd.to_datetime(g["date"]).dt.normalize()==decision_date].tolist()
        if not idxs:
            continue
        i=idxs[-1]
        if i < int(seq_len)-1:
            continue
        arr=g.loc[i-int(seq_len)+1:i, feature_cols].astype("float32").values
        if not np.isfinite(arr).all():
            continue
        xs.append(arr)
        rows.append({"symbol":sym, "date":decision_date})
    if not xs:
        return pd.DataFrame(columns=["symbol","date","tcn_score"])
    model=TCNFactorNet(input_dim=len(feature_cols), channels=cfg.get("tcn_channels",[32,32,64]), kernel_size=int(cfg.get("tcn_kernel_size",3)), dropout=float(cfg.get("tcn_dropout",0.15)), embedding_dim=int(cfg.get("embedding_dim",16))).to(cfg["_device"])
    state=torch.load(model_path, map_location=cfg["_device"])
    model.load_state_dict(state); model.eval()
    scores=[]; embs=[]
    bs=int(cfg.get("tcn_batch_size",1024))
    with torch.no_grad():
        for st in range(0,len(xs),bs):
            x=torch.tensor(np.asarray(xs[st:st+bs]), dtype=torch.float32).to(cfg["_device"])
            pred,emb=model(x,return_embedding=True)
            scores.append(pred.detach().cpu().numpy()); embs.append(emb.detach().cpu().numpy())
    scores=np.concatenate(scores) if scores else np.array([])
    embs=np.concatenate(embs) if embs else np.zeros((0,int(cfg.get("embedding_dim",16))))
    out=pd.DataFrame(rows)
    out["tcn_score"]=scores
    for i in range(embs.shape[1]): out[f"emb_{i:02d}"]=embs[:,i]
    return out


def _merge_live_tabular(base_df, emb_df):
    key=["symbol","date"]
    exclude=set(key+["future_ret_h","future_excess_ret_h","entry_open","exit_open","hit16","hit20","big_loss"])
    extra=[c for c in base_df.columns if c not in exclude and c not in emb_df.columns]
    small=base_df[key+extra].copy()
    return emb_df.merge(small,on=key,how="left")


def run_live_pool(args, cfg, exps):
    """Daily P8/P11 live_pool: use existing latest-fold 30seed artifacts to shrink latest unlabeled candidates.

    This does not train and does not require future_ret_h. It scores decision_date with each seed's latest
    clean fold artifacts, aggregates 30seed consensus, and writes a latest_unlabeled pool for P30_5.
    """
    import numpy as np, pandas as pd
    from v20_p8.data import load_daily, build_features, add_labels
    from v20_p8.ranker import predict_ranker
    from run_v20_p8_integrated import _discover_clean_ensemble_folds, _fold_cache_tag, _add_consensus, _filter_candidates, filter_trade_universe
    out_root=Path(cfg["output_dir"])
    live_dir=Path(args.live_output_dir) if args.live_output_dir else Path(args.p11_out_dir)/"live_pool"
    ensure_dir(live_dir)
    # fresh features: do not trust stale label cache for daily live.
    daily=load_daily(cfg)
    daily["date"]=pd.to_datetime(daily["date"]).dt.normalize()
    dates=daily["date"].dropna().drop_duplicates().sort_values()
    if args.live_decision_date:
        decision_date=pd.to_datetime(args.live_decision_date).normalize()
    else:
        decision_date=pd.to_datetime(dates.iloc[-1]).normalize()
    if args.live_buy_date:
        buy_date=pd.to_datetime(args.live_buy_date).normalize()
    else:
        nxt=dates[dates>decision_date]
        buy_date=pd.to_datetime(nxt.iloc[0]).normalize() if len(nxt) else pd.NaT
    if pd.isna(buy_date):
        pd.DataFrame([{"decision_date_Tminus1":decision_date,"buy_date_T_open":"NEXT_TRADING_DAY_REQUIRED","message":"Pass --live_buy_date manually."}]).to_csv(live_dir/"V20_P8P11_LIVE_POOL_NEXT_TRADING_DAY_REQUIRED.csv",index=False,encoding="utf-8-sig")
        log_time("P8/P11 live_pool skipped | NEXT_TRADING_DAY_REQUIRED")
        return
    feat=add_labels(build_features(daily,cfg),cfg).replace([np.inf,-np.inf],np.nan)
    feat=filter_trade_universe(feat,cfg)
    all_seed_parts=[]
    run_rows=[]
    for structure, grp in exps.groupby("structure"):
        grp=grp.sort_values("seed")
        exp_names=grp["exp_name"].astype(str).tolist()
        seed_labels=[f"S{int(s)}" for s in grp["seed"].tolist()]
        folds, fold_schedule=_discover_clean_ensemble_folds(out_root, exp_names, int(cfg.get("recent_folds",10)))
        latest_fold=folds[-1]
        meta=fold_schedule[fold_schedule["fold"].astype(str)==latest_fold].iloc[0].to_dict()
        fold={k:pd.to_datetime(meta[k]) for k in ["train_start","train_end","valid_start","valid_end","test_start","test_end"]}; fold["fold"]=latest_fold
        log_time(f"P8/P11 live_pool | structure={structure} latest_artifact_fold={latest_fold} decision_date={decision_date.date()} buy_date={buy_date.date()}")
        for _, exp in grp.iterrows():
            exp_name=str(exp["exp_name"]); seed_label=f"S{int(exp['seed'])}"
            train_days, valid_days, test_days = int(exp["train_days"]), int(exp["valid_days"]), int(exp["test_days"])
            hold_days, seq_len = int(exp["hold_days"]), int(exp["seq_len"])
            feature_set=str(exp["feature_set"])
            local_cfg=dict(cfg); local_cfg["hold_days"]=hold_days; local_cfg["seed"]=int(exp["seed"])
            feature_cols=[c for c in local_cfg.get("feature_columns",[]) if c in feat.columns]
            fold_dir=out_root/exp_name/latest_fold
            model_path=fold_dir/"model.pkl"
            if not model_path.exists():
                raise FileNotFoundError(f"Missing ranker artifact for live_pool: {model_path}")
            cache_dir=ensure_dir(local_cfg.get("cache_dir","cache/V20_P8") )
            emb_dir=Path(cache_dir)/"embeddings"/f"H{hold_days}_W{train_days}_{valid_days}_{test_days}_L{seq_len}_SEED{int(exp['seed'])}_{_fold_cache_tag(fold)}"
            live_emb=_build_live_embedding_for_decision(feat,fold,feature_cols,seq_len,local_cfg,emb_dir,decision_date)
            live_df=_merge_live_tabular(feat[feat["date"]<=decision_date].copy(),live_emb)
            model, mmeta=_load_pickle_model(model_path)
            features=mmeta.get("features") or []
            mode=mmeta.get("mode","reg")
            features=[c for c in features if c in live_df.columns]
            if not features:
                raise RuntimeError(f"No live features for {exp_name}/{latest_fold}")
            live_df["rank_score"]=predict_ranker(model,live_df,features,mode)
            live_df=live_df.sort_values(["date","rank_score"],ascending=[True,False]).copy()
            live_df[f"rank_{seed_label}"]=live_df.groupby("date").cumcount()+1
            g=live_df.groupby("date")["rank_score"]
            mu=g.transform("mean"); sd=g.transform("std").replace(0,np.nan)
            live_df[f"score_{seed_label}"]=live_df["rank_score"]
            live_df[f"z_{seed_label}"]=((live_df["rank_score"]-mu)/sd).fillna(0.0)
            live_df[f"pct_{seed_label}"]=live_df.groupby("date")["rank_score"].rank(pct=True)
            keep=live_df[live_df[f"rank_{seed_label}"]<=int(args.live_top_n_per_seed)][["date","symbol",f"rank_{seed_label}",f"score_{seed_label}",f"z_{seed_label}",f"pct_{seed_label}"]].copy()
            keep["structure"]=structure; keep["exp_name"]=exp_name; keep["seed_label"]=seed_label
            all_seed_parts.append(keep)
            run_rows.append({"structure":structure,"exp_name":exp_name,"seed_label":seed_label,"latest_artifact_fold":latest_fold,"live_rows_scored":int(len(live_df)),"live_rows_kept":int(len(keep)),"feature_count":len(features)})
    if not all_seed_parts:
        raise RuntimeError("live_pool produced no seed parts")
    # outer merge all seed topN on decision date/symbol
    merged=None
    for part in all_seed_parts:
        cols=[c for c in part.columns if c.startswith(("rank_","score_","z_","pct_"))]
        sm=part[["date","symbol"]+cols].copy()
        merged=sm if merged is None else merged.merge(sm,on=["date","symbol"],how="outer")
    # consensus using helper from run_v20_p8_integrated
    seed_labels=[]
    for c in merged.columns:
        if c.startswith("rank_S"):
            seed_labels.append(c.replace("rank_",""))
    seed_labels=sorted(set(seed_labels))
    cons=_add_consensus(merged,seed_labels,int(args.live_top_n_per_seed))
    cons=_filter_candidates(cons,{"ensemble_min_top10_votes":2,"ensemble_allow_top3_votes":1,"ensemble_allow_top1_votes":1})
    cons["mc_score_ensemble_seed"]=(cons.get("zscore_mean",0).fillna(0)+0.20*cons.get("top10_votes",0).fillna(0)-0.05*cons.get("rank_mean",0).fillna(0))
    cons=cons.sort_values(["mc_score_ensemble_seed","top10_votes","top3_votes","rank_mean"],ascending=[False,False,False,True]).head(int(args.live_pool_top_n)).copy()
    cons["fold_id"]="live_latest_unlabeled"
    cons["date"]=buy_date
    cons["trade_date"]=buy_date
    cons["decision_date_Tminus1"]=decision_date
    cons["buy_date_T_open"]=buy_date
    cons["source_label"]="P8P11_LIVE_POOL"
    cons["shrink_rule"]="live_30seed_consensus"
    cons["shrink_top_k"]=int(args.live_top_n_per_seed)
    cons["stage2_method"]="live_pool_no_stage2_label"
    cons["stage2_top_n"]=15
    cons["_stage2_rank"]=np.arange(1,len(cons)+1)
    cons["stage2_pool_size"]=len(cons)
    cons["future_ret_h"]=np.nan; cons["future_avg_daily_ret"]=np.nan
    cons["mc_config_vote_count"]=cons.get("top10_votes",0)
    cons["mc_config_row_count"]=cons.get("top10_votes",0)
    cons["mc_best_rank"]=cons.get("rank_min",np.nan)
    cons["mc_mean_rank"]=cons.get("rank_mean",np.nan)
    cons["mc_rank_std"]=cons.get("rank_std",np.nan)
    cons["mc_mean_pool_score"]=cons.get("score_mean",np.nan)
    cons["mc_max_pool_score"]=cons.get("score_max",np.nan)
    cons["mc_score_vote_rank"]=cons["mc_score_ensemble_seed"]
    cons["mc_score_fix3_like"]=cons["mc_score_ensemble_seed"]
    cons["mc_score_mean_pool"]=cons.get("score_mean",np.nan)
    out_csv=live_dir/"V20_P11_TRUE_LIVE_POOL_latest_unlabeled.csv"
    cons.to_csv(out_csv,index=False,encoding="utf-8-sig")
    cons.to_csv(live_dir/"V20_P8P11_LIVE_POOL_multi_config_ensemble.csv",index=False,encoding="utf-8-sig")
    pd.DataFrame(run_rows).to_csv(live_dir/"V20_P8P11_LIVE_POOL_run_audit.csv",index=False,encoding="utf-8-sig")
    (live_dir/"V20_P8P11_LIVE_POOL_audit.txt").write_text(f"decision_date={decision_date}\nbuy_date={buy_date}\nrows={len(cons)}\nsource=existing latest-fold 30seed artifacts, no training, no future_ret_h\n",encoding="utf-8")
    log_time(f"P8/P11 live_pool written | {out_csv} | rows={len(cons)}")

def main():
    args = parse_args()
    cfg = load_yaml(args.config)
    cfg["output_dir"] = args.output_dir
    cfg["db_path"] = args.db_path
    cfg["daily_table"] = args.daily_table
    cfg["recent_folds"] = int(args.recent_folds)
    if args.cache_dir:
        cfg["cache_dir"] = args.cache_dir

    exps = load_experiments(args.experiments)
    if "enable" in exps.columns:
        exps = exps[pd.to_numeric(exps["enable"], errors="coerce").fillna(1).astype(int) == 1].copy()
    if args.only:
        exps = exps[exps["exp_name"].astype(str) == args.only].copy()
        if len(exps) == 0:
            raise ValueError(f"--only={args.only} not found")
    exps["structure"] = exps["structure"].astype(str)
    exps = exps[exps["structure"] == args.structure].copy()
    if len(exps)==0:
        raise ValueError(f"No experiments for structure={args.structure}")

    ensure_dir(Path(cfg["output_dir"]))
    save_json(Path(cfg["output_dir"]) / "V20_P8FOLD_P11_FUSION_run_config.json", {
        "args": vars(args),
        "cfg_overrides": {"output_dir": cfg["output_dir"], "db_path": cfg["db_path"], "daily_table": cfg["daily_table"], "recent_folds": cfg["recent_folds"]},
        "n_experiments": int(len(exps)),
    })

    log_time(f"V20_P8FOLD_P11_FUSION start | mode={args.mode} | exp={len(exps)} | recent_folds={cfg['recent_folds']}")
    if args.mode == "status":
        status_report(cfg, exps, args.structure)
        return
    if args.mode == "live_pool":
        run_live_pool(args, cfg, exps)
        return
    if args.mode in ["all","train"]:
        train_all(cfg, exps, force=args.force)
        gc.collect()
    if args.mode in ["all","ensemble"]:
        ensemble_all(cfg, exps)
        gc.collect()
    if args.mode in ["all","p11"] and (not args.skip_p11):
        run_p11_true(args, cfg)
    log_time("V20_P8FOLD_P11_FUSION finished")

if __name__ == "__main__":
    main()
